=== freeSIEM Sentinel ===
Contributors: freesiem
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 1.0.34
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

freeSIEM Sentinel connects a WordPress site to freeSIEM Core for ownership verification, local scanning, secure uploads, remote commands, and centralized summary reporting.

== Description ==

freeSIEM Sentinel is the WordPress agent for freeSIEM Core.

Features:

* Site registration with freeSIEM Core
* Secure heartbeat every 15 minutes
* Strictly whitelisted remote command handling
* Signed remote Pending Tasks queue for sensitive user-management actions
* Read-only local security scanning
* Secure HMAC-signed local scan uploads
* Remote scan trigger requests
* Admin dashboard, results view, and About page
* GitHub release-based updates with a "Check for Updates" action link

== Installation ==

1. Upload the `freesiem-sentinel` folder to `/wp-content/plugins/`.
2. Activate the plugin in WordPress.
3. Open `freeSIEM > Portal`.
4. Enter the site owner email address.
5. Click `Register / Save`.

== Frequently Asked Questions ==

= How are plugin updates delivered? =

Publish a GitHub Release and attach a zip asset named `freesiem-sentinel.zip`.

That zip should contain:

`freesiem-sentinel/`
`  freesiem-sentinel.php`
`  includes/`
`  readme.txt`

= Release Packaging =

GitHub Releases are the distribution source for freeSIEM Sentinel.

1. Bump the plugin version in `freesiem-sentinel.php` and `readme.txt`.
2. Commit and push `main`.
3. Create a matching git tag such as `v0.1.1`.
4. Push the tag to GitHub.
5. GitHub Actions will automatically build and publish the ZIP asset for that release.

The release ZIP asset must be named `freesiem-sentinel.zip`.

The ZIP must contain the plugin folder at the top level:

`freesiem-sentinel/`
`  freesiem-sentinel.php`
`  includes/`
`  readme.txt`

Version bumps should always have matching git tags.

GitHub Actions publishes the ZIP automatically when a `v*` tag is pushed.

== Changelog ==

= 0.3.47 =

* Keep running full Sync and baseline batch plans visible in Pending Changes after page refresh or empty status polls.
* Rebuild a running full Sync job in the browser from saved Sync status so polling and batch driving continue instead of stopping at the default preview message.
* Include saved Sync status in the job status endpoint and avoid clearing the active full Sync plan unless the user cancels/resets Sync.
* Store large full Sync baseline state on disk, split database batches into smaller chunks, and exclude plugin/runtime options that can crash the destination.

= 0.3.46 =

* Prevent Pending Changes from falling back to generic preview instructions whenever saved status, current job, or preview data indicates a full Sync is running or planned.
* Render a server-side batch counter from the saved running full Sync status message when the full job object is not available after refresh.

= 0.3.45 =

* Render saved full Sync job state in Pending Changes on the server so refreshes show running/resumable batches before JavaScript loads.
* Make Preview Changes use the batched full Sync planner when selected scopes need a baseline, keeping Start Baseline aligned with Preview Full Sync.
* Pass saved Sync status into the admin JavaScript as a fallback when the full Sync job object is temporarily unavailable.

= 0.3.44 =

* Pass saved Sync status into the admin JavaScript so page reloads can still show full Sync running/resume context when the job object is temporarily unavailable.
* Use saved running Sync status as a Pending Changes fallback instead of reverting to generic preview instructions.

= 0.3.43 =

* Restore saved incomplete full Sync jobs after page reload so admins can resume instead of seeing only baseline setup.
* Refresh the Pending Changes header during resumed full Sync runs instead of leaving stale success messages in that panel.
* Infer the active running batch from the full Sync status message when the numeric current batch field has not refreshed yet.

= 0.3.42 =

* Retry interrupted full Sync batches that were left in a running state, allowing Resume Sync to continue after a destination fatal error or timeout.
* Show the active full Sync batch count from the current batch index when detailed batch status has not refreshed yet.

= 0.3.41 =

* Treat destination cURL timeouts during Sync uploads as recoverable by polling the destination Sync status before failing the batch.
* Keep the full Sync UI in a running/retry state when a transient status refresh error happens while the job is still active.

= 0.3.40 =

* Keep the full Sync batch plan visible in Pending Changes while the running job status catches up.
* Preserve previewed batch details during polling so admins can see completed, running, and planned batches refresh during full Sync.

= 0.3.39 =

* Keep the full Sync progress panel visible immediately after Start Full Sync and prevent empty status refreshes from reverting the UI to Awaiting baseline.
* Return an explicit running status when a full Sync job is queued so admins see the planned files, rows, and batch count while processing starts.

= 0.3.38 =

* Simplify the Sync action flow so Preview Full Sync turns into Start Full Sync on the same button while Preview Changes keeps the baseline/push action separate.
* Improve full Sync start feedback and keep the page busy while browser-driven batch processing is running.
* Record manual baseline and completed Sync watermarks from current file/post timestamps so immediate previews do not show already-baselined items as pending.

= 0.3.37 =

* Keep full Sync jobs moving from the admin browser when WordPress loopback or cron does not continue batch processing, improving DDEV/local reliability after partial full Sync runs.

= 0.3.36 =

* Fix Update Live Sentinel by avoiding WordPress filesystem prompts when applying remote plugin packages.
* Add a fallback that updates destination Sentinel files through the Sync receiver when older live sites return a server error from the self-update endpoint.
* Show clear in-page progress and error messages while Update Live Sentinel is running.

= 0.3.35 =

* Package the latest Backup & Restore sync reset and WordPress menu repair updates for GitHub release delivery.

= 0.3.34 =

* Add a Cancel / Reset Sync action so interrupted full Sync jobs can be cleared and restarted cleanly.
* Clarify full Sync as a preview-first workflow before any destination changes are pushed.

= 0.3.33 =

* Repair synced WordPress nav menus through the WordPress menu APIs after database apply so live destinations keep menu items and theme locations.
* Replace incoming menu and SureForms post meta before applying sync SQL so stale destination meta rows do not mask synced values.

= 0.3.32 =

* Add signed install-base dial-home inventory events for activation, upgrade, and recurring heartbeat
* Route local DDEV installs to the Core localhost endpoint and production installs to core.freesiem.com

= 0.3.31 =

* Rename the bundled site package workflow from Synchy to Backup & Restore throughout the Sentinel admin UI
* Keep internal Synchy slugs and endpoints stable for saved settings and remote compatibility

= 0.3.30 =

* Treat Synchy as an embedded Sentinel feature instead of a separately versioned plugin in the Sync UI
* Make Update Live send and apply the full Sentinel plugin package when Synchy is bundled inside Sentinel

= 0.3.29 =

* Fix Update Live Synchy inside Sentinel so it compares and refreshes the bundled Synchy runtime version instead of the parent Sentinel plugin version
* Keep Sentinel itself on the normal GitHub release updater while allowing Sync destinations to receive the latest bundled Synchy runtime

= 0.3.28 =

* Replace local development media URLs during Synchy Sync and restore so DDEV/local aliases do not survive pushes to live sites
* Preserve serialized WordPress content while normalizing local-origin URLs to the destination site URL

= 0.3.27 =

* Improve Synchy full sync reliability and release packaging

= 0.3.20 =

* Harden Stealth Mode login and wp-admin enforcement, including safer token handling and preserved redirect flows
* Add Stealth Mode visibility in logs and the Stealth Mode admin page
* Expose Stealth Mode status to freeSIEM Core and add narrow signed Core commands for Stealth Mode management

= 0.3.19 =

* Add a wp-config.php stealth-mode recovery override so normal WordPress login behavior can be restored without changing saved settings
* Show the effective stealth status and recovery snippet on the Stealth Mode admin page

= 0.3.18 =

* Preserve the stealth login token on wp-login form submits so protected logins redirect to the requested admin page instead of home
* Avoid PHP 8.1+ admin-menu deprecation notices by registering hidden Sentinel pages without passing null parent slugs

= 0.3.17 =

* Fix stealth mode post-login redirects so protected admin URLs and direct stealth logins return to wp-admin safely

= 0.3.16 =

* Reorganize Sentinel admin menus, add Login Protection, Stealth Mode, and Logs pages, and add lightweight auth event logging

= 0.3.15 =

* Remove the SSL readiness overview block, add a dedicated Re-Issue Certificate action, and make Force HTTPS plus HSTS apply through nginx with live status checks

= 0.3.14 =

* Merge SSL settings into Overview, clean duplicate controls, auto-populate webroot, and fix Force HTTPS status/apply behavior

= 0.3.13 =

* Default staging off, reduce duplicate SSL action controls, move reissue controls into readiness, and add a next-steps workflow panel

= 0.3.12 =

* Show both HTTP and HTTPS endpoint status on the SSL overview and warn clearly when a staging certificate is being served

= 0.3.11 =

* Keep nginx SSL config changes in place when only root-only validate/reload steps remain, and surface the exact root finalize commands

= 0.3.10 =

* Clarify nginx apply failures caused by web-user privilege limits instead of reporting them as generic syntax failures

= 0.3.9 =

* Fix nginx apply backups to use Sentinel user-space storage instead of writing sibling backup files in nginx directories

= 0.3.8 =

* Add nginx auto-apply permission guidance with detected-path commands and keep the SSL overview workflow clean

= 0.3.7 =

* Fix nginx detection state refresh and show the true nginx apply blockers in the SSL UI

= 0.3.6 =

* Fix nginx auto detection fallback behavior and stale UI messaging, and polish the SSL workflow-driven overview

= 0.3.5 =

* Fix nginx auto detection diagnostics and streamline the SSL workflow UI with a top action bar, certificate viewer, and logs-first detail layout

= 0.3.4 =

* Add auto nginx apply detection from nginx -T and patch active configs via a Sentinel-managed SSL include snippet

= 0.3.3 =

* Add admin-triggered nginx SSL preview and apply flow with backup, syntax test, reload, and rollback handling

= 0.3.2 =

* Fix SSL issue vs renew certbot command flow, explicit force reissue handling, and no-action-needed renewal messaging

= 0.3.1 =

* Force certbot issue, renew, and preview commands into writable user-space directories

= 0.3.0 =

* Fix SSL readiness blocker messaging and add an optional gated certbot installation UI with environment detection and manual fallback instructions

= 0.2.9 =

* Add explicit admin-triggered certbot issuance and renewal plumbing with structured execution results, certificate metadata capture, and post-run verification while leaving redirects and HSTS inactive

= 0.2.8 =

* Add SSL Phase 2 readiness modeling, simulated certbot preview generation, and a dry-run validation workflow without issuing certificates or changing runtime HTTPS behavior

= 0.2.7 =

* Add a Phase 1 SSL / HTTPS admin area with overview, safe preflight checks, future settings storage, and lightweight logs without issuing certificates or changing server behavior

= 0.2.6 =

* Add the Sentinel-side TFA foundation: encrypted per-user TFA state, local TOTP enrollment and enforcement, signed remote `/users/*` TFA endpoints, and a TFA admin page

= 0.2.5 =

* Force-set and verify explicit provisioning passwords after user creation so the stored WordPress password matches the submitted password exactly

= 0.2.4 =

* Correct the packaged release version for the explicit-password provisioning fix

= 0.2.3 =

* Fix Phase 1 explicit-password provisioning so approval-time execution uses the separate internal execution payload instead of the redacted task snapshot
* Protect raw execution passwords internally, log only short SHA-256 fingerprints for troubleshooting, and scrub the internal execution payload after successful provisioning

= 0.2.2 =

* Send an immediate heartbeat back to freeSIEM Core whenever a pending task status changes, including approve, deny, executing, completed, and failed
* Keep the scheduled priority-heartbeat fallback so task status reporting stays resilient if the immediate send cannot complete

= 0.2.1 =

* Add a signed `GET /wp-json/freesiem-sentinel/v1/cloud-connect/users` endpoint for safe remote user listing
* Reuse the existing freeSIEM signed request verification flow for remote user-list reads
* Return only safe user metadata and advertise `supports_remote_user_listing` in heartbeat payloads
* Add smoke coverage for route registration, valid signed reads, invalid signatures, and empty user-list responses

= 0.2.0 =

* Add a signed Pending Tasks approval queue for remote user-management actions from freeSIEM Core
* Add local approve, deny, auto-approve, execution, audit trail, and heartbeat task reporting flows
* Add Pending Tasks wp-admin review UI and configurable approval policy settings
* Add a repo-native smoke test script for queue submission, idempotency, approvals, and heartbeat redaction

= 0.1.15 =

* Prevent Cloud Connect verify from overwriting saved local automation preferences before the post-verify preference sync is sent

= 0.1.14 =

* Preserve Cloud automation preferences across disconnect and reconnect, and send broader legacy-compatible preference payload keys to freeSIEM Core during Cloud sync

= 0.1.13 =

* Preserve saved Cloud automation preferences during Cloud Connect verify, test, and heartbeat flows instead of overwriting them from Cloud heartbeat responses

= 0.1.12 =

* Keep saved Cloud automation preferences checked locally after Save Cloud Preferences instead of letting the Core sync response overwrite them

= 0.1.11 =

* Make Cloud test/disconnect error reporting clearer, use a minimal signed heartbeat for connection tests, and allow safe local disconnect cleanup when Core already rejects the remote session

= 0.1.10 =

* Preserve saved Cloud automation preferences through verification and sync them to freeSIEM Core immediately after connection

= 0.1.9 =

* Fix Cloud preference sync so remote scan and centralized user sync persist in wp-admin and update freeSIEM Core heartbeat metadata and site permissions correctly

= 0.1.8 =

* Refine the Cloud page UX, restore production-only backend behavior, and sync Cloud preferences to Core while simplifying local user-sync controls

= 0.1.7 =

* Extend Cloud Connect MVP with signed heartbeat/disconnect, status management, and local testing support via a custom backend URL override

= 0.1.6 =

* Refine the Portal landing page, Cloud onboarding, Scan layout, and About page update experience

= 0.1.5 =

* Improve About page updates, compact the Scan UI, and fix clear-results behavior

= 0.1.4 =

* Add the freeSIEM Cloud connection flow and automation controls

= 0.1.3 =

* Improve scan metrics, add clear results flow, and make file changes filtering more interactive

= 0.1.2 =

* Redesign the dashboard and merge scan and results into one investigation workflow

= 0.1.1 =

* Automate GitHub Release publishing from version tags and matching plugin ZIP packaging

= 0.1.0 =

* Add final phase 4 hardening, safe scan failure handling, and stability improvements

= 0.0.9 =

* Fix GitHub release ZIP updater support and enable file integrity monitoring for all users

= 0.0.8 =

* Fix null-safe admin URL handling and polish updater and results rendering

= 0.0.7 =

* Add feature gating and restructure the admin UI for productized freeSIEM workflows

= 0.0.6 =

* Polish file integrity summaries and finding details across wp-admin

= 0.0.5 =

* Add file integrity monitoring baseline and diff engine

= 0.0.4 =

* Fix wp-admin deprecation-prone output handling and redesign the Results experience

= 0.0.3 =

* Improve dashboard, results, and About page operator UX

= 0.0.2 =

* Add bounded filesystem scanning heuristics and richer posture findings

= 0.0.1 =

* Initial release of freeSIEM Sentinel
