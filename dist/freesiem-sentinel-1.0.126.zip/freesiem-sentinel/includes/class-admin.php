<?php

if (!defined('ABSPATH')) {
	exit;
}

class Freesiem_Admin
{
	private Freesiem_Plugin $plugin;

	/**
	 * Populated once per request by maybe_auto_update_from_settings_page() (admin_init, runs
	 * before any admin_menu page callback) so render_settings_page() doesn't have to make a
	 * second forced GitHub API call for the same check later in the same request.
	 */
	private $settings_update_check = null;

	public function __construct(Freesiem_Plugin $plugin)
	{
		$this->plugin = $plugin;
	}

	public function register(): void
	{
		add_action('admin_menu', [$this, 'register_menu']);
		add_action('admin_menu', [$this, 'remove_synchy_top_level_menu'], 999);
		add_action('admin_init', [$this->plugin, 'maybe_process_pending_task_maintenance']);
		add_action('admin_init', [$this, 'maybe_redirect_legacy_synchy_pages']);
		add_action('admin_init', [$this, 'maybe_redirect_legacy_about_page']);
		add_action('admin_init', [$this, 'maybe_auto_update_from_settings_page']);
		add_action('admin_enqueue_scripts', [$this, 'maybe_enqueue_synchy_assets']);
		add_action('admin_notices', 'freesiem_sentinel_render_notices');
		add_action('admin_post_freesiem_sentinel_save_cloud_connect_contact', [$this, 'handle_save_cloud_connect_contact']);
		add_action('admin_post_freesiem_sentinel_cloud_connect_start', [$this, 'handle_cloud_connect_start']);
		add_action('admin_post_freesiem_sentinel_cloud_connect_verify', [$this, 'handle_cloud_connect_verify']);
		add_action('admin_post_freesiem_sentinel_cloud_connect_reset', [$this, 'handle_cloud_connect_reset']);
		add_action('admin_post_freesiem_sentinel_cloud_connect_disconnect', [$this, 'handle_cloud_connect_disconnect']);
		add_action('admin_post_freesiem_sentinel_cloud_connect_test', [$this, 'handle_cloud_connect_test']);
		add_action('admin_post_freesiem_sentinel_save_settings', [$this, 'handle_save_settings']);
		add_action('admin_post_freesiem_sentinel_run_configured_scan', [$this, 'handle_run_configured_scan']);
		add_action('admin_post_freesiem_sentinel_clear_results', [$this, 'handle_clear_results']);
		add_action('admin_post_freesiem_sentinel_save_scan_schedule', [$this, 'handle_save_scan_schedule']);
		add_action('admin_post_freesiem_sentinel_email_scan_results', [$this, 'handle_email_scan_results']);
		add_action('admin_post_freesiem_sentinel_export_results', [$this, 'handle_export_results']);
		add_action('admin_post_freesiem_sentinel_run_full_scan_now', [$this, 'handle_run_full_scan_now']);
		add_action('admin_post_freesiem_sentinel_abort_deep_scan', [$this, 'handle_abort_deep_scan']);
		add_action('admin_post_freesiem_sentinel_clear_cron_history', [$this, 'handle_clear_cron_history']);
		add_action('admin_post_freesiem_sentinel_start_cloud_connect', [$this, 'handle_start_cloud_connect']);
		add_action('admin_post_freesiem_sentinel_verify_cloud_connect', [$this, 'handle_verify_cloud_connect']);
		add_action('admin_post_freesiem_sentinel_save_cloud_preferences', [$this, 'handle_save_cloud_preferences']);
		add_action('admin_post_freesiem_sentinel_request_remote_scan', [$this, 'handle_request_remote_scan']);
		add_action('admin_post_freesiem_sentinel_sync_results', [$this, 'handle_sync_results']);
		add_action('admin_post_freesiem_sentinel_reconnect', [$this, 'handle_reconnect']);
		add_action('admin_post_freesiem_sentinel_disconnect_cloud', [$this, 'handle_disconnect_cloud']);
		add_action('admin_post_freesiem_sentinel_test_connection', [$this, 'handle_test_connection']);
		add_action('admin_post_freesiem_sentinel_approve_task', [$this, 'handle_approve_task']);
		add_action('admin_post_freesiem_sentinel_deny_task', [$this, 'handle_deny_task']);
		add_action('admin_post_freesiem_sentinel_tfa_enroll', [$this, 'handle_tfa_enroll']);
		add_action('admin_post_freesiem_sentinel_tfa_reset', [$this, 'handle_tfa_reset']);
		add_action('admin_post_freesiem_sentinel_tfa_complete_setup', [$this, 'handle_tfa_complete_setup']);
		add_action('admin_post_freesiem_sentinel_tfa_change_password', [$this, 'handle_tfa_change_password']);
		add_action('admin_post_freesiem_sentinel_save_ssl_settings', [$this, 'handle_save_ssl_settings']);
		add_action('admin_post_freesiem_sentinel_run_ssl_preflight', [$this, 'handle_run_ssl_preflight']);
		add_action('admin_post_freesiem_sentinel_run_ssl_dry_run', [$this, 'handle_run_ssl_dry_run']);
		add_action('admin_post_freesiem_sentinel_issue_ssl_certificate', [$this, 'handle_issue_ssl_certificate']);
		add_action('admin_post_freesiem_sentinel_renew_ssl_certificate', [$this, 'handle_renew_ssl_certificate']);
		add_action('admin_post_freesiem_sentinel_detect_nginx_config', [$this, 'handle_detect_nginx_config']);
		add_action('admin_post_freesiem_sentinel_apply_ssl_to_nginx', [$this, 'handle_apply_ssl_to_nginx']);
		add_action('admin_post_freesiem_sentinel_install_certbot', [$this, 'handle_install_certbot']);
		add_action('admin_post_freesiem_sentinel_save_login_protection', [$this, 'handle_save_login_protection']);
		add_action('admin_post_freesiem_sentinel_unblock_login_protection_record', [$this, 'handle_unblock_login_protection_record']);
		add_action('admin_post_freesiem_sentinel_unblock_expired_login_protection_records', [$this, 'handle_unblock_expired_login_protection_records']);
		add_action('admin_post_freesiem_sentinel_save_stealth_mode', [$this, 'handle_save_stealth_mode']);
		add_action('admin_post_freesiem_sentinel_clear_logs', [$this, 'handle_clear_logs']);
		add_action('admin_post_freesiem_sentinel_save_rustfs_settings', [$this, 'handle_save_rustfs_settings']);
		add_action('admin_post_freesiem_sentinel_test_rustfs_connection', [$this, 'handle_test_rustfs_connection']);
		add_action('admin_post_freesiem_sentinel_quarantine_file', [$this, 'handle_quarantine_file']);
		add_action('admin_post_freesiem_sentinel_delete_file', [$this, 'handle_delete_file']);
		add_action('admin_post_freesiem_sentinel_restore_file', [$this, 'handle_restore_file']);
		add_action('admin_post_freesiem_sentinel_mark_finding_safe', [$this, 'handle_mark_finding_safe']);
		add_action('admin_post_freesiem_sentinel_unmark_finding_safe', [$this, 'handle_unmark_finding_safe']);
		add_action('admin_post_freesiem_sentinel_clear_safe_marks', [$this, 'handle_clear_safe_marks']);
		add_action('wp_ajax_freesiem_sentinel_deep_scan_tick', [$this, 'handle_deep_scan_tick']);
		add_action('wp_login_failed', [$this, 'handle_login_failed_event'], 10, 2);
		add_action('wp_login', [$this, 'handle_login_success_event'], 10, 2);
		add_action('init', [$this, 'maybe_handle_stealth_mode'], 1);
		add_action('login_form', [$this, 'render_stealth_login_token_field']);
		add_filter('authenticate', [$this, 'maybe_enforce_login_lockout'], 30, 3);
		add_filter('login_errors', [$this, 'filter_stealth_login_error_message']);
		add_filter('login_url', [$this, 'filter_login_url'], 10, 3);
		add_filter('login_redirect', [$this, 'filter_stealth_login_redirect'], 10, 3);
		add_action('freesiem_sentinel_tfa_success', [$this, 'handle_tfa_success_event'], 10, 2);
		add_action('freesiem_sentinel_tfa_failure', [$this, 'handle_tfa_failure_event'], 10, 2);
	}

	public function register_menu(): void
	{
		add_menu_page(
			__('freeSIEM', 'freesiem-sentinel'),
			__('freeSIEM', 'freesiem-sentinel'),
			'manage_options',
			'freesiem-portal',
			[$this, 'render_dashboard_page'],
			'dashicons-shield-alt'
		);

		add_submenu_page('freesiem-portal', __('Dashboard', 'freesiem-sentinel'), __('Dashboard', 'freesiem-sentinel'), 'manage_options', 'freesiem-portal', [$this, 'render_dashboard_page']);
		// "Operations" bundles Connection (was "Cloud"), Logs, and Pending Tasks -- registered at
		// the lowest capability among its tabs ('read') so a non-admin allowed to approve tasks
		// still sees the menu item; render_activity_page() gates each tab's real content itself.
		add_submenu_page('freesiem-portal', __('Core-Ops', 'freesiem-sentinel'), __('Core-Ops', 'freesiem-sentinel'), 'read', 'freesiem-activity', [$this, 'render_activity_page']);
		// "Security" bundles SSL/HTTPS, TFA, Login Protection, and Stealth Mode.
		add_submenu_page('freesiem-portal', __('Security', 'freesiem-sentinel'), __('Security', 'freesiem-sentinel'), 'manage_options', 'freesiem-security', [$this, 'render_security_page']);
		add_submenu_page('freesiem-portal', __('Synchy', 'freesiem-sentinel'), __('Synchy', 'freesiem-sentinel'), 'manage_options', FREESIEM_SENTINEL_SYNCHY_PAGE, [$this, 'render_synchy_page']);
		add_submenu_page('freesiem-portal', __('Settings', 'freesiem-sentinel'), __('Settings', 'freesiem-sentinel'), 'manage_options', 'freesiem-settings', [$this, 'render_settings_page']);

		// Kept registered but off the visible menu (same pattern as Scan below) -- every existing
		// redirect_to_page()/admin_page_url() call and self-referencing link to these slugs across
		// the plugin keeps working unchanged; Activity/Security are what the sidebar shows instead.
		add_submenu_page('', __('Cloud', 'freesiem-sentinel'), __('Cloud', 'freesiem-sentinel'), 'manage_options', 'freesiem-remote', [$this, 'render_remote_page']);
		add_submenu_page('', __('SSL / HTTPS', 'freesiem-sentinel'), __('SSL / HTTPS', 'freesiem-sentinel'), 'manage_options', 'freesiem-ssl', [$this, 'render_ssl_page']);
		add_submenu_page('', __('TFA (2FA)', 'freesiem-sentinel'), __('TFA (2FA)', 'freesiem-sentinel'), 'manage_options', 'freesiem-tfa', [$this, 'render_tfa_page']);
		add_submenu_page('', __('Login Protection', 'freesiem-sentinel'), __('Login Protection', 'freesiem-sentinel'), 'manage_options', 'freesiem-login-protection', [$this, 'render_login_protection_page']);
		add_submenu_page('', __('Stealth Mode', 'freesiem-sentinel'), __('Stealth Mode', 'freesiem-sentinel'), 'manage_options', 'freesiem-stealth-mode', [$this, 'render_stealth_mode_page']);
		add_submenu_page('', __('Logs', 'freesiem-sentinel'), __('Logs', 'freesiem-sentinel'), 'manage_options', 'freesiem-logs', [$this, 'render_logs_page']);
		add_submenu_page('', __('Pending Tasks', 'freesiem-sentinel'), __('Pending Tasks', 'freesiem-sentinel'), 'read', 'freesiem-pending-tasks', [$this, 'render_pending_tasks_page']);
		add_submenu_page('', __('Scan', 'freesiem-sentinel'), __('Scan', 'freesiem-sentinel'), 'manage_options', 'freesiem-scan', [$this, 'render_scan_page']);
	}

	public function remove_synchy_top_level_menu(): void
	{
		if (!function_exists('synchy_get_pages')) {
			return;
		}

		remove_menu_page('synchy');

		foreach (synchy_get_pages() as $page) {
			$slug = sanitize_key((string) ($page['slug'] ?? ''));
			if ($slug !== '') {
				remove_menu_page($slug);
				remove_submenu_page('synchy', $slug);
				remove_submenu_page($slug, $slug);
			}
		}
	}

	public function maybe_redirect_legacy_synchy_pages(): void
	{
		if (!is_admin() || !current_user_can('manage_options')) {
			return;
		}

		$page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';
		$tab = $this->get_synchy_tab_for_legacy_page($page);

		if ($tab === '') {
			return;
		}

		if ($page === FREESIEM_SENTINEL_SYNCHY_PAGE) {
			return;
		}

		wp_safe_redirect(
			add_query_arg(
				[
					'page' => FREESIEM_SENTINEL_SYNCHY_PAGE,
					'tab' => $tab,
				],
				admin_url('admin.php')
			)
		);
		exit;
	}

	public function maybe_redirect_legacy_about_page(): void
	{
		if (!is_admin() || !current_user_can('manage_options')) {
			return;
		}

		$page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';

		if ($page !== 'freesiem-about') {
			return;
		}

		wp_safe_redirect(freesiem_sentinel_admin_page_url('freesiem-settings', ['tab' => 'about']));
		exit;
	}

	public function maybe_auto_update_from_settings_page(): void
	{
		if (!is_admin() || !current_user_can('manage_options')) {
			return;
		}

		$page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';

		if ($page !== 'freesiem-settings') {
			return;
		}

		$updater = $this->plugin->get_updater();
		$result = $updater->refresh_plugin_update_state();
		$this->settings_update_check = $result;

		if (is_wp_error($result)) {
			return;
		}

		$release = is_array($result['release'] ?? null) ? $result['release'] : [];
		$version = safe($release['version'] ?? '');

		if (empty($result['update_available']) || $version === '') {
			return;
		}

		// A newer packaged release exists -- hand off to the real update flow immediately instead
		// of waiting for an explicit "Update Plugin" click, per "clicking Settings should test and
		// update my plugin". Reuses the exact same admin-post handler (and WP core upgrade screen)
		// the manual button uses; it just fires automatically here.
		wp_safe_redirect($updater->get_update_plugin_url(freesiem_sentinel_admin_page_url('freesiem-settings', ['tab' => 'about'])));
		exit;
	}

	public function maybe_enqueue_synchy_assets(string $hook_suffix): void
	{
		$page = isset($_GET['page']) ? sanitize_key((string) wp_unslash($_GET['page'])) : '';

		// Security and Activity reuse the same header/tab-nav CSS (freesiem-synchy-* classes) as
		// Backup & Restore for their own colorful tab nav -- they just don't need
		// synchy-runtime.php loaded, unlike the actual Backup & Restore page.
		if (in_array($page, ['freesiem-security', 'freesiem-activity'], true)) {
			$style_path = $this->get_synchy_asset_path('admin.css');
			$style_url = $style_path !== '' ? $this->get_synchy_asset_url('admin.css') : '';

			if ($style_path !== '' && $style_url !== '' && file_exists($style_path)) {
				wp_enqueue_style('synchy-admin', $style_url, [], (string) filemtime($style_path));
			}

			return;
		}

		if ($page !== FREESIEM_SENTINEL_SYNCHY_PAGE || !function_exists('synchy_get_site_sync_options')) {
			return;
		}

		$tab = $this->get_synchy_current_tab();
		$style_path = $this->get_synchy_asset_path('admin.css');
		$style_url = $this->get_synchy_asset_url('admin.css');

		if ($style_path !== '' && $style_url !== '' && file_exists($style_path)) {
			wp_enqueue_style('synchy-admin', $style_url, [], (string) filemtime($style_path));
		}

		if ($tab === 'upload-live') {
			$script_path = $this->get_synchy_asset_path('site-sync.js');
			$script_url = $this->get_synchy_asset_url('site-sync.js');

			if ($script_path !== '' && $script_url !== '' && file_exists($script_path)) {
				wp_enqueue_script('synchy-site-sync', $script_url, [], (string) filemtime($script_path), true);
				wp_localize_script(
					'synchy-site-sync',
					'synchySiteSyncConfig',
					[
						'ajaxUrl' => admin_url('admin-ajax.php'),
						'nonce' => wp_create_nonce('synchy_site_sync_ajax'),
						'currentJob' => synchy_build_site_sync_job_response(synchy_get_running_site_sync_job()),
						'defaultStages' => synchy_get_site_sync_stage_items([]),
						'strings' => [
							'uploaded' => __('Uploaded', 'synchy'),
							'timeSpent' => __('Time spent', 'synchy'),
							'timeRemaining' => __('Time remaining', 'synchy'),
							'completedIn' => __('Completed in', 'synchy'),
							'connectionReady' => __('Connection ready', 'synchy'),
							'connectionError' => __('Connection failed', 'synchy'),
							'pushAction' => __('Upload to Live', 'synchy'),
							'unknownError' => __('Synchy hit an unexpected live push error.', 'synchy'),
						],
					]
				);
			}

			return;
		}

		if ($tab === 'sync') {
			$script_path = $this->get_synchy_asset_path('sync.js');
			$script_url = $this->get_synchy_asset_url('sync.js');

			if ($script_path !== '' && $script_url !== '' && file_exists($script_path)) {
				wp_enqueue_script('synchy-sync', $script_url, [], (string) filemtime($script_path), true);
				wp_localize_script(
					'synchy-sync',
					'synchySyncConfig',
					[
						'ajaxUrl' => admin_url('admin-ajax.php'),
						'nonce' => wp_create_nonce('synchy_sync_ajax'),
						'localPluginVersion' => FREESIEM_SENTINEL_VERSION,
						'currentJob' => synchy_build_sync_job_response(synchy_get_visible_sync_job()),
						'connectionState' => synchy_get_current_sync_connection_state(synchy_get_site_sync_options()),
						'defaultStages' => synchy_get_sync_stage_items([]),
						'scopeStatus' => synchy_get_sync_scope_status(synchy_get_site_sync_options()),
						'strings' => [
							'connectionReady' => __('Connection ready', 'synchy'),
							'connectionError' => __('Connection failed', 'synchy'),
							'connected' => __('Connected', 'synchy'),
							'failed' => __('Failed', 'synchy'),
							'needsRetest' => __('Needs retest', 'synchy'),
							'notChecked' => __('Not checked', 'synchy'),
							'incomplete' => __('Incomplete', 'synchy'),
							'previewReady' => __('Preview ready', 'synchy'),
							'previewError' => __('Preview failed', 'synchy'),
							'startBaseline' => __('Start Baseline', 'synchy'),
							'startFullSync' => __('Run Full Sync', 'synchy'),
							'pushChanges' => __('Push', 'synchy'),
							'confirmSyncTitle' => __('Push changes?', 'synchy'),
							'confirmFullSyncTitle' => __('Run Full Sync?', 'synchy'),
							'loadingRows' => __('Loading row content...', 'synchy'),
							'noPendingRows' => __('Nothing to show -- no database rows are pending.', 'synchy'),
							'fullSync' => __('Full Sync', 'synchy'),
							'pauseSync' => __('Pause Sync', 'synchy'),
							'resumeSync' => __('Resume Sync', 'synchy'),
							'resetSync' => __('Cancel', 'synchy'),
							'markManualBaseline' => __('Set Baseline', 'synchy'),
							'confirmResetSync' => __('Cancel the saved Sync job and clear local Sync baseline state? This does not change the destination site.', 'synchy'),
							'resetComplete' => __('Sync state reset. Run Full Sync to start fresh.', 'synchy'),
							'preparingPreview' => __('Preparing preview...', 'synchy'),
							'preparingFullPreview' => __('Preparing full Sync preview...', 'synchy'),
							'syncingAction' => __('Syncing...', 'synchy'),
							'paused' => __('Paused', 'synchy'),
							'resumeReady' => __('Resume ready', 'synchy'),
							'success' => __('Success', 'synchy'),
							'error' => __('Error', 'synchy'),
							'noChanges' => __('No changes', 'synchy'),
							'awaitingBaseline' => __('Awaiting baseline', 'synchy'),
							'baseline' => __('Baseline', 'synchy'),
							'delta' => __('Delta', 'synchy'),
							'lastRun' => __('Last run', 'synchy'),
							'lastSync' => __('Last successful Sync', 'synchy'),
							'destination' => __('Destination', 'synchy'),
							'localPluginVersion' => __('Local Sentinel version', 'synchy'),
							'files' => __('Files', 'synchy'),
							'dbRows' => __('DB rows', 'synchy'),
							'duration' => __('Duration', 'synchy'),
							'site' => __('Site', 'synchy'),
							'pluginVersion' => __('Sentinel version', 'synchy'),
							'authenticatedAs' => __('Authenticated as', 'synchy'),
							'selectedScopes' => __('Selected scopes', 'synchy'),
							'needsBaseline' => __('Needs baseline', 'synchy'),
							'pendingBaseline' => __('Still need baseline', 'synchy'),
							'pendingChanges' => __('Pending changes', 'synchy'),
							'readyForPreview' => __('Ready for preview', 'synchy'),
							'noChangesInScope' => __('No changes', 'synchy'),
							'changedFiles' => __('Changed files', 'synchy'),
							'dbTables' => __('Database tables', 'synchy'),
							'previewSelectionTitle' => __('Pending Changes', 'synchy'),
							'previewSelectionHelp' => __('Review the pending file sections and database tables, then uncheck anything you do not want to send.', 'synchy'),
							'sampleRowIds' => __('Sample row IDs', 'synchy'),
							'syncRunning' => __('Sync running', 'synchy'),
							'selectedChanges' => __('Selected changes', 'synchy'),
							'tableUpdates' => __('Table updates', 'synchy'),
							'sampleFiles' => __('Sample files', 'synchy'),
							'never' => __('Never', 'synchy'),
							'na' => __('N/A', 'synchy'),
							'previewDefault' => __('Run Preview to review changed files and database rows before syncing.', 'synchy'),
							'unknownError' => __('Synchy hit an unexpected Sync error.', 'synchy'),
							'confirmSync' => __('Sync the previewed changes to the destination site now?', 'synchy'),
							'confirmFullSync' => __('Run a full Sync for the selected scopes and send all tracked files and rows to the destination site now?', 'synchy'),
							'confirmResumeSync' => __('Resume the remaining full Sync batches now?', 'synchy'),
							'confirmBaseline' => __('Mark the selected scopes as already baselined after a successful manual full restore to the destination site?', 'synchy'),
							'selectAtLeastOneScope' => __('Select at least one file or database scope first.', 'synchy'),
							'batches' => __('Batches', 'synchy'),
							'batchesComplete' => __('batches complete', 'synchy'),
							'currentBatch' => __('Current batch', 'synchy'),
							'pausePending' => __('Pause requested', 'synchy'),
							'updateAvailable' => __('Destination update available:', 'synchy'),
							'destinationUpToDate' => __('Destination Sentinel is up to date.', 'synchy'),
							'updateCheckPending' => __('Run or wait for the connection check to compare Sentinel versions.', 'synchy'),
							'confirmUpdateRemoteSynchy' => __('Update Sentinel on the destination site from this local plugin copy now?', 'synchy'),
							'updatingDestination' => __('Updating destination Sentinel...', 'synchy'),
							'updatingDestinationDetail' => __('Building a plugin package locally and sending it to the destination site.', 'synchy'),
							'destinationUpdated' => __('Destination Sentinel updated.', 'synchy'),
						],
					]
				);
			}

			return;
		}

		if ($tab !== 'export') {
			return;
		}

		$script_path = $this->get_synchy_asset_path('export.js');
		$script_url = $this->get_synchy_asset_url('export.js');

		if ($script_path !== '' && $script_url !== '' && file_exists($script_path)) {
			wp_enqueue_script('synchy-export', $script_url, [], (string) filemtime($script_path), true);
			wp_localize_script(
				'synchy-export',
				'synchyExportConfig',
				[
					'ajaxUrl' => admin_url('admin-ajax.php'),
					'nonce' => wp_create_nonce('synchy_export_ajax'),
					'currentJob' => synchy_build_job_response(synchy_get_running_export_job()),
					'defaultPackageName' => synchy_get_default_package_name(),
					'defaultStages' => synchy_get_export_stage_items([]),
					'strings' => [
						'filesProcessed' => __('Files processed:', 'synchy'),
						'unknownError' => __('Synchy hit an unexpected error while exporting.', 'synchy'),
						'preparingLabel' => __('Preparing', 'synchy'),
						'startingExport' => __('Starting export job...', 'synchy'),
						'errorPhaseLabel' => __('Error', 'synchy'),
						'completeTitle' => __('Backup complete', 'synchy'),
						'errorTitle' => __('Backup needs attention', 'synchy'),
					],
				]
			);
		}
	}

	public function handle_save_cloud_connect_contact(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$email = isset($_POST['email']) ? sanitize_email(wp_unslash((string) $_POST['email'])) : '';
		$phone = isset($_POST['phone']) ? freesiem_sentinel_sanitize_phone_number(wp_unslash((string) $_POST['phone'])) : '';

		if (!is_email($email)) {
			freesiem_sentinel_set_notice('error', __('Enter a valid email address to save.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-remote');
		}

		if ($phone === '') {
			freesiem_sentinel_set_notice('error', __('Enter a valid US phone number to save.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-remote');
		}

		freesiem_sentinel_update_settings(['email' => $email, 'phone' => $phone]);

		freesiem_sentinel_set_notice('success', __('Cloud contact details saved locally.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_cloud_connect_start(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$settings = freesiem_sentinel_get_settings();
		$email = sanitize_email((string) ($settings['email'] ?? ''));
		$phone = freesiem_sentinel_sanitize_phone_number((string) ($settings['phone'] ?? ''));

		if (!is_email($email)) {
			freesiem_sentinel_set_notice('error', __('Enter a valid email address to continue.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-remote');
		}

		if ($phone === '') {
			freesiem_sentinel_set_notice('error', __('Enter a valid US phone number to continue.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-remote');
		}

		$result = $this->plugin->start_cloud_connect($email, $phone);

		if (is_wp_error($result)) {
			freesiem_sentinel_set_notice('error', $result->get_error_message());
			$this->redirect_to_page('freesiem-remote');
		}

		freesiem_sentinel_set_notice('success', __('Verification code sent. Enter it below to finish connecting this site.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_cloud_connect_verify(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$code = isset($_POST['verification_code']) ? preg_replace('/\D+/', '', wp_unslash((string) $_POST['verification_code'])) : '';
		$code = is_string($code) ? $code : '';

		if ($code === '') {
			freesiem_sentinel_set_notice('error', __('Enter the verification code to continue.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-remote');
		}

		$result = $this->plugin->verify_cloud_connect($code);

		if (is_wp_error($result)) {
			freesiem_sentinel_set_notice('error', $result->get_error_message());
			$this->redirect_to_page('freesiem-remote');
		}

		freesiem_sentinel_set_notice('success', __('freeSIEM Cloud Connect is now active for this site.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_cloud_connect_reset(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		Freesiem_Cloud_Connect_State::reset_pending();
		freesiem_sentinel_set_notice('success', __('Pending verification was canceled and the local connect state was reset.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_cloud_connect_test(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$result = $this->plugin->test_connection();
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('Connection test completed successfully.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_cloud_connect_disconnect(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$result = $this->plugin->disconnect_cloud_connect();
		if (is_wp_error($result)) {
			freesiem_sentinel_set_notice('error', $result->get_error_message());
		} elseif (!empty($result['local_only'])) {
			freesiem_sentinel_set_notice('warning', sprintf(__('Local Cloud credentials were cleared, but freeSIEM Core responded with: %s', 'freesiem-sentinel'), $result['message'] ?? __('request rejected', 'freesiem-sentinel')));
		} else {
			freesiem_sentinel_set_notice('success', __('Disconnected from freeSIEM Cloud Connect.', 'freesiem-sentinel'));
		}
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_save_settings(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$current = freesiem_sentinel_get_settings();
		$email = isset($_POST['email']) ? sanitize_email(wp_unslash((string) $_POST['email'])) : '';
		$backend_url_raw = isset($_POST['backend_url']) ? wp_unslash((string) $_POST['backend_url']) : '';
		$backend_url = trim($backend_url_raw) === ''
			? freesiem_sentinel_safe_string($current['backend_url'] ?? FREESIEM_SENTINEL_BACKEND_URL)
			: freesiem_sentinel_sanitize_backend_url($backend_url_raw);

		$settings = freesiem_sentinel_update_settings([
			'email' => $email,
			'backend_url' => $backend_url,
		]);

		if ($email === '') {
			freesiem_sentinel_set_notice('error', __('Email is required to register this site with freeSIEM Core.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-remote');
		}

		$result = $this->plugin->register_site($settings['email']);

		if (is_wp_error($result)) {
			freesiem_sentinel_set_notice('error', $result->get_error_message());
			$this->redirect_to_page('freesiem-remote');
		}

		freesiem_sentinel_set_notice('success', __('Site registration completed successfully.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_run_configured_scan(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$options = $this->sanitize_scan_preferences($_POST);
		freesiem_sentinel_update_settings(['scan_preferences' => $options]);

		$result = $this->plugin->run_local_scan_with_options(true, $options);
		$is_error = is_wp_error($result) || (is_array($result) && ($result['status'] ?? '') === 'error');
		$message = is_wp_error($result) ? $result->get_error_message() : safe($result['message'] ?? __('Configuration scan completed.', 'freesiem-sentinel'));
		$upload = is_array($result) ? freesiem_sentinel_safe_array($result['upload'] ?? []) : [];

		$deep_enabled = !empty($options['scan_malware']) || !empty($options['scan_core_integrity']) || !empty($options['scan_plugin_integrity']) || !empty($options['scan_database']);

		if (!$is_error && $deep_enabled) {
			$deep = $this->plugin->get_deep_scanner();
			$deep->start($options);
			$pass = $deep->run_foreground_pass();

			if (!empty($pass['done'])) {
				$progress = $pass['progress'];
				$message = sprintf(
					/* translators: 1: files scanned, 2: malware hits */
					__('Deep scan complete — %1$s files inspected, %2$s signature hit(s). See findings below.', 'freesiem-sentinel'),
					number_format_i18n((int) ($progress['files_scanned'] ?? 0)),
					number_format_i18n((int) ($progress['malware_hits'] ?? 0))
				);
			} else {
				$message = sprintf(
					/* translators: %s: percent complete */
					__('Deep scan started (%s%% complete) and is continuing in the background. This page refreshes with progress; findings appear as they are confirmed.', 'freesiem-sentinel'),
					number_format_i18n((int) ($pass['progress']['percent'] ?? 0))
				);
			}
		}

		$notice_type = $is_error ? 'error' : 'success';

		// Only surface an upload problem the admin can actually act on. "Cloud sync
		// not provisioned on freeSIEM Core" (404/405) and "cloud upload turned off"
		// are normal local-only operation — say nothing.
		if (!$is_error && $upload !== [] && empty($upload['ok']) && empty($upload['unavailable']) && empty($upload['skipped'])) {
			$notice_type = 'warning';
			$message .= ' ' . sprintf(
				/* translators: %s: upload error detail */
				__('Results are saved locally, but the upload to freeSIEM Core failed: %s', 'freesiem-sentinel'),
				(string) ($upload['error'] ?? '')
			);
		}

		freesiem_sentinel_set_notice($notice_type, $message);
		$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
	}

	/**
	 * AJAX: advance the running deep scan by one throttled slice and report progress.
	 *
	 * The Scan screen polls this while a scan is in progress so coverage advances
	 * from the browser instead of depending solely on WP-Cron (which is unreliable
	 * on low-traffic or DISABLE_WP_CRON installs).
	 */
	public function handle_deep_scan_tick(): void
	{
		if (!current_user_can('manage_options')) {
			wp_send_json_error(['message' => 'forbidden'], 403);
		}

		check_ajax_referer('freesiem_sentinel_deep_scan_tick', 'nonce');

		$deep = $this->plugin->get_deep_scanner();

		if ($deep->is_running()) {
			$deep->run_tick();
		}

		wp_send_json_success($deep->progress());
	}

	public function handle_abort_deep_scan(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		$this->plugin->get_deep_scanner()->abort();
		freesiem_sentinel_set_notice('success', __('The running deep scan and its queued continuation were stopped.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-scan');
	}

	public function handle_clear_cron_history(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		$this->plugin->get_cron_monitor()->clear_history();
		freesiem_sentinel_set_notice('success', __('WP-Cron execution history cleared.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-security', ['section' => 'wp-cron']);
	}

	public function handle_request_remote_scan(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		$result = $this->plugin->request_remote_scan();
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('Remote scan request sent.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_save_scan_schedule(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		freesiem_sentinel_update_settings([
			'deep_scan_weekly_enabled' => empty($_POST['deep_scan_weekly_enabled']) ? 0 : 1,
			'deep_scan_weekly_day' => in_array((int) ($_POST['deep_scan_weekly_day'] ?? -1), [-1, 0, 1, 2, 3, 4, 5, 6], true) ? (int) $_POST['deep_scan_weekly_day'] : -1,
			'scan_email_on_weekly' => empty($_POST['scan_email_on_weekly']) ? 0 : 1,
			'report_primary_email' => isset($_POST['report_primary_email']) ? sanitize_email(wp_unslash((string) $_POST['report_primary_email'])) : '',
			'scan_email_recipients' => isset($_POST['scan_email_recipients']) ? sanitize_textarea_field(wp_unslash((string) $_POST['scan_email_recipients'])) : '',
		]);

		freesiem_sentinel_reschedule_weekly_scan();

		$next = wp_next_scheduled(Freesiem_Cron::WEEKLY_DEEP_SCAN_HOOK);
		$message = $next
			? sprintf(__('Report and schedule settings saved. Next weekly full scan: %s.', 'freesiem-sentinel'), freesiem_sentinel_format_datetime(gmdate('c', (int) $next)))
			: __('Report settings saved. The weekly full scan is turned off.', 'freesiem-sentinel');

		freesiem_sentinel_set_notice('success', $message);
		$this->redirect_to_page('freesiem-scan');
	}

	public function handle_email_scan_results(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$extra = isset($_POST['extra_recipients'])
			? array_filter(array_map('sanitize_email', preg_split('/[\s,;]+/', wp_unslash((string) $_POST['extra_recipients'])) ?: []))
			: [];

		$result = freesiem_sentinel_send_scan_report_email($extra, 'manual');

		freesiem_sentinel_set_notice(
			is_wp_error($result) ? 'error' : 'success',
			is_wp_error($result) ? $result->get_error_message() : __('Scan report emailed.', 'freesiem-sentinel')
		);
		$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
	}

	/**
	 * Stream the scan findings as a downloadable file. GET with a nonce
	 * (?format=json|csv, optional ?scan_run=<id> for a historical run).
	 */
	public function handle_export_results(): void
	{
		if (!current_user_can('manage_options')) {
			wp_die(esc_html__('You do not have permission to export scan results.', 'freesiem-sentinel'), '', ['response' => 403]);
		}

		check_admin_referer(FREESIEM_SENTINEL_NONCE_ACTION);

		$format = strtolower(isset($_GET['format']) ? sanitize_key(wp_unslash($_GET['format'])) : 'json');
		$format = in_array($format, ['json', 'csv'], true) ? $format : 'json';
		$run_id = isset($_GET['scan_run']) ? sanitize_text_field(wp_unslash((string) $_GET['scan_run'])) : '';

		$results = $this->plugin->get_results();

		if ($run_id !== '') {
			$run = $results->get_scan_run($run_id);

			if ($run === null) {
				wp_die(esc_html__('That scan run is no longer available for export.', 'freesiem-sentinel'));
			}

			$findings = array_values(array_filter((array) ($run['findings'] ?? []), 'is_array'));
			$meta = freesiem_sentinel_safe_array($run['meta'] ?? []);
			$scanned_at = (string) ($meta['finished_at'] ?? '');
			$score = (int) ($meta['score'] ?? freesiem_sentinel_score_from_findings($findings));
			$counts = freesiem_sentinel_safe_array($meta['severity_counts'] ?? []);
			$label = 'run-' . $run_id;
			$scan = [
				'status' => !empty($meta['partial']) ? 'partial' : 'complete',
				'scan_type' => (string) ($meta['type'] ?? 'deep') . (!empty($meta['full']) ? ' (full)' : ''),
				'files_content_scanned' => (int) ($meta['files_scanned'] ?? 0),
				'malware_hits' => (int) ($meta['malware_hits'] ?? 0),
				'core_files_modified' => (int) ($meta['core_files_modified'] ?? 0),
				'plugin_files_modified' => (int) ($meta['plugin_files_modified'] ?? 0),
				'database_issues' => (int) ($meta['database_issues'] ?? 0),
			];
		} else {
			$cache = $results->get_cache();
			$findings = array_values(array_filter(freesiem_sentinel_safe_array($cache['local_findings'] ?? []), 'is_array'));
			$summary = freesiem_sentinel_safe_array($cache['summary'] ?? []);
			$scanned_at = (string) ($summary['last_deep_scan_at'] ?? ($summary['last_local_scan_at'] ?? ''));
			$score = (int) ($summary['local_score'] ?? freesiem_sentinel_score_from_findings($findings));
			$counts = freesiem_sentinel_safe_array($cache['severity_counts'] ?? []);
			$label = 'current';

			$running = $this->plugin->get_deep_scanner()->is_running();
			$scan = [
				'status' => $running ? 'in_progress' : (!empty($summary['deep_scan_partial']) ? 'partial' : 'complete'),
				'scan_type' => 'deep',
				'modules' => array_values((array) ($summary['scan_modules'] ?? [])),
				'files_discovered' => (int) ($summary['files_discovered'] ?? 0),
				'files_heuristic_scanned' => (int) ($summary['files_analyzed'] ?? 0),
				'files_content_scanned' => (int) ($summary['files_content_scanned'] ?? 0),
				'bytes_scanned' => (int) ($summary['bytes_scanned'] ?? 0),
				'malware_hits' => (int) ($summary['malware_hits'] ?? 0),
				'core_files_modified' => (int) ($summary['core_files_modified'] ?? 0),
				'plugin_files_modified' => (int) ($summary['plugin_files_modified'] ?? 0),
				'database_issues' => (int) ($summary['database_issues'] ?? 0),
				'last_deep_scan_at' => (string) ($summary['last_deep_scan_at'] ?? ''),
			];
		}

		$export = freesiem_sentinel_build_scan_export($format, [
			'findings' => $findings,
			'scanned_at' => $scanned_at,
			'score' => $score,
			'severity_counts' => $counts,
			'scan' => $scan,
			'label' => $label,
		]);

		nocache_headers();
		header('Content-Type: ' . $export['mime']);
		header('Content-Disposition: attachment; filename="' . $export['filename'] . '"');
		header('Content-Length: ' . strlen($export['body']));
		echo $export['body']; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	public function handle_run_full_scan_now(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$deep = $this->plugin->get_deep_scanner();
		if ($deep->is_running()) {
			freesiem_sentinel_set_notice('warning', __('A deep scan is already running. Stop it before starting another full scan.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan');
		}
		$deep->start_full('deep');
		$pass = $deep->run_foreground_pass();

		freesiem_sentinel_set_notice('success', !empty($pass['done'])
			? __('Full scan complete. See findings below.', 'freesiem-sentinel')
			: sprintf(__('Full scan started (%s%% complete) and is continuing — keep this tab open or let WP-Cron finish it.', 'freesiem-sentinel'), number_format_i18n((int) ($pass['progress']['percent'] ?? 0))));
		$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
	}

	public function handle_clear_results(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		$this->plugin->clear_scan_results();
		freesiem_sentinel_set_notice('success', __('Stored scan results were cleared.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-scan');
	}

	/**
	 * The relative path carried by the finding whose reference was POSTed, so a
	 * file action can only ever touch a path that actually appears in a finding.
	 */
	private function posted_finding_path(): array
	{
		$reference = isset($_POST['finding']) ? sanitize_text_field(wp_unslash((string) $_POST['finding'])) : '';
		$cache = $this->plugin->get_results()->get_cache();
		$findings = array_values(freesiem_sentinel_safe_array($cache['local_findings'] ?? []));
		$finding = $reference !== '' ? $this->find_finding_by_reference($findings, $reference) : null;
		$path = is_array($finding) ? freesiem_sentinel_safe_string($finding['evidence']['path'] ?? '') : '';

		return ['reference' => $reference, 'path' => $path];
	}

	private function redirect_after_file_action(string $reference): void
	{
		$args = ['show_results' => '1'];

		if ($reference !== '') {
			$args['finding'] = $reference;
		}

		$this->redirect_to_page('freesiem-scan', $args);
	}

	public function handle_quarantine_file(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		if (!Freesiem_File_Actions::can_act()) {
			freesiem_sentinel_set_notice('error', __('File actions are disabled on this site.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		['reference' => $reference, 'path' => $path] = $this->posted_finding_path();

		if ($path === '') {
			freesiem_sentinel_set_notice('error', __('That finding is no longer available.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		$result = Freesiem_File_Actions::quarantine($path);

		freesiem_sentinel_set_notice(
			is_wp_error($result) ? 'error' : 'success',
			is_wp_error($result)
				? $result->get_error_message()
				: sprintf(__('Moved %s to quarantine. Re-run the scan to confirm it is gone.', 'freesiem-sentinel'), $path)
		);
		$this->redirect_after_file_action($reference);
	}

	public function handle_delete_file(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		if (!Freesiem_File_Actions::can_act()) {
			freesiem_sentinel_set_notice('error', __('File actions are disabled on this site.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		$quarantine_id = isset($_POST['quarantine_id']) ? sanitize_text_field(wp_unslash((string) $_POST['quarantine_id'])) : '';

		if ($quarantine_id !== '') {
			$result = Freesiem_File_Actions::delete($quarantine_id);
			freesiem_sentinel_set_notice(
				is_wp_error($result) ? 'error' : 'success',
				is_wp_error($result) ? $result->get_error_message() : __('Quarantined copy permanently deleted.', 'freesiem-sentinel')
			);
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		['reference' => $reference, 'path' => $path] = $this->posted_finding_path();

		if ($path === '') {
			freesiem_sentinel_set_notice('error', __('That finding is no longer available.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		$result = Freesiem_File_Actions::delete($path);

		freesiem_sentinel_set_notice(
			is_wp_error($result) ? 'error' : 'success',
			is_wp_error($result) ? $result->get_error_message() : sprintf(__('Deleted %s.', 'freesiem-sentinel'), $path)
		);
		$this->redirect_after_file_action(is_wp_error($result) ? $reference : '');
	}

	public function handle_restore_file(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		if (!Freesiem_File_Actions::can_act()) {
			freesiem_sentinel_set_notice('error', __('File actions are disabled on this site.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		$id = isset($_POST['quarantine_id']) ? sanitize_text_field(wp_unslash((string) $_POST['quarantine_id'])) : '';
		$result = $id !== '' ? Freesiem_File_Actions::restore($id) : new WP_Error('freesiem_no_id', __('No quarantine item was specified.', 'freesiem-sentinel'));

		freesiem_sentinel_set_notice(
			is_wp_error($result) ? 'error' : 'success',
			is_wp_error($result) ? $result->get_error_message() : __('File restored to its original location.', 'freesiem-sentinel')
		);
		$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
	}

	public function handle_mark_finding_safe(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		if (!Freesiem_Acknowledgements::can_manage()) {
			freesiem_sentinel_set_notice('error', __('Marking findings as safe is disabled on this site.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		['reference' => $reference, 'finding' => $finding] = $this->posted_finding();
		$note = isset($_POST['ack_note']) ? sanitize_textarea_field(wp_unslash((string) $_POST['ack_note'])) : '';

		if (!is_array($finding)) {
			freesiem_sentinel_set_notice('error', __('That finding is no longer available.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		$user = wp_get_current_user();
		$result = Freesiem_Acknowledgements::add($finding, $note, (string) ($user->user_login ?? ''), (int) ($user->ID ?? 0));

		if (is_wp_error($result)) {
			freesiem_sentinel_set_notice('error', $result->get_error_message());
			$this->redirect_after_file_action($reference);
		}

		$this->plugin->get_results()->reapply_acknowledgements();
		freesiem_sentinel_set_notice('success', __('Finding marked as safe. It is excluded from the score and counts, and will return automatically if the file changes.', 'freesiem-sentinel'));
		$this->redirect_after_file_action($reference);
	}

	public function handle_unmark_finding_safe(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$user = wp_get_current_user();
		$finding_key = isset($_POST['finding_key']) ? sanitize_text_field(wp_unslash((string) $_POST['finding_key'])) : '';
		['reference' => $reference, 'finding' => $finding] = $this->posted_finding();

		if ($finding_key === '' && is_array($finding)) {
			$finding_key = freesiem_sentinel_safe_string($finding['finding_key'] ?? '');
		}

		if ($finding_key === '') {
			freesiem_sentinel_set_notice('error', __('That safe mark is no longer available.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
		}

		Freesiem_Acknowledgements::remove($finding_key, (string) ($user->user_login ?? ''));
		$this->plugin->get_results()->reapply_acknowledgements();
		freesiem_sentinel_set_notice('success', __('Safe mark removed. The finding is active again.', 'freesiem-sentinel'));
		$this->redirect_after_file_action($reference);
	}

	public function handle_clear_safe_marks(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$user = wp_get_current_user();
		$removed = Freesiem_Acknowledgements::clear_all((string) ($user->user_login ?? ''));
		$this->plugin->get_results()->reapply_acknowledgements();
		freesiem_sentinel_set_notice(
			'success',
			$removed > 0
				? sprintf(_n('Cleared %d safe mark.', 'Cleared %d safe marks.', $removed, 'freesiem-sentinel'), $removed)
				: __('There were no safe marks to clear.', 'freesiem-sentinel')
		);
		$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
	}

	/**
	 * Resolve the POSTed finding reference to the finding it names, searching
	 * the full stored set (acknowledged findings included).
	 *
	 * @return array{reference:string,finding:?array}
	 */
	private function posted_finding(): array
	{
		$reference = isset($_POST['finding']) ? sanitize_text_field(wp_unslash((string) $_POST['finding'])) : '';
		$cache = $this->plugin->get_results()->get_cache();
		$findings = array_values(freesiem_sentinel_safe_array($cache['local_findings'] ?? []));
		$finding = $reference !== '' ? $this->find_finding_by_reference($findings, $reference) : null;

		return ['reference' => $reference, 'finding' => is_array($finding) ? $finding : null];
	}

	public function handle_start_cloud_connect(): void
	{
		$_POST['phone'] = $_POST['phone_number'] ?? '';
		$this->handle_cloud_connect_start();
	}

	public function handle_verify_cloud_connect(): void
	{
		$_POST['verification_code'] = $_POST['confirmation_code'] ?? '';
		$this->handle_cloud_connect_verify();
	}

	public function handle_save_cloud_preferences(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$preferences = [
			'allow_remote_scan' => empty($_POST['allow_remote_scan']) ? 0 : 1,
			'scan_frequency' => isset($_POST['scan_frequency']) ? sanitize_key(wp_unslash((string) $_POST['scan_frequency'])) : 'daily',
			'user_sync_enabled' => empty($_POST['user_sync_enabled']) ? 0 : 1,
			'enable_pending_task_queue' => empty($_POST['enable_pending_task_queue']) ? 0 : 1,
			'auto_approve_enabled_default' => empty($_POST['auto_approve_enabled_default']) ? 0 : 1,
			'auto_approve_after_minutes_default' => max(1, min(1440, (int) ($_POST['auto_approve_after_minutes_default'] ?? 30))),
			'require_manual_approval_for_list_users' => empty($_POST['require_manual_approval_for_list_users']) ? 0 : 1,
			'require_manual_approval_for_create_user' => empty($_POST['require_manual_approval_for_create_user']) ? 0 : 1,
			'require_manual_approval_for_update_user' => empty($_POST['require_manual_approval_for_update_user']) ? 0 : 1,
			'require_manual_approval_for_password_reset' => empty($_POST['require_manual_approval_for_password_reset']) ? 0 : 1,
			'require_manual_approval_for_delete_user' => empty($_POST['require_manual_approval_for_delete_user']) ? 0 : 1,
			'allow_auto_approve_list_users' => empty($_POST['allow_auto_approve_list_users']) ? 0 : 1,
			'allow_auto_approve_create_user' => empty($_POST['allow_auto_approve_create_user']) ? 0 : 1,
			'allow_auto_approve_update_user' => empty($_POST['allow_auto_approve_update_user']) ? 0 : 1,
			'allow_auto_approve_password_reset' => empty($_POST['allow_auto_approve_password_reset']) ? 0 : 1,
			'allow_auto_approve_delete_user' => empty($_POST['allow_auto_approve_delete_user']) ? 0 : 1,
			'notify_admins_on_pending_task' => empty($_POST['notify_admins_on_pending_task']) ? 0 : 1,
			'include_pending_tasks_in_heartbeat' => empty($_POST['include_pending_tasks_in_heartbeat']) ? 0 : 1,
			'heartbeat_include_recent_completed_tasks' => empty($_POST['heartbeat_include_recent_completed_tasks']) ? 0 : 1,
			'roles_allowed_to_approve_tasks' => isset($_POST['roles_allowed_to_approve_tasks']) && is_array($_POST['roles_allowed_to_approve_tasks'])
				? array_map(static fn($role): string => sanitize_key(wp_unslash((string) $role)), $_POST['roles_allowed_to_approve_tasks'])
				: ['administrator'],
		];
		$result = $this->plugin->save_cloud_preferences($preferences);

		if (is_wp_error($result)) {
			freesiem_sentinel_set_notice('warning', $result->get_error_message());
			$this->redirect_to_page('freesiem-remote');
		}

		$message = !empty($result['synced'])
			? __('Cloud automation preferences were saved and synced to freeSIEM Core.', 'freesiem-sentinel')
			: __('Cloud automation preferences were saved locally and will sync after connection.', 'freesiem-sentinel');
		freesiem_sentinel_set_notice('success', $message);
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_sync_results(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		$result = $this->plugin->sync_results();
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('Results synced from freeSIEM Core.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-scan', ['show_results' => '1']);
	}

	public function handle_reconnect(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		$result = $this->plugin->reconnect();
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('Site reconnected successfully.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-remote');
	}

	public function handle_disconnect_cloud(): void
	{
		$this->handle_cloud_connect_disconnect();
	}

	public function handle_test_connection(): void
	{
		$this->handle_cloud_connect_test();
	}

	public function handle_approve_task(): void
	{
		$this->assert_task_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$task_id = isset($_REQUEST['task_id']) ? (int) $_REQUEST['task_id'] : 0;
		$result = $this->plugin->get_pending_tasks()->approve_task($task_id, get_current_user_id());

		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('Pending task approved and executed locally.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-pending-tasks', ['task_id' => (string) $task_id]);
	}

	public function handle_deny_task(): void
	{
		$this->assert_task_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$task_id = isset($_REQUEST['task_id']) ? (int) $_REQUEST['task_id'] : 0;
		$reason = isset($_POST['deny_reason']) ? sanitize_textarea_field(wp_unslash((string) $_POST['deny_reason'])) : '';
		$result = $this->plugin->get_pending_tasks()->deny_task($task_id, get_current_user_id(), $reason);

		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('Pending task denied locally.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-pending-tasks', ['task_id' => (string) $task_id]);
	}

	public function handle_tfa_enroll(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$user_id = isset($_REQUEST['user_id']) ? (int) $_REQUEST['user_id'] : 0;
		$result = $this->plugin->get_tfa_service()->start_local_enrollment($user_id);
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('TFA enrollment is ready. Complete setup with the verification code below.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-tfa', ['user_id' => (string) $user_id]);
	}

	public function handle_tfa_reset(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$user_id = isset($_REQUEST['user_id']) ? (int) $_REQUEST['user_id'] : 0;
		$result = $this->plugin->get_tfa_service()->reset_local_tfa($user_id);
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('Local TFA was reset for the selected user.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-tfa', ['user_id' => (string) $user_id]);
	}

	public function handle_tfa_complete_setup(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$user_id = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
		$code = isset($_POST['tfa_code']) ? wp_unslash((string) $_POST['tfa_code']) : '';
		$result = $this->plugin->get_tfa_service()->complete_pending_setup($user_id, $code);
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('TFA is now enabled for the selected user.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-tfa', ['user_id' => (string) $user_id]);
	}

	public function handle_tfa_change_password(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$user_id = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
		$password = isset($_POST['password']) ? wp_unslash((string) $_POST['password']) : '';
		$result = $this->plugin->get_tfa_service()->change_local_password($user_id, $password);
		freesiem_sentinel_set_notice(is_wp_error($result) ? 'error' : 'success', is_wp_error($result) ? $result->get_error_message() : __('The local WordPress password was updated.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-tfa', ['user_id' => (string) $user_id]);
	}

	public function handle_save_ssl_settings(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$existing_settings = freesiem_sentinel_get_ssl_settings();
		$environment = freesiem_sentinel_get_ssl_environment_snapshot($existing_settings);
		$recommended_webroot = freesiem_sentinel_recommend_ssl_webroot_path($existing_settings, $environment);
		$submitted_webroot = isset($_POST['webroot_path']) ? trim((string) wp_unslash($_POST['webroot_path'])) : '';

		$settings_update = [
			'enable_management_ui' => 1,
			'acme_contact_email' => isset($_POST['acme_contact_email']) ? sanitize_email(wp_unslash((string) $_POST['acme_contact_email'])) : '',
			'hostname_override' => '',
			'allow_local_override' => 0,
			'challenge_method' => isset($_POST['challenge_method']) ? sanitize_key(wp_unslash((string) $_POST['challenge_method'])) : 'webroot-http-01',
			'webroot_path' => $submitted_webroot !== '' ? $submitted_webroot : $recommended_webroot,
			'check_port_80' => 1,
			'check_port_443' => 1,
			'force_https' => empty($_POST['force_https']) ? 0 : 1,
			'hsts_enabled' => empty($_POST['hsts_enabled']) ? 0 : 1,
			'auto_renew' => empty($_POST['auto_renew']) ? 0 : 1,
			'use_staging' => empty($_POST['use_staging']) ? 0 : 1,
			'detailed_logs' => empty($_POST['detailed_logs']) ? 0 : 1,
			'provider' => isset($_POST['provider']) ? sanitize_key(wp_unslash((string) $_POST['provider'])) : 'auto',
			'cpanel_username' => isset($_POST['cpanel_username']) ? sanitize_text_field(wp_unslash((string) $_POST['cpanel_username'])) : '',
			'cpanel_host_override' => isset($_POST['cpanel_host_override']) ? sanitize_text_field(wp_unslash((string) $_POST['cpanel_host_override'])) : '',
		];

		// Leave the token out of the update entirely when the field was left
		// blank, so a previously saved token is preserved instead of erased -
		// the same write-once masked-secret UX used for other credentials.
		$submitted_token = isset($_POST['cpanel_api_token']) ? trim(wp_unslash((string) $_POST['cpanel_api_token'])) : '';
		if ($submitted_token !== '') {
			$settings_update['cpanel_api_token'] = $submitted_token;
		}

		$settings = freesiem_sentinel_update_ssl_settings($settings_update);

		$readiness = freesiem_sentinel_calculate_ssl_readiness($settings);
		freesiem_sentinel_add_ssl_log(
			'info',
			__('SSL settings were saved.', 'freesiem-sentinel'),
			'settings',
			[
				'readiness_state' => $readiness['state'],
				'challenge_method' => (string) ($settings['challenge_method'] ?? 'webroot-http-01'),
				'force_https' => !empty($settings['force_https']) ? 'enabled' : 'disabled',
			]
		);
		freesiem_sentinel_add_ssl_log(
			'info',
			sprintf(__('SSL readiness recalculated: %s.', 'freesiem-sentinel'), $readiness['label']),
			'readiness',
			['readiness_state' => $readiness['state']]
		);
		freesiem_sentinel_set_notice('success', __('SSL settings saved.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-ssl', ['tab' => 'overview']);
	}

	public function handle_run_ssl_preflight(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$preflight = freesiem_sentinel_run_ssl_preflight();
		$readiness = freesiem_sentinel_calculate_ssl_readiness();
		freesiem_sentinel_add_ssl_log('info', $preflight['summary'] ?? __('SSL preflight was run.', 'freesiem-sentinel'), 'preflight', [
			'readiness_state' => $readiness['state'],
			'fail_count' => (string) ((int) ($preflight['counts']['fail'] ?? 0)),
		]);
		freesiem_sentinel_set_notice('success', $preflight['summary'] ?? __('SSL preflight completed.', 'freesiem-sentinel'));
		$redirect_tab = isset($_POST['redirect_tab']) ? sanitize_key((string) wp_unslash($_POST['redirect_tab'])) : 'preflight';
		$this->redirect_to_page('freesiem-ssl', ['tab' => in_array($redirect_tab, ['overview', 'preflight', 'dry-run', 'logs'], true) ? $redirect_tab : 'preflight']);
	}

	public function handle_run_ssl_dry_run(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$dry_run = freesiem_sentinel_run_ssl_dry_run();
		freesiem_sentinel_add_ssl_log('info', $dry_run['summary'] ?? __('SSL dry run validation completed.', 'freesiem-sentinel'), 'dry_run', [
			'readiness_state' => (string) ($dry_run['readiness_state'] ?? 'not_configured'),
			'would_attempt_status' => (string) (($dry_run['context']['would_attempt_status'] ?? 'warn')),
		]);
		freesiem_sentinel_set_notice('success', $dry_run['summary'] ?? __('SSL dry run validation completed.', 'freesiem-sentinel'));
		$redirect_tab = isset($_POST['redirect_tab']) ? sanitize_key((string) wp_unslash($_POST['redirect_tab'])) : 'dry-run';
		$this->redirect_to_page('freesiem-ssl', ['tab' => in_array($redirect_tab, ['overview', 'preflight', 'dry-run', 'logs'], true) ? $redirect_tab : 'dry-run']);
	}

	public function handle_issue_ssl_certificate(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		freesiem_sentinel_add_ssl_log('info', __('Issue certificate was requested from wp-admin.', 'freesiem-sentinel'), 'issue_request');
		$result = freesiem_sentinel_execute_ssl_issue();
		freesiem_sentinel_add_ssl_log($this->ssl_result_log_level((string) ($result['status'] ?? 'failed')), (string) ($result['summary'] ?? __('Certificate issuance completed.', 'freesiem-sentinel')), 'issue', [
			'status' => (string) ($result['status'] ?? 'failed'),
			'action_type' => (string) ($result['action_type'] ?? 'issue'),
			'result_code' => (string) ($result['result_code'] ?? ''),
			'force_reissue' => !empty($result['force_reissue']) ? 'yes' : 'no',
		]);

		if (!empty($result['verification']['status']) && in_array((string) $result['verification']['status'], ['warning', 'failed'], true)) {
			freesiem_sentinel_add_ssl_log($this->ssl_result_log_level((string) $result['verification']['status']), (string) ($result['verification']['summary'] ?? __('Certificate verification returned a warning.', 'freesiem-sentinel')), 'verification');
		}

		$notice_level = !empty($result['success']) ? 'success' : ((string) ($result['status'] ?? '') === 'warning' ? 'warning' : 'error');
		if ((string) ($result['status'] ?? '') === 'no_action_needed') {
			$notice_level = 'warning';
		}
		freesiem_sentinel_set_notice($notice_level, (string) ($result['summary'] ?? __('Certificate issuance completed.', 'freesiem-sentinel')));
		$this->redirect_to_page('freesiem-ssl', ['tab' => 'overview']);
	}

	public function handle_renew_ssl_certificate(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		freesiem_sentinel_add_ssl_log('info', __('Renew certificate was requested from wp-admin.', 'freesiem-sentinel'), 'renew_request');
		$result = freesiem_sentinel_execute_ssl_renew();
		freesiem_sentinel_add_ssl_log($this->ssl_result_log_level((string) ($result['status'] ?? 'failed')), (string) ($result['summary'] ?? __('Certificate renewal completed.', 'freesiem-sentinel')), 'renew', [
			'status' => (string) ($result['status'] ?? 'failed'),
			'action_type' => (string) ($result['action_type'] ?? 'renew'),
			'result_code' => (string) ($result['result_code'] ?? ''),
		]);

		if (!empty($result['verification']['status']) && in_array((string) $result['verification']['status'], ['warning', 'failed'], true)) {
			freesiem_sentinel_add_ssl_log($this->ssl_result_log_level((string) $result['verification']['status']), (string) ($result['verification']['summary'] ?? __('Certificate verification returned a warning.', 'freesiem-sentinel')), 'verification');
		}

		$notice_level = !empty($result['success']) ? 'success' : ((string) ($result['status'] ?? '') === 'warning' ? 'warning' : 'error');
		if ((string) ($result['status'] ?? '') === 'no_action_needed') {
			$notice_level = 'warning';
		}
		freesiem_sentinel_set_notice($notice_level, (string) ($result['summary'] ?? __('Certificate renewal completed.', 'freesiem-sentinel')));
		$this->redirect_to_page('freesiem-ssl', ['tab' => 'overview']);
	}

	public function handle_apply_ssl_to_nginx(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$ssl_settings = freesiem_sentinel_get_ssl_settings();
		$enable_redirect = !empty($ssl_settings['force_https']) || !empty($_POST['enable_nginx_https_redirect']);
		freesiem_sentinel_add_ssl_log('info', __('Apply SSL to nginx was requested from wp-admin.', 'freesiem-sentinel'), 'nginx_apply_attempt', [
			'redirect_enabled' => $enable_redirect ? 'yes' : 'no',
		]);

		$result = freesiem_sentinel_apply_ssl_to_nginx($enable_redirect);
		$apply_category = !empty($result['success']) ? 'nginx_apply_success' : (((string) ($result['status'] ?? '') === 'failed_rolled_back') ? 'nginx_rollback' : 'nginx_apply_failure');
		freesiem_sentinel_add_ssl_log($this->ssl_result_log_level((string) ($result['status'] ?? 'failed')), (string) ($result['summary'] ?? __('Nginx SSL apply completed.', 'freesiem-sentinel')), $apply_category, [
			'status' => (string) ($result['status'] ?? 'failed'),
			'target_path' => (string) (($result['integration']['target_path'] ?? '')),
			'backup_path' => (string) ($result['backup_path'] ?? ''),
			'confidence' => (string) (($result['integration']['detection_confidence'] ?? '')),
		]);

		if (!empty($result['test'])) {
			freesiem_sentinel_add_ssl_log(!empty($result['test']['success']) ? 'success' : 'error', !empty($result['test']['success']) ? __('Nginx syntax test passed.', 'freesiem-sentinel') : __('Nginx syntax test failed.', 'freesiem-sentinel'), 'nginx_test', [
				'result' => !empty($result['test']['stderr_summary']) ? (string) $result['test']['stderr_summary'] : (string) ($result['test']['stdout_summary'] ?? ''),
			]);
		}

		if (!empty($result['reload'])) {
			freesiem_sentinel_add_ssl_log(!empty($result['reload']['success']) ? 'success' : 'error', !empty($result['reload']['success']) ? __('Nginx reload completed.', 'freesiem-sentinel') : __('Nginx reload failed.', 'freesiem-sentinel'), 'nginx_reload', [
				'result' => !empty($result['reload']['stderr_summary']) ? (string) $result['reload']['stderr_summary'] : (string) ($result['reload']['stdout_summary'] ?? ''),
			]);
		}

		$notice = (string) ($result['summary'] ?? __('Nginx SSL apply completed.', 'freesiem-sentinel'));
		if ((string) ($result['status'] ?? '') === 'manual_required' && !empty($result['manual_commands']) && is_array($result['manual_commands'])) {
			$notice .= ' ' . sprintf(
				__('Run as root: %1$s ; %2$s', 'freesiem-sentinel'),
				(string) ($result['manual_commands'][0] ?? 'nginx -t'),
				(string) ($result['manual_commands'][1] ?? 'nginx -s reload')
			);
		}
		if (!empty($result['success']) && !is_ssl() && strtolower((string) wp_parse_url(home_url('/'), PHP_URL_SCHEME)) !== 'https') {
			$notice .= ' ' . __('SSL is active at nginx, but WordPress URLs still need to be switched to HTTPS manually or in a later phase.', 'freesiem-sentinel');
		}

		$notice_level = !empty($result['success']) ? 'success' : (((string) ($result['status'] ?? '') === 'manual_required') ? 'warning' : 'error');
		freesiem_sentinel_set_notice($notice_level, $notice);
		$this->redirect_to_page('freesiem-ssl', ['tab' => 'overview']);
	}

	public function handle_detect_nginx_config(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		freesiem_sentinel_add_ssl_log('info', __('Active nginx config detection was requested from wp-admin.', 'freesiem-sentinel'), 'nginx_detect_attempt');
		$ssl_settings = freesiem_sentinel_get_ssl_settings();
		$environment = freesiem_sentinel_get_ssl_environment_snapshot($ssl_settings);
		$ssl_state = freesiem_sentinel_get_ssl_state();
		$integration = freesiem_sentinel_detect_nginx_integration($ssl_settings, $environment, $ssl_state);
		freesiem_sentinel_update_ssl_state([
			'nginx_integration_mode' => (string) ($integration['mode'] ?? 'manual_required'),
			'nginx_detection_source' => (string) ($integration['detection_source'] ?? 'nginx_t'),
			'nginx_detection_confidence' => (string) ($integration['detection_confidence'] ?? 'ambiguous'),
			'nginx_matched_server_name' => (string) ($integration['matched_server_name'] ?? ''),
			'nginx_config_path' => (string) ($integration['target_path'] ?? ''),
			'nginx_last_detect_result' => (string) ($integration['detection_result'] ?? __('Nginx detection completed.', 'freesiem-sentinel')),
			'nginx_last_detect_at' => freesiem_sentinel_get_iso8601_time(),
		]);
		$level = match ((string) ($integration['detection_confidence'] ?? 'ambiguous')) {
			'exact' => 'success',
			'probable' => 'warning',
			default => 'error',
		};
		$category = (string) ($integration['detection_confidence'] ?? '') === 'ambiguous' ? 'nginx_detect_ambiguous' : 'nginx_detect_success';
		freesiem_sentinel_add_ssl_log($level, (string) ($integration['detection_result'] ?? __('Nginx detection completed.', 'freesiem-sentinel')), $category, [
			'config_path' => (string) ($integration['target_path'] ?? ''),
			'matched_domain' => (string) ($integration['matched_server_name'] ?? ''),
			'confidence' => (string) ($integration['detection_confidence'] ?? 'ambiguous'),
		]);
		if (!empty($integration['permissions_blocked'])) {
			$guidance = freesiem_sentinel_get_nginx_permission_guidance($integration, $environment);
			freesiem_sentinel_add_ssl_log('warning', __('Automatic nginx apply is currently blocked by filesystem permissions.', 'freesiem-sentinel'), 'nginx_permission_guidance', [
				'paths' => array_values(array_map(static fn(array $item): string => (string) ($item['path'] ?? ''), (array) ($guidance['items'] ?? []))),
				'web_user' => (string) ($guidance['web_user']['user'] ?? ''),
			]);
		}

		$notice_level = (string) ($integration['detection_confidence'] ?? '') === 'exact' ? 'success' : ((string) ($integration['detection_confidence'] ?? '') === 'probable' ? 'warning' : 'error');
		freesiem_sentinel_set_notice($notice_level, (string) ($integration['detection_result'] ?? __('Nginx detection completed.', 'freesiem-sentinel')));
		$this->redirect_to_page('freesiem-ssl', ['tab' => 'overview']);
	}

	public function handle_install_certbot(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		if (empty($_POST['confirm_certbot_install'])) {
			freesiem_sentinel_set_notice('error', __('Confirm that you understand certbot installation requires server-level permissions before continuing.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-ssl', ['tab' => 'overview']);
		}

		$environment = freesiem_sentinel_detect_ssl_install_environment();
		freesiem_sentinel_add_ssl_log('info', __('Certbot install environment was detected.', 'freesiem-sentinel'), 'environment_detected', [
			'os_family' => (string) ($environment['os_family'] ?? 'unknown'),
			'install_method' => (string) ($environment['install_method'] ?? ''),
			'root_status' => (string) ($environment['root_status'] ?? 'unknown'),
		]);
		freesiem_sentinel_add_ssl_log('info', __('Certbot install was requested from wp-admin.', 'freesiem-sentinel'), 'install_attempt', [
			'install_method' => (string) ($environment['install_method'] ?? ''),
		]);

		$result = freesiem_sentinel_install_certbot();
		freesiem_sentinel_add_ssl_log(
			!empty($result['success']) ? 'success' : 'error',
			(string) ($result['summary'] ?? __('Certbot installation completed.', 'freesiem-sentinel')),
			!empty($result['success']) ? 'install_success' : 'install_failure',
			[
				'install_method' => (string) (($result['install_environment']['install_method'] ?? '')),
				'root_status' => (string) (($result['install_environment']['root_status'] ?? 'unknown')),
			]
		);

		$readiness = freesiem_sentinel_calculate_ssl_readiness();
		freesiem_sentinel_add_ssl_log('info', sprintf(__('SSL readiness recalculated: %s.', 'freesiem-sentinel'), $readiness['label']), 'readiness', [
			'readiness_state' => (string) ($readiness['state'] ?? 'not_configured'),
		]);

		freesiem_sentinel_set_notice(!empty($result['success']) ? 'success' : 'error', (string) ($result['summary'] ?? __('Certbot installation completed.', 'freesiem-sentinel')));
		$this->redirect_to_page('freesiem-ssl', ['tab' => 'overview']);
	}

	public function handle_save_login_protection(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$settings = freesiem_sentinel_update_login_protection_settings([
			'enabled' => empty($_POST['enabled']) ? 0 : 1,
			'max_failed_attempts' => isset($_POST['max_failed_attempts']) ? (int) $_POST['max_failed_attempts'] : 5,
			'lockout_duration_minutes' => isset($_POST['lockout_duration_minutes']) ? (int) $_POST['lockout_duration_minutes'] : 15,
			'tracking_mode' => isset($_POST['tracking_mode']) ? sanitize_key(wp_unslash((string) $_POST['tracking_mode'])) : 'both',
			'enable_permanent_ban' => empty($_POST['enable_permanent_ban']) ? 0 : 1,
			'permanent_ban_threshold' => isset($_POST['permanent_ban_threshold']) ? (int) $_POST['permanent_ban_threshold'] : 0,
			'track_failed_login_count' => empty($_POST['track_failed_login_count']) ? 0 : 1,
			'log_successful_logins' => empty($_POST['log_successful_logins']) ? 0 : 1,
			'log_failed_logins' => empty($_POST['log_failed_logins']) ? 0 : 1,
		]);

		if (!empty($settings['enable_permanent_ban']) && (int) ($settings['permanent_ban_threshold'] ?? 0) < 1) {
			freesiem_sentinel_set_notice('error', __('Permanent ban threshold must be at least 1 when permanent bans are enabled.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-login-protection');
		}

		freesiem_sentinel_set_notice('success', __('Login Protection settings saved.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-login-protection');
	}

	public function handle_unblock_login_protection_record(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$key = isset($_POST['record_key']) ? sanitize_key(wp_unslash((string) $_POST['record_key'])) : '';
		$record = $key !== '' ? freesiem_sentinel_get_login_protection_records(true)[$key] ?? null : null;

		if (!is_array($record) || $key === '') {
			freesiem_sentinel_set_notice('error', __('Login Protection record not found.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-login-protection');
		}

		freesiem_sentinel_delete_login_protection_record($key);
		freesiem_sentinel_log_event('login_unblocked', __('A Login Protection record was manually unblocked.', 'freesiem-sentinel'), (string) ($record['username'] ?? ''), (string) ($record['ip_address'] ?? ''), [
			'key_type' => (string) ($record['key_type'] ?? 'combined'),
			'actor' => 'admin',
		]);
		do_action('freesiem_sentinel_login_unblocked', $record, ['source' => 'admin']);

		freesiem_sentinel_set_notice('success', __('Login Protection record unblocked.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-login-protection');
	}

	public function handle_unblock_expired_login_protection_records(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$removed = freesiem_sentinel_delete_expired_login_protection_records();
		if ($removed > 0) {
			freesiem_sentinel_log_event('login_unblocked', __('Expired Login Protection records were cleared.', 'freesiem-sentinel'), '', '', [
				'count' => $removed,
				'actor' => 'admin',
			]);
			do_action('freesiem_sentinel_login_unblocked', ['bulk' => true, 'count' => $removed], ['source' => 'admin']);
		}

		freesiem_sentinel_set_notice('success', sprintf(_n('%d expired record cleared.', '%d expired records cleared.', $removed, 'freesiem-sentinel'), $removed));
		$this->redirect_to_page('freesiem-login-protection');
	}

	public function handle_save_stealth_mode(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$settings = freesiem_sentinel_update_stealth_mode_settings([
			'enabled' => empty($_POST['enabled']) ? 0 : 1,
			'custom_login_slug' => isset($_POST['custom_login_slug']) ? sanitize_title(wp_unslash((string) $_POST['custom_login_slug'])) : 'sentinel-login',
			'block_direct_wp_login' => empty($_POST['block_direct_wp_login']) ? 0 : 1,
			'redirect_wp_admin_guests' => empty($_POST['redirect_wp_admin_guests']) ? 0 : 1,
		]);

		$current_login_url = freesiem_sentinel_is_stealth_mode_effectively_active($settings) ? freesiem_sentinel_get_stealth_login_url($settings) : wp_login_url();
		freesiem_sentinel_set_notice('success', sprintf(__('Stealth Mode settings saved. Current login URL: %s', 'freesiem-sentinel'), $current_login_url));
		$this->redirect_to_page('freesiem-stealth-mode');
	}

	public function handle_clear_logs(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();
		freesiem_sentinel_clear_log_rows();
		freesiem_sentinel_set_notice('success', __('Sentinel logs cleared.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-logs');
	}

	public function handle_save_rustfs_settings(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$existing = freesiem_sentinel_get_settings();
		$submitted_secret = isset($_POST['rustfs_secret_key']) ? (string) wp_unslash($_POST['rustfs_secret_key']) : '';
		$secret = $submitted_secret === freesiem_sentinel_get_rustfs_secret_placeholder()
			? (string) $existing['rustfs_secret_key']
			: $submitted_secret;

		freesiem_sentinel_update_settings([
			'rustfs_enabled' => empty($_POST['rustfs_enabled']) ? 0 : 1,
			'rustfs_provider' => isset($_POST['rustfs_provider']) ? sanitize_key((string) wp_unslash($_POST['rustfs_provider'])) : 'rustfs',
			'rustfs_endpoint' => isset($_POST['rustfs_endpoint']) ? (string) wp_unslash($_POST['rustfs_endpoint']) : '',
			'rustfs_console_url' => isset($_POST['rustfs_console_url']) ? (string) wp_unslash($_POST['rustfs_console_url']) : '',
			'rustfs_region' => isset($_POST['rustfs_region']) ? (string) wp_unslash($_POST['rustfs_region']) : 'us-east-1',
			'rustfs_bucket' => isset($_POST['rustfs_bucket']) ? (string) wp_unslash($_POST['rustfs_bucket']) : '',
			'rustfs_access_key' => isset($_POST['rustfs_access_key']) ? (string) wp_unslash($_POST['rustfs_access_key']) : '',
			'rustfs_secret_key' => $secret,
			'rustfs_path_style' => empty($_POST['rustfs_path_style']) ? 0 : 1,
		]);

		freesiem_sentinel_set_notice('success', __('RustFS settings saved.', 'freesiem-sentinel'));
		$this->redirect_to_page('freesiem-settings', ['tab' => 'general']);
	}

	public function handle_test_rustfs_connection(): void
	{
		$this->assert_manage_permissions();
		freesiem_sentinel_require_admin_post_nonce();

		$settings = freesiem_sentinel_get_settings();

		if (!freesiem_sentinel_rustfs_is_configured($settings)) {
			freesiem_sentinel_set_notice('error', __('Fill in and save the endpoint, bucket, access key, and secret key before testing the connection.', 'freesiem-sentinel'));
			$this->redirect_to_page('freesiem-settings', ['tab' => 'general']);
		}

		$client = freesiem_sentinel_get_rustfs_client($settings);
		$result = $client instanceof FreeSIEM_Sentinel_S3_Client ? $client->list_buckets() : new WP_Error('freesiem_sentinel_rustfs_unavailable', __('The storage client is not available.', 'freesiem-sentinel'));

		if (is_wp_error($result)) {
			freesiem_sentinel_set_notice('error', sprintf(__('RustFS connection test failed: %s', 'freesiem-sentinel'), $result->get_error_message()));
		} else {
			$bucket_count = is_array($result) ? count($result) : 0;
			freesiem_sentinel_set_notice('success', sprintf(
				/* translators: %d: number of buckets visible with these credentials */
				__('RustFS connection test succeeded. %d bucket(s) visible with these credentials.', 'freesiem-sentinel'),
				$bucket_count
			));
		}

		$this->redirect_to_page('freesiem-settings', ['tab' => 'general']);
	}

	public function render_dashboard_page(): void
	{
		$settings = freesiem_sentinel_get_settings();
		$cache = $this->plugin->get_results()->get_cache();
		$summary = freesiem_sentinel_safe_array($cache['summary'] ?? []);
		$severity_counts = array_merge(
			['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'info' => 0],
			freesiem_sentinel_safe_array($cache['severity_counts'] ?? [])
		);
		$top_issues = array_values(freesiem_sentinel_safe_array($cache['top_issues'] ?? []));
		$recommendations = array_values(array_filter(freesiem_sentinel_safe_array($cache['recommendations'] ?? [])));
		$inventory = freesiem_sentinel_safe_array($cache['local_inventory'] ?? []);
		$filesystem = freesiem_sentinel_safe_array($inventory['filesystem'] ?? []);
		$connection_ok = !empty($settings['site_id']) && !empty($settings['api_key']) && !empty($settings['hmac_secret']);
		$show_results_url = $this->build_scan_url(['show_results' => '1']) . '#freesiem-results-section';
		$remote_url = freesiem_sentinel_admin_page_url('freesiem-activity', ['section' => 'connection']);

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('Dashboard', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('Your freeSIEM control center for current risk, scan activity, and next actions.', 'freesiem-sentinel') . '</p>';

		echo '<div style="background:linear-gradient(135deg,#09111c,#15253b);padding:22px;border-radius:16px;color:#fff;margin:20px 0 24px;">';
		echo '<h2 style="margin:0 0 10px;color:#fff;">' . esc_html__('Security Risk Overview', 'freesiem-sentinel') . '</h2>';
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;">';
		foreach ([
			'critical' => ['label' => __('Critical', 'freesiem-sentinel'), 'bg' => '#7f1d1d', 'border' => '#b91c1c', 'text' => '#fff'],
			'high' => ['label' => __('High', 'freesiem-sentinel'), 'bg' => '#9a3412', 'border' => '#ea580c', 'text' => '#fff'],
			'medium' => ['label' => __('Medium', 'freesiem-sentinel'), 'bg' => '#92400e', 'border' => '#f59e0b', 'text' => '#fff7ed'],
			'low' => ['label' => __('Low', 'freesiem-sentinel'), 'bg' => '#1d4ed8', 'border' => '#60a5fa', 'text' => '#eff6ff'],
			'info' => ['label' => __('Info', 'freesiem-sentinel'), 'bg' => '#334155', 'border' => '#94a3b8', 'text' => '#f8fafc'],
		] as $severity => $config) {
			$url = $this->build_scan_url([
				'show_results' => '1',
				'severity' => [$severity],
			]) . '#freesiem-results-section';
			echo '<a href="' . esc_url($url) . '" style="display:block;padding:16px 18px;border-radius:14px;background:' . esc_attr($config['bg']) . ';border:1px solid ' . esc_attr($config['border']) . ';text-decoration:none;color:' . esc_attr($config['text']) . ';">';
			echo '<span style="display:block;font-size:12px;letter-spacing:.08em;text-transform:uppercase;opacity:.85;">' . esc_html($config['label']) . '</span>';
			echo '<strong style="display:block;font-size:30px;line-height:1.1;margin-top:8px;">' . esc_html(safe($severity_counts[$severity] ?? '0')) . '</strong>';
			echo '</a>';
		}
		echo '</div>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:16px;margin-bottom:24px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Quick Actions', 'freesiem-sentinel') . '</h2>';
		echo '<div style="display:flex;gap:12px;flex-wrap:wrap;">';
		echo '<a class="button button-primary" style="padding:10px 18px;" href="' . esc_url(freesiem_sentinel_admin_page_url('freesiem-scan')) . '">' . esc_html__('Run Scan', 'freesiem-sentinel') . '</a>';
		echo '<a class="button button-secondary" style="padding:10px 18px;" href="' . esc_url($show_results_url) . '">' . esc_html__('View Results', 'freesiem-sentinel') . '</a>';
		echo '<a class="button button-secondary" style="padding:10px 18px;" href="' . esc_url($remote_url) . '">' . esc_html__('Connection', 'freesiem-sentinel') . '</a>';
		echo '</div>';
		echo '</div>';

		echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px;">';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:16px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Top Issues', 'freesiem-sentinel') . '</h2>';
		if ($top_issues === []) {
			$this->render_empty_state(__('No scan has been run yet.', 'freesiem-sentinel'), __('Run a scan to surface the most important issues to review next.', 'freesiem-sentinel'));
		} else {
			echo '<ul style="margin:0;padding-left:18px;">';
			foreach ($top_issues as $index => $issue) {
				if (!is_array($issue)) {
					continue;
				}
				$url = $this->build_scan_url([
					'show_results' => '1',
					'finding' => $this->build_finding_reference($issue),
				]);
				echo '<li style="margin-bottom:10px;"><a href="' . esc_url($url) . '" style="text-decoration:none;"><strong>' . esc_html(freesiem_sentinel_safe_string($issue['title'] ?? '')) . '</strong></a><br /><span>' . esc_html(freesiem_sentinel_safe_string($issue['recommendation'] ?? '')) . '</span></li>';
			}
			echo '</ul>';
		}
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:16px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Recommendations', 'freesiem-sentinel') . '</h2>';
		if ($recommendations === []) {
			$this->render_empty_state(__('No recommendations yet.', 'freesiem-sentinel'), __('Recommendations will appear here after scan or sync data is available.', 'freesiem-sentinel'));
		} else {
			echo '<ul style="margin:0;padding-left:18px;">';
			foreach ($recommendations as $recommendation) {
				echo '<li style="margin-bottom:8px;">' . esc_html(freesiem_sentinel_safe_string($recommendation)) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
		echo '</div>';

		echo '<div style="display:grid;grid-template-columns:1.2fr .8fr;gap:20px;">';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:16px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Last Scan Summary', 'freesiem-sentinel') . '</h2>';
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;">';
		$this->render_summary_stat(__('Last Scan Time', 'freesiem-sentinel'), $this->summary_value_or_fallback($settings['last_local_scan_at'] ?? '', true));
		$this->render_summary_stat(__('Overall Score', 'freesiem-sentinel'), $this->summary_value_or_fallback($summary['overall_score'] ?? ($summary['local_score'] ?? ''), false));
		$this->render_summary_stat(__('Files Discovered', 'freesiem-sentinel'), $this->summary_value_or_fallback($filesystem['discovered_files'] ?? '', false));
		$this->render_summary_stat(__('Files Analyzed', 'freesiem-sentinel'), $this->summary_value_or_fallback($filesystem['inspected_files'] ?? '', false));
		$this->render_summary_stat(__('Flagged Files', 'freesiem-sentinel'), $this->summary_value_or_fallback($filesystem['flagged_files'] ?? '', false));
		echo '</div>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:16px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Site Status', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Site ID', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->friendly_site_id($settings['site_id'] ?? '')) . '</p>';
		echo '<p><strong>' . esc_html__('Agent Status', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->agent_status_label($connection_ok)) . '</p>';
		echo '<p><strong>' . esc_html__('Last Heartbeat', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback($settings['last_heartbeat_at'] ?? '', true)) . '</p>';
		echo '<p><strong>' . esc_html__('Registration State', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->registration_state_label($settings['registration_status'] ?? '')) . '</p>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}

	public function render_login_protection_page(): void
	{
		$this->assert_manage_permissions();
		$settings = freesiem_sentinel_get_login_protection_settings();
		$records = array_values(freesiem_sentinel_get_login_protection_records(true));
		$active_count = 0;
		$ban_count = 0;

		foreach ($records as $record) {
			$status = freesiem_sentinel_get_login_protection_record_status($record);
			if ($status === 'active_lockout') {
				$active_count++;
			} elseif ($status === 'permanent_ban') {
				$ban_count++;
			}
		}

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('Login Protection', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('Configure brute-force protection, failed login tracking, lockouts, and recovery actions for WordPress sign-in events.', 'freesiem-sentinel') . '</p>';
		echo '<p><strong>' . esc_html__('Current status', 'freesiem-sentinel') . ':</strong> ' . esc_html(sprintf(__('Active lockouts: %1$d | Permanent bans: %2$d | Tracked records: %3$d', 'freesiem-sentinel'), $active_count, $ban_count, count($records))) . '</p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_save_login_protection" />';
		echo '<table class="form-table" role="presentation">';
		$this->render_ssl_checkbox_field('enabled', __('Enable login protection', 'freesiem-sentinel'), !empty($settings['enabled']), __('When enabled, Sentinel tracks failed logins and temporarily locks out repeated attempts.', 'freesiem-sentinel'));
		echo '<tr><th scope="row"><label for="freesiem-max-failed-attempts">' . esc_html__('Max failed login attempts', 'freesiem-sentinel') . '</label></th><td><input id="freesiem-max-failed-attempts" type="number" min="1" max="100" name="max_failed_attempts" value="' . esc_attr((string) ($settings['max_failed_attempts'] ?? 5)) . '" class="small-text" /><p class="description">' . esc_html__('Base threshold for the first lockout. Progressive lockouts automatically escalate from this value.', 'freesiem-sentinel') . '</p></td></tr>';
		echo '<tr><th scope="row"><label for="freesiem-lockout-duration">' . esc_html__('Lockout duration (minutes)', 'freesiem-sentinel') . '</label></th><td><input id="freesiem-lockout-duration" type="number" min="1" max="1440" name="lockout_duration_minutes" value="' . esc_attr((string) ($settings['lockout_duration_minutes'] ?? 15)) . '" class="small-text" /></td></tr>';
		echo '<tr><th scope="row"><label for="freesiem-tracking-mode">' . esc_html__('Tracking mode', 'freesiem-sentinel') . '</label></th><td><select id="freesiem-tracking-mode" name="tracking_mode">';
		foreach ([
			'both' => __('Both username and IP', 'freesiem-sentinel'),
			'username' => __('Username only', 'freesiem-sentinel'),
			'ip' => __('IP only', 'freesiem-sentinel'),
		] as $value => $label) {
			echo '<option value="' . esc_attr($value) . '" ' . selected((string) ($settings['tracking_mode'] ?? 'both'), $value, false) . '>' . esc_html($label) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__('Both username and IP is the recommended default because it reduces collateral lockouts while still slowing brute-force attempts.', 'freesiem-sentinel') . '</p></td></tr>';
		$this->render_ssl_checkbox_field('enable_permanent_ban', __('Enable permanent bans', 'freesiem-sentinel'), !empty($settings['enable_permanent_ban']), __('When enabled, repeated lockout offenses can be converted into a permanent block until an admin clears the record.', 'freesiem-sentinel'));
		echo '<tr><th scope="row"><label for="freesiem-permanent-ban-threshold">' . esc_html__('Permanent ban after offenses', 'freesiem-sentinel') . '</label></th><td><input id="freesiem-permanent-ban-threshold" type="number" min="0" max="1000" name="permanent_ban_threshold" value="' . esc_attr((string) ($settings['permanent_ban_threshold'] ?? 0)) . '" class="small-text" /><p class="description">' . esc_html__('Set to 0 to disable permanent bans. When enabled, the value represents how many lockout offenses must occur before a permanent ban is applied.', 'freesiem-sentinel') . '</p></td></tr>';
		$this->render_ssl_checkbox_field('track_failed_login_count', __('Track failed login count', 'freesiem-sentinel'), !empty($settings['track_failed_login_count']), __('Stores the current failed-attempt counter per username/IP key for lockout evaluation.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('log_successful_logins', __('Log successful logins', 'freesiem-sentinel'), !empty($settings['log_successful_logins']), __('Adds wp_login events to the Sentinel Logs page.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('log_failed_logins', __('Log failed logins', 'freesiem-sentinel'), !empty($settings['log_failed_logins']), __('Adds wp_login_failed and lockout events to the Sentinel Logs page.', 'freesiem-sentinel'));
		echo '</table>';
		$thresholds = freesiem_sentinel_get_login_protection_progressive_thresholds($settings);
		echo '<p><strong>' . esc_html__('Progressive lockout defaults', 'freesiem-sentinel') . ':</strong> ';
		$threshold_labels = [];
		foreach ($thresholds as $rule) {
			$threshold_labels[] = sprintf(__('%1$d attempts => %2$d minutes', 'freesiem-sentinel'), (int) ($rule['threshold'] ?? 0), (int) ($rule['duration_minutes'] ?? 0));
		}
		echo esc_html(implode(' | ', $threshold_labels)) . '</p>';
		submit_button(__('Save Login Protection Settings', 'freesiem-sentinel'));
		echo '</form>';

		echo '<hr style="margin:24px 0;" />';
		echo '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 12px 0;">';
		echo '<h2 style="margin:0;">' . esc_html__('Active Lockouts / Bans', 'freesiem-sentinel') . '</h2>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_unblock_expired_login_protection_records" />';
		submit_button(__('Unblock All Expired', 'freesiem-sentinel'), 'secondary', '', false);
		echo '</form>';
		echo '</div>';

		if ($records === []) {
			echo '<p>' . esc_html__('No login protection records exist yet.', 'freesiem-sentinel') . '</p>';
		} else {
			echo '<div style="overflow:auto;">';
			echo '<table class="widefat striped" style="min-width:1080px;"><thead><tr><th>' . esc_html__('Key Type', 'freesiem-sentinel') . '</th><th>' . esc_html__('IP', 'freesiem-sentinel') . '</th><th>' . esc_html__('Username', 'freesiem-sentinel') . '</th><th>' . esc_html__('Attempts', 'freesiem-sentinel') . '</th><th>' . esc_html__('Total Offenses', 'freesiem-sentinel') . '</th><th>' . esc_html__('Locked Until', 'freesiem-sentinel') . '</th><th>' . esc_html__('Status', 'freesiem-sentinel') . '</th><th>' . esc_html__('Last Failure', 'freesiem-sentinel') . '</th><th>' . esc_html__('Reason', 'freesiem-sentinel') . '</th><th>' . esc_html__('Actions', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach ($records as $record) {
				$status = freesiem_sentinel_get_login_protection_record_status($record);
				echo '<tr>';
				echo '<td>' . esc_html((string) ($record['key_type'] ?? 'combined')) . '</td>';
				echo '<td>' . esc_html((string) ($record['ip_address'] ?? '')) . '</td>';
				echo '<td>' . esc_html((string) ($record['username'] ?? '')) . '</td>';
				echo '<td>' . esc_html((string) ((int) ($record['attempts'] ?? 0))) . '</td>';
				echo '<td>' . esc_html((string) ((int) ($record['total_offenses'] ?? 0))) . '</td>';
				echo '<td>' . esc_html(!empty($record['locked_until']) ? gmdate('Y-m-d H:i:s', (int) $record['locked_until']) . ' UTC' : __('Not locked', 'freesiem-sentinel')) . '</td>';
				echo '<td>' . esc_html(match ($status) {
					'permanent_ban' => __('Permanent ban', 'freesiem-sentinel'),
					'active_lockout' => __('Active lockout', 'freesiem-sentinel'),
					default => __('Expired', 'freesiem-sentinel'),
				}) . '</td>';
				echo '<td>' . esc_html(!empty($record['last_failure_at']) ? gmdate('Y-m-d H:i:s', (int) $record['last_failure_at']) . ' UTC' : __('Never', 'freesiem-sentinel')) . '</td>';
				echo '<td>' . esc_html((string) ($record['reason'] ?? '')) . '</td>';
				echo '<td>';
				echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;">';
				wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
				echo '<input type="hidden" name="action" value="freesiem_sentinel_unblock_login_protection_record" />';
				echo '<input type="hidden" name="record_key" value="' . esc_attr((string) ($record['key'] ?? '')) . '" />';
				submit_button(__('Unblock', 'freesiem-sentinel'), 'secondary small', '', false, ['onclick' => "return confirm('" . esc_js(__('Clear this login protection record?', 'freesiem-sentinel')) . "');"]);
				echo '</form>';
				echo '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
			echo '</div>';
		}
		echo '</div>';
	}

	public function render_synchy_page(): void
	{
		$this->assert_manage_permissions();

		if (!function_exists('synchy_render_page')) {
			echo '<div class="wrap">';
			echo '<h1>' . esc_html__('Synchy', 'freesiem-sentinel') . '</h1>';
			echo '<p>' . esc_html__('The bundled Synchy runtime is not available.', 'freesiem-sentinel') . '</p>';
			echo '</div>';
			return;
		}

		$current_tab = $this->get_synchy_current_tab();
		$tabs = $this->get_synchy_tabs();

		echo '<div class="wrap">';
		echo '<div class="freesiem-synchy-header">';
		echo '<div class="freesiem-synchy-title"><span class="freesiem-synchy-title__mark" aria-hidden="true"></span><h1>' . esc_html__('Synchy', 'freesiem-sentinel') . '</h1></div>';
		echo '<h2 class="nav-tab-wrapper freesiem-synchy-tabs">';
		foreach ($tabs as $tab => $config) {
			$url = add_query_arg(
				[
					'page' => FREESIEM_SENTINEL_SYNCHY_PAGE,
					'tab' => $tab,
				],
				admin_url('admin.php')
			);
			echo '<a class="nav-tab ' . esc_attr($tab === $current_tab ? 'nav-tab-active' : '') . '" href="' . esc_url($url) . '">' . esc_html((string) ($config['label'] ?? $tab)) . '</a>';
		}
		echo '</h2>';
		echo '</div>';
		echo '</div>';

		ob_start();
		synchy_render_page($this->get_synchy_legacy_page_slug($current_tab));
		$html = (string) ob_get_clean();
		echo $this->filter_synchy_rendered_page_html($html, $current_tab); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function render_security_page(): void
	{
		$this->assert_manage_permissions();

		$tabs = $this->get_security_tabs();
		$current_tab = $this->get_security_current_tab();

		echo '<div class="wrap">';
		echo '<div class="freesiem-synchy-header">';
		echo '<div class="freesiem-synchy-title"><span class="freesiem-synchy-title__mark" aria-hidden="true"></span><h1>' . esc_html__('Security', 'freesiem-sentinel') . '</h1></div>';
		echo '<h2 class="nav-tab-wrapper freesiem-synchy-tabs">';
		foreach ($tabs as $section => $config) {
			$url = add_query_arg(['page' => 'freesiem-security', 'section' => $section], admin_url('admin.php'));
			echo '<a class="nav-tab ' . esc_attr($section === $current_tab ? 'nav-tab-active' : '') . '" href="' . esc_url($url) . '">' . esc_html((string) $config['label']) . '</a>';
		}
		echo '</h2>';
		echo '</div>';
		echo '</div>';

		// Each of these still fully self-contains its own <div class="wrap"> and permission
		// check, exactly as it does when reached directly at its own (now hidden) menu slug --
		// this wrapper only adds the shared header and tab nav above it as a sibling block.
		switch ($current_tab) {
			case 'tfa':
				$this->render_tfa_page();
				break;
			case 'login-protection':
				$this->render_login_protection_page();
				break;
			case 'stealth-mode':
				$this->render_stealth_mode_page();
				break;
			case 'wp-cron':
				$this->render_wp_cron_page();
				break;
			default:
				$this->render_ssl_page();
				break;
		}
	}

	private function get_security_tabs(): array
	{
		return [
			'ssl' => ['label' => __('SSL / HTTPS', 'freesiem-sentinel')],
			'tfa' => ['label' => __('TFA (2FA)', 'freesiem-sentinel')],
			'login-protection' => ['label' => __('Login Protection', 'freesiem-sentinel')],
			'stealth-mode' => ['label' => __('Stealth Mode', 'freesiem-sentinel')],
			'wp-cron' => ['label' => __('WP-Cron', 'freesiem-sentinel')],
		];
	}

	private function get_security_current_tab(): string
	{
		$section = isset($_GET['section']) ? sanitize_key((string) wp_unslash($_GET['section'])) : 'ssl';
		$tabs = $this->get_security_tabs();

		return isset($tabs[$section]) ? $section : 'ssl';
	}

	public function render_wp_cron_page(): void
	{
		$this->assert_manage_permissions();
		$monitor = $this->plugin->get_cron_monitor();
		$events = $monitor->get_events();
		$history = $monitor->get_history();
		$disabled = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
		$overdue = count(array_filter($events, static fn (array $event): bool => !empty($event['overdue'])));

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('WP-Cron Monitor', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('View every scheduled WordPress event and recent executions. History starts when this Sentinel version is installed and retains the latest 250 runs.', 'freesiem-sentinel') . '</p>';
		echo '<div style="display:flex;gap:12px;flex-wrap:wrap;margin:16px 0;">';
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 18px;"><strong>' . esc_html(number_format_i18n(count($events))) . '</strong><br><span>' . esc_html__('Scheduled events', 'freesiem-sentinel') . '</span></div>';
		echo '<div style="background:#fff;border:1px solid ' . esc_attr($overdue > 0 ? '#d63638' : '#dcdcde') . ';border-radius:10px;padding:14px 18px;"><strong>' . esc_html(number_format_i18n($overdue)) . '</strong><br><span>' . esc_html__('Overdue events', 'freesiem-sentinel') . '</span></div>';
		echo '<div style="background:#fff;border:1px solid ' . esc_attr($disabled ? '#d63638' : '#00a32a') . ';border-radius:10px;padding:14px 18px;"><strong>' . esc_html($disabled ? __('Disabled', 'freesiem-sentinel') : __('Enabled', 'freesiem-sentinel')) . '</strong><br><span>' . esc_html__('Traffic-triggered WP-Cron', 'freesiem-sentinel') . '</span></div>';
		echo '</div>';

		if ($disabled) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__('DISABLE_WP_CRON is enabled. Confirm that Hostinger or another system scheduler calls wp-cron.php; otherwise overdue work will accumulate.', 'freesiem-sentinel') . '</p></div>';
		}

		echo '<h2>' . esc_html__('Scheduled Events', 'freesiem-sentinel') . '</h2>';
		echo '<div style="overflow:auto;background:#fff;border:1px solid #dcdcde;border-radius:10px;"><table class="widefat striped"><thead><tr><th>' . esc_html__('Hook', 'freesiem-sentinel') . '</th><th>' . esc_html__('Next run', 'freesiem-sentinel') . '</th><th>' . esc_html__('Schedule', 'freesiem-sentinel') . '</th><th>' . esc_html__('Arguments', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
		if ($events === []) {
			echo '<tr><td colspan="4">' . esc_html__('No WP-Cron events are scheduled.', 'freesiem-sentinel') . '</td></tr>';
		} else {
			foreach ($events as $event) {
				$args = wp_json_encode($event['args'], JSON_UNESCAPED_SLASHES);
				$args = is_string($args) ? $args : '[]';
				echo '<tr><td><code>' . esc_html((string) $event['hook']) . '</code></td>';
				echo '<td>' . (!empty($event['overdue']) ? '<strong style="color:#b32d2e;">' . esc_html__('Overdue: ', 'freesiem-sentinel') . '</strong>' : '') . esc_html(freesiem_sentinel_format_datetime(gmdate('c', (int) $event['next_run']))) . '</td>';
				echo '<td>' . esc_html((string) $event['schedule']) . '</td><td><code title="' . esc_attr($args) . '">' . esc_html(strlen($args) > 160 ? substr($args, 0, 157) . '...' : $args) . '</code></td></tr>';
			}
		}
		echo '</tbody></table></div>';

		echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:24px;"><h2 style="margin:0;">' . esc_html__('Execution History', 'freesiem-sentinel') . '</h2>';
		if ($history !== []) {
			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="freesiem_sentinel_clear_cron_history">';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<button class="button button-secondary" type="submit">' . esc_html__('Clear History', 'freesiem-sentinel') . '</button></form>';
		}
		echo '</div>';
		echo '<div style="overflow:auto;background:#fff;border:1px solid #dcdcde;border-radius:10px;margin-top:12px;"><table class="widefat striped"><thead><tr><th>' . esc_html__('Hook', 'freesiem-sentinel') . '</th><th>' . esc_html__('Started', 'freesiem-sentinel') . '</th><th>' . esc_html__('Status', 'freesiem-sentinel') . '</th><th>' . esc_html__('Duration', 'freesiem-sentinel') . '</th><th>' . esc_html__('Peak memory increase', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
		if ($history === []) {
			echo '<tr><td colspan="5">' . esc_html__('No executions have been observed yet.', 'freesiem-sentinel') . '</td></tr>';
		} else {
			foreach ($history as $row) {
				$status = sanitize_key((string) ($row['status'] ?? 'unknown'));
				$started = (string) ($row['started_at'] ?? '');
				if ($status === 'running' && (strtotime($started) ?: time()) < time() - 600) {
					$status = 'stale';
				}
				$color = $status === 'completed' ? '#008a20' : ($status === 'running' ? '#996800' : '#b32d2e');
				echo '<tr><td><code>' . esc_html((string) ($row['hook'] ?? '')) . '</code></td><td>' . esc_html($started !== '' ? freesiem_sentinel_format_datetime($started) : '—') . '</td>';
				echo '<td><strong style="color:' . esc_attr($color) . ';">' . esc_html(ucfirst($status)) . '</strong>' . (!empty($row['error']) ? '<br><small>' . esc_html((string) $row['error']) . '</small>' : '') . '</td>';
				echo '<td>' . esc_html(number_format_i18n((int) ($row['duration_ms'] ?? 0))) . ' ms</td><td>' . esc_html(size_format((int) ($row['memory_delta'] ?? 0))) . '</td></tr>';
			}
		}
		echo '</tbody></table></div></div>';
	}

	public function render_activity_page(): void
	{
		$can_manage = current_user_can('manage_options');
		$can_approve = $this->plugin->get_pending_tasks()->current_user_can_approve_tasks();

		if (!$can_manage && !$can_approve) {
			wp_die(esc_html__('You are not allowed to view this page.', 'freesiem-sentinel'));
		}

		$tabs = $this->get_activity_tabs($can_manage, $can_approve);
		$current_tab = $this->get_activity_current_tab($tabs);

		echo '<div class="wrap">';
		echo '<div class="freesiem-synchy-header">';
		echo '<div class="freesiem-synchy-title"><span class="freesiem-synchy-title__mark" aria-hidden="true"></span><h1>' . esc_html__('Core-Ops', 'freesiem-sentinel') . '</h1></div>';
		echo '<h2 class="nav-tab-wrapper freesiem-synchy-tabs">';
		foreach ($tabs as $section => $config) {
			$url = add_query_arg(['page' => 'freesiem-activity', 'section' => $section], admin_url('admin.php'));
			echo '<a class="nav-tab ' . esc_attr($section === $current_tab ? 'nav-tab-active' : '') . '" href="' . esc_url($url) . '">' . esc_html((string) $config['label']) . '</a>';
		}
		echo '</h2>';
		echo '</div>';
		echo '</div>';

		switch ($current_tab) {
			case 'logs':
				$this->render_logs_page();
				break;
			case 'pending-tasks':
				$this->render_pending_tasks_page();
				break;
			default:
				$this->render_remote_page();
				break;
		}
	}

	private function get_activity_tabs(bool $can_manage, bool $can_approve): array
	{
		$tabs = [];

		// Only offered to users who can actually open them -- keeps a non-admin task approver
		// from seeing Connection/Logs tabs that would just reject them.
		if ($can_manage) {
			$tabs['connection'] = ['label' => __('Connection', 'freesiem-sentinel')];
			$tabs['logs'] = ['label' => __('Logs', 'freesiem-sentinel')];
		}

		if ($can_approve) {
			$tabs['pending-tasks'] = ['label' => __('Pending Tasks', 'freesiem-sentinel')];
		}

		return $tabs;
	}

	private function get_activity_current_tab(array $tabs): string
	{
		$section = isset($_GET['section']) ? sanitize_key((string) wp_unslash($_GET['section'])) : '';

		if (isset($tabs[$section])) {
			return $section;
		}

		$keys = array_keys($tabs);

		return $keys[0] ?? 'connection';
	}

	public function render_stealth_mode_page(): void
	{
		$this->assert_manage_permissions();
		$settings = freesiem_sentinel_get_stealth_mode_settings();
		$override_active = freesiem_sentinel_is_stealth_mode_config_override_enabled();
		$stealth_active = freesiem_sentinel_is_stealth_mode_effectively_active($settings);
		$current_login_url = $stealth_active ? freesiem_sentinel_get_stealth_login_url($settings) : wp_login_url();
		$effective_status = !empty($settings['enabled'])
			? ($override_active ? __('Enabled in settings but disabled by wp-config.php override', 'freesiem-sentinel') : __('Enabled and active', 'freesiem-sentinel'))
			: __('Disabled', 'freesiem-sentinel');

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('Stealth Mode', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('Configure a safer login entry URL for visitors while keeping the hardened wp-login.php token fallback in place.', 'freesiem-sentinel') . '</p>';
		echo '<div class="notice notice-warning inline"><p>' . esc_html__('Changing login access can lock you out. Keep another administrator session open before enabling Stealth Mode changes.', 'freesiem-sentinel') . '</p></div>';
		if ($override_active) {
			echo '<div class="notice notice-error inline"><p><strong>' . esc_html__('Stealth Mode override active.', 'freesiem-sentinel') . '</strong> ' . esc_html__('Stealth Mode is currently disabled by the wp-config.php recovery override, so normal WordPress login behavior is being used.', 'freesiem-sentinel') . '</p></div>';
		}
		echo '<p><strong>' . esc_html__('Effective status', 'freesiem-sentinel') . ':</strong> ' . esc_html($effective_status) . '</p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_save_stealth_mode" />';
		echo '<table class="form-table" role="presentation">';
		$this->render_ssl_checkbox_field('enabled', __('Enable stealth mode', 'freesiem-sentinel'), !empty($settings['enabled']), __('Turns on Sentinel login obfuscation handling for the custom login URL below.', 'freesiem-sentinel'));
		echo '<tr><th scope="row"><label for="freesiem-stealth-slug">' . esc_html__('Custom login slug', 'freesiem-sentinel') . '</label></th><td><input id="freesiem-stealth-slug" type="text" name="custom_login_slug" value="' . esc_attr((string) ($settings['custom_login_slug'] ?? 'sentinel-login')) . '" class="regular-text" /><p class="description">' . esc_html__('Sentinel publishes this as a friendly login path, such as /clogin/, and keeps the secure token fallback behind the scenes.', 'freesiem-sentinel') . '</p></td></tr>';
		$this->render_ssl_checkbox_field('block_direct_wp_login', __('Block direct wp-login.php access', 'freesiem-sentinel'), !empty($settings['block_direct_wp_login']), __('When enabled, direct wp-login.php requests without the Sentinel login token are redirected away.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('redirect_wp_admin_guests', __('Redirect unauthenticated wp-admin users', 'freesiem-sentinel'), !empty($settings['redirect_wp_admin_guests']), __('When enabled, guests trying to access wp-admin are sent to the Sentinel login URL.', 'freesiem-sentinel'));
		echo '</table>';
		submit_button(__('Save Stealth Mode Settings', 'freesiem-sentinel'));
		echo '</form>';
		echo '<p><strong>' . esc_html__('Current login URL', 'freesiem-sentinel') . ':</strong> <code>' . esc_html($current_login_url) . '</code></p>';
		echo '<p><strong>' . esc_html__('Recovery override', 'freesiem-sentinel') . ':</strong> ' . esc_html__('Add this to wp-config.php to disable Stealth Mode enforcement without changing the saved settings:', 'freesiem-sentinel') . '</p>';
		echo '<pre style="padding:12px 14px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:6px;overflow:auto;"><code>define(\'FREESIEM_SENTINEL_DISABLE_STEALTH_MODE\', true);</code></pre>';
		echo '<p style="color:#646970;">' . esc_html__('Stealth Mode publishes a friendly login path and internally validates the same secure login token, so plugins using wp_login_url() can link to the cleaner URL.', 'freesiem-sentinel') . '</p>';
		if ($stealth_active) {
			echo '<p style="color:#646970;">' . esc_html__('Stealth Mode enforcement is currently active for the settings shown above.', 'freesiem-sentinel') . '</p>';
		}
		$recent_events = freesiem_sentinel_get_recent_log_rows_by_prefix('stealth_', 5);
		echo '<h2>' . esc_html__('Recent Stealth Events', 'freesiem-sentinel') . '</h2>';
		if ($recent_events === []) {
			echo '<p>' . esc_html__('No recent Stealth Mode events were recorded.', 'freesiem-sentinel') . '</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:980px;">';
			echo '<thead><tr><th>' . esc_html__('Time', 'freesiem-sentinel') . '</th><th>' . esc_html__('Event', 'freesiem-sentinel') . '</th><th>' . esc_html__('Username', 'freesiem-sentinel') . '</th><th>' . esc_html__('IP', 'freesiem-sentinel') . '</th><th>' . esc_html__('Message', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach ($recent_events as $event) {
				echo '<tr>';
				echo '<td>' . esc_html(freesiem_sentinel_format_datetime((string) ($event['created_at'] ?? ''))) . '</td>';
				echo '<td>' . esc_html((string) ($event['event_type'] ?? '')) . '</td>';
				echo '<td>' . esc_html((string) ($event['username'] ?? '')) . '</td>';
				echo '<td>' . esc_html((string) ($event['ip_address'] ?? '')) . '</td>';
				echo '<td>' . esc_html((string) ($event['message'] ?? '')) . '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	public function render_logs_page(): void
	{
		$this->assert_manage_permissions();
		$selected_type = isset($_GET['event_type']) ? sanitize_key((string) wp_unslash($_GET['event_type'])) : '';
		$selected_scope = isset($_GET['scope']) ? sanitize_key((string) wp_unslash($_GET['scope'])) : '';
		$search_username = isset($_GET['username']) ? sanitize_user((string) wp_unslash($_GET['username']), true) : '';
		$search_ip = isset($_GET['ip_address']) ? sanitize_text_field((string) wp_unslash($_GET['ip_address'])) : '';
		$rows = freesiem_sentinel_get_filtered_log_rows([
			'event_type' => $selected_type,
			'scope' => $selected_scope,
			'username' => $search_username,
			'ip_address' => $search_ip,
		], 200);
		$types = freesiem_sentinel_get_log_event_types();

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('Logs', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('Review lightweight login, stealth, TFA, and related Sentinel events.', 'freesiem-sentinel') . '</p>';
		echo '<form method="get" style="margin:0 0 14px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">';
		echo '<input type="hidden" name="page" value="freesiem-logs" />';
		echo '<label for="freesiem-log-type">' . esc_html__('Event type', 'freesiem-sentinel') . '</label>';
		echo '<select id="freesiem-log-type" name="event_type"><option value="">' . esc_html__('All events', 'freesiem-sentinel') . '</option>';
		foreach ($types as $type) {
			echo '<option value="' . esc_attr($type) . '" ' . selected($selected_type, $type, false) . '>' . esc_html($type) . '</option>';
		}
		echo '</select>';
		echo '<label for="freesiem-log-scope">' . esc_html__('Group', 'freesiem-sentinel') . '</label>';
		echo '<select id="freesiem-log-scope" name="scope">';
		foreach ([
			'' => __('All groups', 'freesiem-sentinel'),
			'failures' => __('Failures', 'freesiem-sentinel'),
			'lockouts' => __('Lockouts', 'freesiem-sentinel'),
			'bans' => __('Bans', 'freesiem-sentinel'),
		] as $value => $label) {
			echo '<option value="' . esc_attr($value) . '" ' . selected($selected_scope, $value, false) . '>' . esc_html($label) . '</option>';
		}
		echo '</select>';
		echo '<label for="freesiem-log-username">' . esc_html__('Username', 'freesiem-sentinel') . '</label>';
		echo '<input id="freesiem-log-username" type="search" name="username" value="' . esc_attr($search_username) . '" class="regular-text" style="max-width:180px;" />';
		echo '<label for="freesiem-log-ip">' . esc_html__('IP', 'freesiem-sentinel') . '</label>';
		echo '<input id="freesiem-log-ip" type="search" name="ip_address" value="' . esc_attr($search_ip) . '" class="regular-text" style="max-width:180px;" />';
		submit_button(__('Filter', 'freesiem-sentinel'), 'secondary', '', false);
		echo '</form>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0 0 14px 0;">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_clear_logs" />';
		submit_button(__('Clear Logs', 'freesiem-sentinel'), 'delete', '', false, ['onclick' => "return confirm('" . esc_js(__('Clear all Sentinel log rows?', 'freesiem-sentinel')) . "');"]);
		echo '</form>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Timestamp', 'freesiem-sentinel') . '</th><th>' . esc_html__('Event Type', 'freesiem-sentinel') . '</th><th>' . esc_html__('Username', 'freesiem-sentinel') . '</th><th>' . esc_html__('IP', 'freesiem-sentinel') . '</th><th>' . esc_html__('Message / Details', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
		if ($rows === []) {
			echo '<tr><td colspan="5">' . esc_html__('No log events recorded yet.', 'freesiem-sentinel') . '</td></tr>';
		} else {
			foreach ($rows as $row) {
				$message = (string) ($row['message'] ?? '');
				$context = !empty($row['context']) ? json_decode((string) $row['context'], true) : null;
				if (is_array($context) && $context !== []) {
					$message .= ' ' . wp_json_encode($context);
				}
				echo '<tr>';
				echo '<td>' . esc_html(freesiem_sentinel_format_datetime((string) ($row['created_at'] ?? ''))) . '</td>';
				echo '<td>' . esc_html((string) ($row['event_type'] ?? '')) . '</td>';
				echo '<td>' . esc_html((string) ($row['username'] ?? '')) . '</td>';
				echo '<td>' . esc_html((string) ($row['ip_address'] ?? '')) . '</td>';
				echo '<td>' . esc_html($message) . '</td>';
				echo '</tr>';
			}
		}
		echo '</tbody></table>';
		echo '</div>';
	}

	public function render_scan_page(): void
	{
		$settings = freesiem_sentinel_get_settings();
		$prefs = freesiem_sentinel_safe_array($settings['scan_preferences'] ?? []);
		$view = $this->get_scan_results_view();
		$cache = $view['cache'];
		$summary = $view['summary'];
		$filesystem = $view['filesystem'];
		$scan_profile = freesiem_sentinel_safe_array($view['inventory']['scan_profile'] ?? []);
		$scan_metrics = array_merge(
			[
				'files_discovered' => '',
				'files_analyzed' => '',
				'files_flagged' => '',
				'duration_seconds' => '',
				'scan_modules' => [],
			],
			freesiem_sentinel_safe_array($summary),
			freesiem_sentinel_safe_array($view['inventory']['scan_metrics'] ?? [])
		);
		$results_url = $this->build_scan_url(['show_results' => '1']) . '#freesiem-results-section';
		$severity_counts = array_merge(
			['critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'info' => 0],
			freesiem_sentinel_safe_array($cache['severity_counts'] ?? [])
		);
		$has_scan = !empty($settings['last_local_scan_at']);

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('Scan', 'freesiem-sentinel') . '</h1>';

		$this->render_deep_scan_progress();

		echo '<div class="fs-scan-layout" style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start;margin-top:12px;">';
		echo '<div style="min-width:0;">'; // ---- main column ----

		$this->render_scan_action_bar($results_url);
		$this->render_scan_summary_card($settings, $summary, $scan_metrics, $filesystem, $scan_profile, $severity_counts, $has_scan, $results_url);

		$acknowledged_count = (int) ($cache['acknowledged_count'] ?? 0);
		if ($acknowledged_count > 0) {
			echo '<p style="margin:-8px 0 20px;color:#047857;font-size:13px;">'
				. esc_html(sprintf(
					/* translators: %d: count */
					_n('%d finding is marked as safe and excluded from the score.', '%d findings are marked as safe and excluded from the score.', $acknowledged_count, 'freesiem-sentinel'),
					$acknowledged_count
				))
				. ' <a href="' . esc_url($results_url) . '">' . esc_html__('Review', 'freesiem-sentinel') . '</a></p>';
		}

		$this->render_scan_history_card();

		$requested_run = isset($_GET['scan_run']) ? sanitize_text_field(wp_unslash((string) $_GET['scan_run'])) : '';

		if ($requested_run !== '') {
			$this->render_scan_run_detail($requested_run);
		}

		$this->render_scan_config_card($prefs);
		$this->render_scan_results_section($view);

		echo '</div>'; // ---- /main column ----

		echo '<aside style="min-width:0;">';
		$this->render_scan_reports_card($settings);
		echo '</aside>';

		echo '</div>'; // ---- /layout ----

		echo '<style>'
			. '.fs-scan-layout aside .button{width:100%;text-align:center;box-sizing:border-box;}'
			. '.fs-sev-tiles{display:flex;flex-wrap:wrap;gap:10px;}'
			. '.fs-sev-tiles>a{flex:1 1 110px;max-width:220px;}'
			. '@media (max-width:1080px){.fs-scan-layout{grid-template-columns:1fr!important;}.fs-scan-layout aside>div{position:static!important;}}'
			. '</style>';

		echo '</div>';
	}

	/**
	 * The big, colourful action row at the top of the Scan screen. "Run Scan"
	 * submits the (collapsed) Scan Configuration form via its form= attribute.
	 */
	private function render_scan_action_bar(string $results_url): void
	{
		$clear_url = freesiem_sentinel_admin_post_url('freesiem_sentinel_clear_results');
		$btn = 'display:inline-flex;align-items:center;gap:8px;padding:12px 22px;font-size:15px;font-weight:600;line-height:1;border-radius:10px;border:1px solid transparent;text-decoration:none;cursor:pointer;';

		echo '<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:20px;">';

		echo '<button type="submit" form="fs-scan-config-form" style="' . esc_attr($btn) . 'background:#16794a;color:#fff;box-shadow:0 1px 2px rgba(0,0,0,.15);">'
			. '<span aria-hidden="true">&#9654;</span> ' . esc_html__('Run Scan', 'freesiem-sentinel') . '</button>';

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;" onsubmit="return confirm(\'' . esc_js(__('Start a complete full scan now? It runs in the background and can take a while on large sites.', 'freesiem-sentinel')) . '\');">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_run_full_scan_now" />';
		echo '<button type="submit" style="' . esc_attr($btn) . 'background:#1d4ed8;color:#fff;">' . esc_html__('Run Full Scan Now', 'freesiem-sentinel') . '</button>';
		echo '</form>';

		echo '<a href="' . esc_url($results_url) . '" style="' . esc_attr($btn) . 'background:#0f172a;color:#fff;">' . esc_html__('View Results', 'freesiem-sentinel') . '</a>';

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_email_scan_results" />';
		echo '<button type="submit" style="' . esc_attr($btn) . 'background:#fff;color:#1e293b;border-color:#cbd5e1;">' . esc_html__('Email Results Now', 'freesiem-sentinel') . '</button>';
		echo '</form>';

		echo '<a href="' . esc_url($clear_url) . '" onclick="return confirm(\'' . esc_js(__('Clear the stored scan results and findings?', 'freesiem-sentinel')) . '\');" style="' . esc_attr($btn) . 'background:#fff;color:#b91c1c;border-color:#fca5a5;">' . esc_html__('Clear Results', 'freesiem-sentinel') . '</a>';

		echo '</div>';
	}

	private function render_scan_summary_card(array $settings, array $summary, array $scan_metrics, array $filesystem, array $scan_profile, array $severity_counts, bool $has_scan, string $results_url): void
	{
		echo '<div style="background:#fff;padding:18px 20px;border:1px solid #dcdcde;border-radius:16px;margin:0 0 20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Scan Summary', 'freesiem-sentinel') . '</h2>';

		if (!$has_scan) {
			$this->render_empty_state(__('No scan has been run yet.', 'freesiem-sentinel'), __('Click “Run Scan” above to review findings, file changes, and summary metrics here.', 'freesiem-sentinel'));
			echo '</div>';

			return;
		}

		// Clickable severity tiles -> filtered findings.
		echo '<div class="fs-sev-tiles">';
		foreach ([
			'critical' => ['label' => __('Critical', 'freesiem-sentinel'), 'bg' => '#fef2f2', 'border' => '#fecaca', 'fg' => '#b91c1c'],
			'high' => ['label' => __('High', 'freesiem-sentinel'), 'bg' => '#fff7ed', 'border' => '#fed7aa', 'fg' => '#c2410c'],
			'medium' => ['label' => __('Medium', 'freesiem-sentinel'), 'bg' => '#fefce8', 'border' => '#fde68a', 'fg' => '#a16207'],
			'low' => ['label' => __('Low', 'freesiem-sentinel'), 'bg' => '#eff6ff', 'border' => '#bfdbfe', 'fg' => '#1d4ed8'],
			'info' => ['label' => __('Info', 'freesiem-sentinel'), 'bg' => '#f8fafc', 'border' => '#e2e8f0', 'fg' => '#475569'],
		] as $sev => $c) {
			$url = $this->build_scan_url(['show_results' => '1', 'severity' => [$sev]]) . '#freesiem-results-section';
			echo '<a href="' . esc_url($url) . '" style="display:block;padding:14px;border:1px solid ' . esc_attr($c['border']) . ';border-radius:12px;background:' . esc_attr($c['bg']) . ';text-decoration:none;color:' . esc_attr($c['fg']) . ';">';
			echo '<span style="display:block;font-size:11px;text-transform:uppercase;letter-spacing:.08em;opacity:.9;">' . esc_html($c['label']) . '</span>';
			echo '<strong style="display:block;font-size:26px;line-height:1.1;margin-top:6px;">' . esc_html(number_format_i18n((int) ($severity_counts[$sev] ?? 0))) . '</strong>';
			echo '</a>';
		}
		echo '</div>';

		// Metric tiles -> jump to the findings table.
		$metrics = [
			[__('Overall Score', 'freesiem-sentinel'), $this->summary_value_or_fallback($summary['overall_score'] ?? ($summary['local_score'] ?? ''), false)],
			[__('Last Scan', 'freesiem-sentinel'), freesiem_sentinel_format_datetime((string) ($settings['last_local_scan_at'] ?? ''))],
			[__('Files Discovered', 'freesiem-sentinel'), $this->summary_value_or_fallback($scan_metrics['files_discovered'] ?? ($filesystem['discovered_files'] ?? ''), false)],
			[__('Files Analyzed', 'freesiem-sentinel'), $this->summary_value_or_fallback($scan_metrics['files_analyzed'] ?? ($filesystem['inspected_files'] ?? ''), false)],
			[__('Flagged Files', 'freesiem-sentinel'), $this->summary_value_or_fallback($scan_metrics['files_flagged'] ?? ($filesystem['flagged_files'] ?? ''), false)],
			[__('Scan Duration', 'freesiem-sentinel'), $this->format_duration($scan_metrics['duration_seconds'] ?? '')],
		];

		if (isset($summary['files_content_scanned'])) {
			$metrics[] = [__('Content-Scanned', 'freesiem-sentinel'), number_format_i18n((int) $summary['files_content_scanned'])];
		}

		if (isset($summary['malware_hits'])) {
			$metrics[] = [__('Signature Hits', 'freesiem-sentinel'), number_format_i18n((int) $summary['malware_hits'])];
		}

		if (isset($summary['core_files_modified'])) {
			$metrics[] = [__('Core Files Modified', 'freesiem-sentinel'), number_format_i18n((int) $summary['core_files_modified'])];
		}

		if (isset($summary['database_issues'])) {
			$metrics[] = [__('Database Issues', 'freesiem-sentinel'), number_format_i18n((int) $summary['database_issues'])];
		}

		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;margin-top:10px;">';
		foreach ($metrics as [$label, $value]) {
			echo '<a href="' . esc_url($results_url) . '" style="display:block;padding:10px 12px;border:1px solid #e5e7eb;border-radius:10px;background:#fbfbfc;text-decoration:none;color:inherit;">';
			echo '<span style="display:block;font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:#64748b;">' . esc_html($label) . '</span>';
			echo '<strong style="display:block;font-size:16px;line-height:1.2;margin-top:4px;">' . esc_html((string) $value) . '</strong>';
			echo '</a>';
		}
		echo '</div>';

		if (!empty($summary['last_deep_scan_at'])) {
			echo '<p style="margin:12px 0 0;color:#50575e;font-size:13px;"><strong>' . esc_html__('Last Deep Scan', 'freesiem-sentinel') . ':</strong> ' . esc_html(freesiem_sentinel_format_datetime((string) $summary['last_deep_scan_at']));
			if (!empty($summary['deep_scan_partial'])) {
				echo ' — ' . esc_html__('partial (the next scheduled run continues coverage)', 'freesiem-sentinel');
			}
			echo '</p>';
		}

		if (!empty($scan_metrics['scan_modules']) || !empty($scan_profile)) {
			echo '<p style="margin:6px 0 0;color:#50575e;font-size:13px;"><strong>' . esc_html__('Modules', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->format_scan_modules(!empty($scan_metrics['scan_modules']) ? ['scan_modules' => $scan_metrics['scan_modules']] : $scan_profile)) . '</p>';
		}

		echo '</div>';
	}

	/**
	 * The Scan Configuration form — collapsed by default. "Run Scan" in the top
	 * action bar posts it via its form id.
	 */
	private function render_scan_config_card(array $prefs): void
	{
		$intensity = in_array((string) ($prefs['scan_intensity'] ?? 'balanced'), ['gentle', 'balanced', 'thorough'], true) ? (string) $prefs['scan_intensity'] : 'balanced';
		$cloud_upload_on = !array_key_exists('cloud_upload', $prefs) || !empty($prefs['cloud_upload']);

		echo '<details style="background:#fff;border:1px solid #dcdcde;border-radius:16px;margin:0 0 20px;">';
		echo '<summary style="cursor:pointer;padding:16px 20px;font-size:15px;font-weight:600;">'
			. esc_html__('Scan Configuration', 'freesiem-sentinel')
			. '<span style="font-weight:400;color:#64748b;"> — ' . esc_html__('modules, intensity, exclusions', 'freesiem-sentinel') . '</span></summary>';
		echo '<div style="padding:0 20px 18px;">';

		echo '<form id="fs-scan-config-form" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_run_configured_scan" />';
		echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">';

		echo '<div>';
		echo '<h3 style="margin:0 0 10px;font-size:16px;">' . esc_html__('Scan Modules', 'freesiem-sentinel') . '</h3>';
		foreach ([
			'scan_wordpress' => __('WordPress Configuration Scan', 'freesiem-sentinel'),
			'scan_filesystem' => __('Filesystem Heuristics', 'freesiem-sentinel'),
			'scan_fim' => __('File Integrity Monitoring', 'freesiem-sentinel'),
			'scan_malware' => __('Malware & web-shell signatures (reads file contents)', 'freesiem-sentinel'),
			'scan_core_integrity' => __('WordPress core checksum verification', 'freesiem-sentinel'),
			'scan_plugin_integrity' => __('Plugin checksum verification (WordPress.org)', 'freesiem-sentinel'),
			'scan_database' => __('Database scan (users, options, cron, content)', 'freesiem-sentinel'),
			'scan_uploads_deep' => __('Include the uploads directory in the deep scan', 'freesiem-sentinel'),
		] as $key => $label) {
			echo '<label style="display:block;margin-bottom:8px;font-size:14px;"><input type="checkbox" name="' . esc_attr($key) . '" value="1"' . checked(!empty($prefs[$key]), true, false) . ' /> ' . esc_html($label) . '</label>';
		}
		echo '</div>';

		echo '<div>';
		echo '<h3 style="margin:0 0 10px;font-size:16px;">' . esc_html__('Advanced Options', 'freesiem-sentinel') . '</h3>';
		echo '<p style="margin:0 0 10px;"><label>' . esc_html__('Scan intensity', 'freesiem-sentinel') . '<br /><select name="scan_intensity">';
		foreach (['gentle' => __('Gentle — smallest footprint, slowest', 'freesiem-sentinel'), 'balanced' => __('Balanced (recommended)', 'freesiem-sentinel'), 'thorough' => __('Thorough — finishes sooner, more load', 'freesiem-sentinel')] as $value => $label) {
			echo '<option value="' . esc_attr($value) . '"' . selected($intensity, $value, false) . '>' . esc_html($label) . '</option>';
		}
		echo '</select></label></p>';
		echo '<p style="margin:0 0 10px;"><label>' . esc_html__('Heuristic pass: max files', 'freesiem-sentinel') . '<br /><input type="number" min="100" max="200000" step="100" name="max_files" value="' . esc_attr(freesiem_sentinel_safe_string($prefs['max_files'] ?? '1000')) . '" /></label></p>';
		echo '<p style="margin:0 0 10px;"><label>' . esc_html__('Directory depth limit', 'freesiem-sentinel') . '<br /><input type="number" min="1" max="20" step="1" name="max_depth" value="' . esc_attr(freesiem_sentinel_safe_string($prefs['max_depth'] ?? '5')) . '" /></label></p>';
		echo '<p style="margin:0 0 10px;"><label>' . esc_html__('Exclude paths (one per line, relative to the WordPress root)', 'freesiem-sentinel') . '<br /><textarea name="exclude_paths" rows="3" class="large-text" placeholder="wp-content/uploads/cache">' . esc_textarea(implode("\n", array_map('freesiem_sentinel_safe_string', is_array($prefs['exclude_paths'] ?? null) ? $prefs['exclude_paths'] : []))) . '</textarea></label></p>';
		echo '<p style="margin:0 0 10px;"><label><input type="checkbox" name="include_uploads" value="1"' . checked(!empty($prefs['include_uploads']), true, false) . ' /> ' . esc_html__('Include uploads in the heuristic pass', 'freesiem-sentinel') . '</label></p>';
		echo '<p style="margin:0;"><label><input type="checkbox" name="cloud_upload" value="1"' . checked($cloud_upload_on, true, false) . ' /> ' . esc_html__('Upload results to freeSIEM Core (Cloud)', 'freesiem-sentinel') . '</label></p>';
		echo '</div>';

		echo '</div>';
		echo '<p style="margin:14px 0 0;"><button type="submit" class="button button-primary">' . esc_html__('Save & Run Scan', 'freesiem-sentinel') . '</button></p>';
		echo '</form>';

		echo '</div>';
		echo '</details>';
	}

	private function render_scan_reports_card(array $settings): void
	{
		$next = wp_next_scheduled(Freesiem_Cron::WEEKLY_DEEP_SCAN_HOOK);
		$day = (int) ($settings['deep_scan_weekly_day'] ?? -1);
		$days = [
			-1 => __('Automatic (spread across the week)', 'freesiem-sentinel'),
			0 => __('Sunday', 'freesiem-sentinel'),
			1 => __('Monday', 'freesiem-sentinel'),
			2 => __('Tuesday', 'freesiem-sentinel'),
			3 => __('Wednesday', 'freesiem-sentinel'),
			4 => __('Thursday', 'freesiem-sentinel'),
			5 => __('Friday', 'freesiem-sentinel'),
			6 => __('Saturday', 'freesiem-sentinel'),
		];

		$primary_email = (string) ($settings['report_primary_email'] ?? '');

		if ($primary_email === '') {
			$primary_email = (string) get_option('admin_email');
		}

		echo '<div style="background:#fff;padding:16px 18px;border:1px solid #dcdcde;border-radius:16px;position:sticky;top:40px;">';
		echo '<h2 style="margin:0 0 12px;font-size:16px;">' . esc_html__('Reports & Automation', 'freesiem-sentinel') . '</h2>';

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_save_scan_schedule" />';

		echo '<label style="display:flex;gap:8px;margin-bottom:12px;font-size:14px;"><input type="checkbox" name="deep_scan_weekly_enabled" value="1"' . checked(!empty($settings['deep_scan_weekly_enabled']), true, false) . ' /> ' . esc_html__('Weekly full deep scan', 'freesiem-sentinel') . '</label>';

		echo '<p style="margin:0 0 12px;"><label style="font-size:12px;color:#64748b;display:block;margin-bottom:3px;">' . esc_html__('Preferred day', 'freesiem-sentinel') . '</label><select name="deep_scan_weekly_day" style="width:100%;">';
		foreach ($days as $value => $label) {
			echo '<option value="' . esc_attr((string) $value) . '"' . selected($day, $value, false) . '>' . esc_html($label) . '</option>';
		}
		echo '</select></p>';

		echo '<hr style="border:none;border-top:1px solid #f0f0f1;margin:12px 0;" />';

		echo '<label style="display:flex;gap:8px;margin-bottom:12px;font-size:14px;"><input type="checkbox" name="scan_email_on_weekly" value="1"' . checked(!empty($settings['scan_email_on_weekly']), true, false) . ' /> ' . esc_html__('Email the report after each scan', 'freesiem-sentinel') . '</label>';

		echo '<p style="margin:0 0 12px;"><label style="font-size:12px;color:#64748b;display:block;margin-bottom:3px;">' . esc_html__('Report goes to', 'freesiem-sentinel') . '</label><input type="email" name="report_primary_email" value="' . esc_attr($primary_email) . '" style="width:100%;" /></p>';

		echo '<p style="margin:0 0 12px;"><label style="font-size:12px;color:#64748b;display:block;margin-bottom:3px;">' . esc_html__('Also copy (comma separated)', 'freesiem-sentinel') . '</label><textarea name="scan_email_recipients" rows="2" style="width:100%;" placeholder="ops@example.com">' . esc_textarea((string) ($settings['scan_email_recipients'] ?? '')) . '</textarea></p>';

		if ($next) {
			echo '<p style="margin:0 0 12px;color:#64748b;font-size:12px;"><strong>' . esc_html__('Next run', 'freesiem-sentinel') . ':</strong><br />' . esc_html(freesiem_sentinel_format_datetime(gmdate('c', (int) $next))) . '</p>';
		}

		echo '<button type="submit" class="button button-primary">' . esc_html__('Save', 'freesiem-sentinel') . '</button>';
		echo '</form>';

		echo '</div>';
	}

	private function render_scan_history_card(): void
	{
		$history = $this->plugin->get_results()->get_scan_history();

		echo '<div style="background:#fff;padding:18px 20px;border:1px solid #dcdcde;border-radius:16px;margin:0 0 20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Scan History', 'freesiem-sentinel') . '</h2>';

		if ($history === []) {
			$this->render_empty_state(__('No completed scans recorded yet.', 'freesiem-sentinel'), __('Each completed deep or weekly scan is listed here so you can compare runs over time.', 'freesiem-sentinel'));
			echo '</div>';
			return;
		}

		echo '<div style="overflow-x:auto;">';
		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__('Finished', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Type', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Score', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Crit / High / Med / Low', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Files', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Coverage', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Export', 'freesiem-sentinel') . '</th>'
			. '</tr></thead><tbody>';

		foreach ($history as $row) {
			$counts = freesiem_sentinel_safe_array($row['severity_counts'] ?? []);
			$id = freesiem_sentinel_safe_string($row['id'] ?? '');
			$type = freesiem_sentinel_safe_string($row['type'] ?? 'deep');
			$view_link = $this->build_scan_url(['scan_run' => $id]) . '#fs-scan-run';

			echo '<tr>';
			echo '<td>' . esc_html(freesiem_sentinel_format_datetime((string) ($row['finished_at'] ?? ''))) . '</td>';
			echo '<td>' . esc_html(ucfirst($type)) . (!empty($row['full']) ? ' <span style="color:#16794a;">' . esc_html__('(full)', 'freesiem-sentinel') . '</span>' : '') . '</td>';
			echo '<td><strong>' . esc_html((string) (int) ($row['score'] ?? 0)) . '</strong></td>';
			echo '<td>' . esc_html(sprintf('%d / %d / %d / %d', (int) ($counts['critical'] ?? 0), (int) ($counts['high'] ?? 0), (int) ($counts['medium'] ?? 0), (int) ($counts['low'] ?? 0))) . '</td>';
			echo '<td>' . esc_html(number_format_i18n((int) ($row['files_scanned'] ?? 0))) . '</td>';
			echo '<td>' . (empty($row['partial']) ? esc_html__('Complete', 'freesiem-sentinel') : '<span style="color:#b45309;">' . esc_html__('Partial', 'freesiem-sentinel') . '</span>') . '</td>';

			if (!empty($row['has_detail'])) {
				$json = freesiem_sentinel_admin_post_url('freesiem_sentinel_export_results', ['scan_run' => $id, 'format' => 'json']);
				$csv = freesiem_sentinel_admin_post_url('freesiem_sentinel_export_results', ['scan_run' => $id, 'format' => 'csv']);
				echo '<td style="white-space:nowrap;">'
					. '<a class="button button-small" href="' . esc_url($view_link) . '">' . esc_html__('View', 'freesiem-sentinel') . '</a> '
					. '<button type="button" class="button button-small fs-copy-export" data-url="' . esc_url($json) . '" data-label="' . esc_attr__('JSON', 'freesiem-sentinel') . '">' . esc_html__('Copy JSON', 'freesiem-sentinel') . '</button> '
					. '<button type="button" class="button button-small fs-copy-export" data-url="' . esc_url($csv) . '" data-label="' . esc_attr__('CSV', 'freesiem-sentinel') . '">' . esc_html__('Copy CSV', 'freesiem-sentinel') . '</button>'
					. '</td>';
			} else {
				echo '<td><span style="color:#8c8f94;">' . esc_html__('summary only', 'freesiem-sentinel') . '</span></td>';
			}
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '</div>';
		echo '</div>';

		$this->render_export_copy_script();
	}

	private function render_scan_run_detail(string $id): void
	{
		$run = $this->plugin->get_results()->get_scan_run($id);

		echo '<div id="fs-scan-run" style="background:#fff;padding:18px 20px;border:1px solid #2271b1;border-radius:16px;margin:0 0 20px;">';

		if ($run === null) {
			$this->render_empty_state(__('That scan run is no longer available.', 'freesiem-sentinel'), __('Detailed findings are kept for the most recent runs only.', 'freesiem-sentinel'));
			echo '</div>';
			return;
		}

		$meta = freesiem_sentinel_safe_array($run['meta'] ?? []);
		$findings = array_values(array_filter((array) ($run['findings'] ?? []), 'is_array'));
		$counts = freesiem_sentinel_safe_array($meta['severity_counts'] ?? []);

		echo '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">';
		echo '<h2 style="margin:0;">' . esc_html(sprintf(__('Scan run — %s', 'freesiem-sentinel'), freesiem_sentinel_format_datetime((string) ($meta['finished_at'] ?? '')))) . '</h2>';
		echo '<span style="display:inline-flex;gap:8px;flex-wrap:wrap;align-items:center;">';
		echo $this->render_export_actions(['scan_run' => $id]);
		echo '<a class="button button-secondary" href="' . esc_url($this->build_scan_url(['show_results' => '1']) . '#freesiem-results-section') . '">' . esc_html__('Back to current results', 'freesiem-sentinel') . '</a>';
		echo '</span>';
		echo '</div>';
		$this->render_export_copy_script();
		echo '<p style="color:#50575e;">' . esc_html(sprintf(
			__('%1$s · score %2$d · %3$d critical, %4$d high, %5$d medium, %6$d low · %7$s files scanned%8$s', 'freesiem-sentinel'),
			ucfirst(freesiem_sentinel_safe_string($meta['type'] ?? 'deep')) . (!empty($meta['full']) ? ' (full)' : ''),
			(int) ($meta['score'] ?? 0),
			(int) ($counts['critical'] ?? 0),
			(int) ($counts['high'] ?? 0),
			(int) ($counts['medium'] ?? 0),
			(int) ($counts['low'] ?? 0),
			number_format_i18n((int) ($meta['files_scanned'] ?? 0)),
			!empty($meta['partial']) ? ' · ' . __('partial', 'freesiem-sentinel') : ''
		)) . '</p>';

		if ($findings === []) {
			$this->render_empty_state(__('No findings in this run.', 'freesiem-sentinel'), __('This scan completed without flagging anything.', 'freesiem-sentinel'));
			echo '</div>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__('Severity', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Title', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Category', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Location', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Recommendation', 'freesiem-sentinel') . '</th>'
			. '</tr></thead><tbody>';

		foreach ($findings as $finding) {
			$sev = freesiem_sentinel_normalize_severity((string) ($finding['severity'] ?? 'info'));
			$path = freesiem_sentinel_safe_string($finding['evidence']['path'] ?? '');
			$line = freesiem_sentinel_safe_string($finding['evidence']['line'] ?? '');
			$where = $path !== '' ? $path . ($line !== '' ? ':' . $line : '') : '';
			$size_label = $this->finding_size_label($finding);

			$safe_tag = !empty($finding['acknowledged'])
				? ' <span style="display:inline-block;padding:1px 7px;border-radius:999px;background:#d1fae5;color:#065f46;font-size:11px;font-weight:600;">' . esc_html__('marked safe', 'freesiem-sentinel') . '</span>'
				: '';

			echo '<tr>';
			echo '<td><span style="' . esc_attr($this->severity_badge_style($sev)) . '">' . esc_html(strtoupper($sev)) . '</span></td>';
			echo '<td><strong>' . esc_html(freesiem_sentinel_safe_string($finding['title'] ?? '')) . '</strong>' . $safe_tag . '<br /><span style="color:#50575e;">' . esc_html(freesiem_sentinel_safe_string($finding['description'] ?? '')) . '</span></td>';
			echo '<td>' . esc_html(freesiem_sentinel_safe_string($finding['category'] ?? '')) . '</td>';
			echo '<td><code style="font-size:12px;">' . esc_html($where) . '</code>'
				. ($size_label !== '' ? '<br /><small style="color:#646970;">' . esc_html($size_label) . '</small>' : '')
				. '</td>';
			echo '<td>' . esc_html(freesiem_sentinel_safe_string($finding['recommendation'] ?? '')) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '</div>';
	}

	public function render_local_scan_page(): void
	{
		$this->render_scan_page();
	}

	public function render_results_page(): void
	{
		$this->render_scan_page();
	}

	public function render_remote_page(): void
	{
		$this->assert_manage_permissions();

		$settings = freesiem_sentinel_get_settings();
		$state = (string) ($settings['connection_state'] ?? 'disconnected');
		$is_connected = Freesiem_Cloud_Connect_State::is_connected($settings);
		$email = safe($settings['email'] ?? '');
		$phone = freesiem_sentinel_format_phone((string) ($settings['phone'] ?? ''));
		$can_connect = is_email($email) && freesiem_sentinel_is_valid_us_phone((string) ($settings['phone'] ?? ''));
		$site_id = safe($settings['site_id'] ?? '');
		$last_heartbeat = $this->summary_value_or_fallback($settings['last_heartbeat_at'] ?? '', true);
		$last_heartbeat_result = safe($settings['last_heartbeat_result'] ?? '');

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('freeSIEM Cloud', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('Connect this site to freeSIEM Core, verify ownership, and manage signed Cloud Connect communication.', 'freesiem-sentinel') . '</p>';

		echo '<div style="display:grid;grid-template-columns:minmax(0,2fr) minmax(280px,1fr);gap:20px;align-items:start;">';
		echo '<div>';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Cloud Connect', 'freesiem-sentinel') . '</h2>';

		if (in_array($state, ['suspended', 'revoked'], true)) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__('This Cloud Connect session is no longer active. Disconnect locally, then reconnect to establish a new session.', 'freesiem-sentinel') . '</p></div>';
		}

		if ($is_connected) {
			echo '<div style="margin-top:16px;padding:16px;border-radius:12px;background:#ecfdf5;border:1px solid #a7f3d0;">';
			echo '<p style="margin:0 0 10px;font-weight:700;color:#166534;">' . esc_html__('Connected', 'freesiem-sentinel') . '</p>';
			echo '<p style="margin:0 0 8px;">' . esc_html__('This site can send signed heartbeats to freeSIEM Core.', 'freesiem-sentinel') . '</p>';
			echo '<p style="margin:0;"><strong>' . esc_html__('Site ID', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->friendly_site_id($site_id)) . '</p>';
			echo '</div>';
			echo '<p style="margin-top:16px;"><a class="button button-secondary" href="' . esc_url(freesiem_sentinel_admin_post_url('freesiem_sentinel_cloud_connect_test')) . '">' . esc_html__('Test Connection', 'freesiem-sentinel') . '</a> ';
			echo '<a class="button button-secondary" onclick="return confirm(\''
				. esc_js(__('Disconnect this site from freeSIEM Cloud?', 'freesiem-sentinel'))
				. '\');" href="' . esc_url(freesiem_sentinel_admin_post_url('freesiem_sentinel_cloud_connect_disconnect')) . '">' . esc_html__('Disconnect', 'freesiem-sentinel') . '</a></p>';
		} elseif ($state === 'pending_verification') {
			echo '<p style="margin-top:16px;">' . esc_html__('A verification code was sent to the provided contact. Enter it below to finish connecting this site.', 'freesiem-sentinel') . '</p>';
			echo '<p><strong>' . esc_html__('Email', 'freesiem-sentinel') . ':</strong> ' . esc_html($email) . '</p>';
			echo '<p><strong>' . esc_html__('Phone', 'freesiem-sentinel') . ':</strong> ' . esc_html($phone) . '</p>';
			if (!empty($settings['connect_expires_at'])) {
				echo '<p><strong>' . esc_html__('Code Expires', 'freesiem-sentinel') . ':</strong> ' . esc_html(freesiem_sentinel_format_datetime((string) $settings['connect_expires_at'])) . '</p>';
			}
			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:16px;">';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<input type="hidden" name="action" value="freesiem_sentinel_cloud_connect_verify" />';
			echo '<table class="form-table" role="presentation">';
			echo '<tr><th scope="row"><label for="freesiem-cloud-connect-code">' . esc_html__('Verification Code', 'freesiem-sentinel') . '</label></th><td><input class="regular-text" id="freesiem-cloud-connect-code" name="verification_code" type="text" inputmode="numeric" autocomplete="one-time-code" value="" required /></td></tr>';
			echo '</table>';
			submit_button(__('Verify', 'freesiem-sentinel'), 'primary', '', false);
			echo ' <a class="button button-secondary" href="' . esc_url(freesiem_sentinel_admin_post_url('freesiem_sentinel_cloud_connect_reset')) . '">' . esc_html__('Cancel / Reset', 'freesiem-sentinel') . '</a>';
			echo '</form>';
		} else {
			echo '<p style="margin-top:16px;">' . esc_html__('Save this site contact info locally first, then connect using the saved email and phone number.', 'freesiem-sentinel') . '</p>';
			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<input type="hidden" name="action" value="freesiem_sentinel_save_cloud_connect_contact" />';
			echo '<table class="form-table" role="presentation">';
			echo '<tr><th scope="row"><label for="freesiem-cloud-connect-email">' . esc_html__('Email', 'freesiem-sentinel') . '</label></th><td><input class="regular-text" id="freesiem-cloud-connect-email" name="email" type="email" value="' . esc_attr($email) . '" required /></td></tr>';
			echo '<tr><th scope="row"><label for="freesiem-cloud-connect-phone">' . esc_html__('US Phone Number', 'freesiem-sentinel') . '</label></th><td><input class="regular-text" id="freesiem-cloud-connect-phone" name="phone" type="tel" value="' . esc_attr($phone) . '" placeholder="+1 (555) 234-5678" required /></td></tr>';
			echo '</table>';
			submit_button(__('Save', 'freesiem-sentinel'), 'secondary', '', false);
			echo '</form>';
			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:12px;">';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<input type="hidden" name="action" value="freesiem_sentinel_cloud_connect_start" />';
			submit_button(__('Connect', 'freesiem-sentinel'), 'primary', '', false, $can_connect ? [] : ['disabled' => 'disabled']);
			if (!$can_connect) {
				echo '<p class="description" style="margin-top:8px;">' . esc_html__('Save a valid email and US phone number to enable Connect.', 'freesiem-sentinel') . '</p>';
			}
			echo '</form>';
		}
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Automation & Access Control', 'freesiem-sentinel') . '</h2>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_save_cloud_preferences" />';
		echo '<p><label><input type="checkbox" name="allow_remote_scan" value="1"' . checked(!empty($settings['allow_remote_scan']), true, false) . ' /> ' . esc_html__('Allow Remote Scans', 'freesiem-sentinel') . '</label></p>';
		echo '<p><strong>' . esc_html__('Scan Frequency', 'freesiem-sentinel') . '</strong></p>';
		echo '<p><label><input type="radio" name="scan_frequency" value="manual"' . checked(($settings['scan_frequency'] ?? 'daily') === 'manual', true, false) . ' /> ' . esc_html__('Manual only', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label><input type="radio" name="scan_frequency" value="daily"' . checked(($settings['scan_frequency'] ?? 'daily') === 'daily', true, false) . ' /> ' . esc_html__('Once daily', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label><input type="radio" name="scan_frequency" value="6hours"' . checked(($settings['scan_frequency'] ?? 'daily') === '6hours', true, false) . ' /> ' . esc_html__('Every 6 hours', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label><input type="radio" name="scan_frequency" value="hourly"' . checked(($settings['scan_frequency'] ?? 'daily') === 'hourly', true, false) . ' /> ' . esc_html__('Every hour', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label><input type="checkbox" name="user_sync_enabled" value="1"' . checked(!empty($settings['user_sync_enabled']), true, false) . ' /> ' . esc_html__('Enable Centralized User Sync', 'freesiem-sentinel') . '</label><br /><span style="color:#50575e;">' . esc_html__('Enable centralized user sync so this site can share managed users with the freeSIEM client portal. This allows authorized users to be synced across multiple WordPress sites and managed centrally, including password updates and future security controls like TFA.', 'freesiem-sentinel') . '</span></p>';
		echo '<hr style="margin:20px 0;" />';
		echo '<h3 style="margin-top:0;">' . esc_html__('Pending Task Approvals', 'freesiem-sentinel') . '</h3>';
		echo '<p><label><input type="checkbox" name="enable_pending_task_queue" value="1"' . checked(!empty($settings['enable_pending_task_queue']), true, false) . ' /> ' . esc_html__('Enable the Pending Tasks approval queue', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label><input type="checkbox" name="auto_approve_enabled_default" value="1"' . checked(!empty($settings['auto_approve_enabled_default']), true, false) . ' /> ' . esc_html__('Allow eligible tasks to auto-approve after a timeout', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label>' . esc_html__('Default auto-approve timeout (minutes)', 'freesiem-sentinel') . '<br /><input type="number" min="1" max="1440" name="auto_approve_after_minutes_default" value="' . esc_attr((string) ($settings['auto_approve_after_minutes_default'] ?? 30)) . '" /></label></p>';
		echo '<p style="margin-bottom:8px;"><strong>' . esc_html__('Require Manual Approval', 'freesiem-sentinel') . '</strong></p>';
		foreach ([
			'require_manual_approval_for_list_users' => __('List users', 'freesiem-sentinel'),
			'require_manual_approval_for_create_user' => __('Create user', 'freesiem-sentinel'),
			'require_manual_approval_for_update_user' => __('Update user', 'freesiem-sentinel'),
			'require_manual_approval_for_password_reset' => __('Send password reset', 'freesiem-sentinel'),
			'require_manual_approval_for_delete_user' => __('Delete user', 'freesiem-sentinel'),
		] as $key => $label) {
			echo '<p style="margin:0 0 6px;"><label><input type="checkbox" name="' . esc_attr($key) . '" value="1"' . checked(!empty($settings[$key]), true, false) . ' /> ' . esc_html($label) . '</label></p>';
		}
		echo '<p style="margin:16px 0 8px;"><strong>' . esc_html__('Allow Auto-Approve', 'freesiem-sentinel') . '</strong></p>';
		foreach ([
			'allow_auto_approve_list_users' => __('List users', 'freesiem-sentinel'),
			'allow_auto_approve_create_user' => __('Create user', 'freesiem-sentinel'),
			'allow_auto_approve_update_user' => __('Update user', 'freesiem-sentinel'),
			'allow_auto_approve_password_reset' => __('Send password reset', 'freesiem-sentinel'),
			'allow_auto_approve_delete_user' => __('Delete user', 'freesiem-sentinel'),
		] as $key => $label) {
			echo '<p style="margin:0 0 6px;"><label><input type="checkbox" name="' . esc_attr($key) . '" value="1"' . checked(!empty($settings[$key]), true, false) . ' /> ' . esc_html($label) . '</label></p>';
		}
		$roles = function_exists('wp_roles') && wp_roles() ? wp_roles()->roles : [];
		echo '<p style="margin:16px 0 8px;"><strong>' . esc_html__('Roles Allowed To Approve Tasks', 'freesiem-sentinel') . '</strong></p>';
		foreach ($roles as $role_key => $role) {
			echo '<p style="margin:0 0 6px;"><label><input type="checkbox" name="roles_allowed_to_approve_tasks[]" value="' . esc_attr((string) $role_key) . '"' . checked(in_array((string) $role_key, (array) ($settings['roles_allowed_to_approve_tasks'] ?? []), true), true, false) . ' /> ' . esc_html(translate_user_role((string) ($role['name'] ?? $role_key))) . '</label></p>';
		}
		echo '<p><label><input type="checkbox" name="notify_admins_on_pending_task" value="1"' . checked(!empty($settings['notify_admins_on_pending_task']), true, false) . ' /> ' . esc_html__('Notify the site admin email when a task enters the queue', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label><input type="checkbox" name="include_pending_tasks_in_heartbeat" value="1"' . checked(!empty($settings['include_pending_tasks_in_heartbeat']), true, false) . ' /> ' . esc_html__('Include pending task data in heartbeats', 'freesiem-sentinel') . '</label></p>';
		echo '<p><label><input type="checkbox" name="heartbeat_include_recent_completed_tasks" value="1"' . checked(!empty($settings['heartbeat_include_recent_completed_tasks']), true, false) . ' /> ' . esc_html__('Include recent completed and denied task updates in heartbeats', 'freesiem-sentinel') . '</label></p>';
		submit_button(__('Save Cloud Preferences', 'freesiem-sentinel'));
		echo '</form>';
		echo '</div>';
		echo '</div>';

		echo '<div>';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Status', 'freesiem-sentinel') . '</h2>';
		echo '<table class="widefat striped" style="border:none;box-shadow:none;"><tbody>';
		echo '<tr><td><strong>' . esc_html__('Connection State', 'freesiem-sentinel') . '</strong></td><td>' . esc_html($this->format_connection_state($state)) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('Connected Email', 'freesiem-sentinel') . '</strong></td><td>' . esc_html($email !== '' ? $email : __('Not set', 'freesiem-sentinel')) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('Connected Phone', 'freesiem-sentinel') . '</strong></td><td>' . esc_html($phone !== '' ? $phone : __('Not set', 'freesiem-sentinel')) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('Site ID', 'freesiem-sentinel') . '</strong></td><td>' . esc_html($site_id !== '' ? $this->friendly_site_id($site_id) : __('Not assigned', 'freesiem-sentinel')) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('Last Heartbeat', 'freesiem-sentinel') . '</strong></td><td>' . esc_html($last_heartbeat) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('Last Result', 'freesiem-sentinel') . '</strong></td><td>' . esc_html($last_heartbeat_result !== '' ? $last_heartbeat_result : __('No heartbeat sent yet.', 'freesiem-sentinel')) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('Remote Scan Allowed', 'freesiem-sentinel') . '</strong></td><td>' . esc_html(!empty($settings['allow_remote_scan']) ? __('Yes', 'freesiem-sentinel') : __('No', 'freesiem-sentinel')) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('Scan Frequency', 'freesiem-sentinel') . '</strong></td><td>' . esc_html(safe($settings['scan_frequency'] ?? 'daily')) . '</td></tr>';
		echo '<tr><td><strong>' . esc_html__('User Sync Enabled', 'freesiem-sentinel') . '</strong></td><td>' . esc_html(!empty($settings['user_sync_enabled']) ? __('Yes', 'freesiem-sentinel') : __('No', 'freesiem-sentinel')) . '</td></tr>';
		echo '</tbody></table>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Stored Credentials', 'freesiem-sentinel') . '</h2>';
		echo '<p>' . esc_html__('API credentials are stored locally and never shown in plain text here.', 'freesiem-sentinel') . '</p>';
		echo '<p><strong>' . esc_html__('API Key', 'freesiem-sentinel') . ':</strong> <code>' . esc_html(freesiem_sentinel_mask_secret((string) ($settings['api_key'] ?? ''))) . '</code></p>';
		echo '<p><strong>' . esc_html__('HMAC Secret', 'freesiem-sentinel') . ':</strong> <code>' . esc_html(freesiem_sentinel_mask_secret((string) ($settings['hmac_secret'] ?? ''))) . '</code></p>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}

	public function render_cloud_connect_page(): void
	{
		$this->render_remote_page();
	}

	public function render_pending_tasks_page(): void
	{
		$this->assert_task_permissions();

		$service = $this->plugin->get_pending_tasks();
		$task_id = isset($_GET['task_id']) ? (int) $_GET['task_id'] : 0;
		$status_filter = isset($_GET['status']) ? sanitize_key(wp_unslash((string) $_GET['status'])) : '';
		$search = isset($_GET['s']) ? sanitize_text_field(wp_unslash((string) $_GET['s'])) : '';
		$task = $task_id > 0 ? $service->get_task($task_id) : null;

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('Pending Tasks', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('Review signed remote user-management requests from freeSIEM Core before they execute locally in WordPress.', 'freesiem-sentinel') . '</p>';

		if (is_array($task)) {
			$this->render_pending_task_detail($task);
			echo '</div>';
			return;
		}

		$tasks = $service->list_tasks([
			'status' => $status_filter,
			'search' => $search,
			'limit' => 100,
		]);
		$summary = $service->build_heartbeat_payload(freesiem_sentinel_get_settings());

		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:20px 0;">';
		$this->render_summary_stat(__('Pending', 'freesiem-sentinel'), (string) (($summary['task_status_summary']['pending'] ?? 0)));
		$this->render_summary_stat(__('Approved', 'freesiem-sentinel'), (string) (($summary['task_status_summary']['approved'] ?? 0)));
		$this->render_summary_stat(__('Auto Approved', 'freesiem-sentinel'), (string) (($summary['task_status_summary']['auto_approved'] ?? 0)));
		$this->render_summary_stat(__('Completed', 'freesiem-sentinel'), (string) (($summary['task_status_summary']['completed'] ?? 0)));
		$this->render_summary_stat(__('Failed', 'freesiem-sentinel'), (string) (($summary['task_status_summary']['failed'] ?? 0)));
		echo '</div>';

		echo '<div style="background:#fff;padding:16px 18px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">';
		echo '<input type="hidden" name="page" value="freesiem-pending-tasks" />';
		echo '<p style="margin:0;"><label>' . esc_html__('Status', 'freesiem-sentinel') . '<br /><select name="status"><option value="">' . esc_html__('All statuses', 'freesiem-sentinel') . '</option>';
		foreach ($service->get_status_options() as $status) {
			echo '<option value="' . esc_attr($status) . '"' . selected($status_filter === $status, true, false) . '>' . esc_html(ucwords(str_replace('_', ' ', $status))) . '</option>';
		}
		echo '</select></label></p>';
		echo '<p style="margin:0;"><label>' . esc_html__('Search', 'freesiem-sentinel') . '<br /><input class="regular-text" type="search" name="s" value="' . esc_attr($search) . '" /></label></p>';
		echo '<p style="margin:0;"><button type="submit" class="button button-secondary">' . esc_html__('Filter Tasks', 'freesiem-sentinel') . '</button></p>';
		echo '</form>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Task Queue', 'freesiem-sentinel') . '</h2>';

		if ($tasks === []) {
			$this->render_empty_state(__('No tasks yet.', 'freesiem-sentinel'), __('Pending task requests from freeSIEM Core will appear here as they are submitted.', 'freesiem-sentinel'));
		} else {
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Task ID', 'freesiem-sentinel') . '</th><th>' . esc_html__('Core Task ID', 'freesiem-sentinel') . '</th><th>' . esc_html__('Action', 'freesiem-sentinel') . '</th><th>' . esc_html__('Target', 'freesiem-sentinel') . '</th><th>' . esc_html__('Requested At', 'freesiem-sentinel') . '</th><th>' . esc_html__('Auto Approve At', 'freesiem-sentinel') . '</th><th>' . esc_html__('Status', 'freesiem-sentinel') . '</th><th>' . esc_html__('Source', 'freesiem-sentinel') . '</th><th>' . esc_html__('Actions', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach ($tasks as $row) {
				$view_url = add_query_arg('task_id', (string) ($row['id'] ?? 0));
				$approve_url = freesiem_sentinel_admin_post_url('freesiem_sentinel_approve_task', ['task_id' => (string) ($row['id'] ?? 0)]);
				echo '<tr>';
				echo '<td><a href="' . esc_url($view_url) . '">#' . esc_html((string) ($row['id'] ?? 0)) . '</a></td>';
				echo '<td><code>' . esc_html((string) ($row['core_task_id'] ?? '')) . '</code></td>';
				echo '<td>' . esc_html(ucwords(str_replace('_', ' ', (string) ($row['action_type'] ?? '')))) . '</td>';
				echo '<td>' . esc_html($this->task_target_summary($row)) . '</td>';
				echo '<td>' . esc_html(freesiem_sentinel_format_datetime((string) ($row['requested_at'] ?? ''))) . '</td>';
				echo '<td>' . esc_html(!empty($row['auto_approve_at']) ? freesiem_sentinel_format_datetime((string) $row['auto_approve_at']) : __('Manual only', 'freesiem-sentinel')) . '</td>';
				echo '<td><span style="' . esc_attr($this->task_status_badge_style((string) ($row['status'] ?? 'pending'))) . '">' . esc_html(ucwords(str_replace('_', ' ', (string) ($row['status'] ?? 'pending')))) . '</span></td>';
				echo '<td>' . esc_html((string) ($row['source_core_identifier'] ?? 'freeSIEM Core')) . '</td>';
				echo '<td><a class="button button-secondary" href="' . esc_url($view_url) . '">' . esc_html__('View', 'freesiem-sentinel') . '</a> ';
				if (($row['status'] ?? '') === 'pending') {
					echo '<a class="button button-primary" href="' . esc_url($approve_url) . '">' . esc_html__('Approve', 'freesiem-sentinel') . '</a>';
				}
				echo '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}

		echo '</div>';
		echo '</div>';
	}

	public function render_tfa_page(): void
	{
		$this->assert_manage_permissions();

		$service = $this->plugin->get_tfa_service();
		$selected_user_id = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;
		$selected_user = $selected_user_id > 0 ? get_user_by('id', $selected_user_id) : null;
		$selected_state = $selected_user instanceof WP_User ? $service->get_user_tfa_state((int) $selected_user->ID) : null;
		$selected_secret = $selected_user instanceof WP_User && is_array($selected_state) && $selected_state['tfa_status'] === Freesiem_TFA_Service::STATUS_PENDING_SETUP
			? $service->get_secret((int) $selected_user->ID)
			: '';
		$selected_otpauth = $selected_user instanceof WP_User && is_string($selected_secret) && $selected_secret !== ''
			? $service->build_otpauth_uri($selected_user, $selected_secret)
			: '';
		$users = get_users(['orderby' => 'login', 'order' => 'ASC']);

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('TFA (2FA)', 'freesiem-sentinel') . '</h1>';
		echo '<p>' . esc_html__('Manage local and Core-managed TFA state for WordPress users without exposing secrets in APIs, logs, or status payloads.', 'freesiem-sentinel') . '</p>';

		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:20px 0;">';
		$this->render_summary_stat(__('Enabled', 'freesiem-sentinel'), (string) count(array_filter($users, fn($user): bool => $user instanceof WP_User && $service->get_user_tfa_state((int) $user->ID)['tfa_status'] === Freesiem_TFA_Service::STATUS_ENABLED)));
		$this->render_summary_stat(__('Pending Setup', 'freesiem-sentinel'), (string) count(array_filter($users, fn($user): bool => $user instanceof WP_User && $service->get_user_tfa_state((int) $user->ID)['tfa_status'] === Freesiem_TFA_Service::STATUS_PENDING_SETUP)));
		$this->render_summary_stat(__('Core Managed', 'freesiem-sentinel'), (string) count(array_filter($users, fn($user): bool => $user instanceof WP_User && $service->is_core_managed((int) $user->ID))));
		$this->render_summary_stat(__('Local Managed', 'freesiem-sentinel'), (string) count(array_filter($users, fn($user): bool => $user instanceof WP_User && !$service->is_core_managed((int) $user->ID))));
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('User TFA Status', 'freesiem-sentinel') . '</h2>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Username', 'freesiem-sentinel') . '</th><th>' . esc_html__('Email', 'freesiem-sentinel') . '</th><th>' . esc_html__('Status', 'freesiem-sentinel') . '</th><th>' . esc_html__('Source', 'freesiem-sentinel') . '</th><th>' . esc_html__('Managed By', 'freesiem-sentinel') . '</th><th>' . esc_html__('Last Verified', 'freesiem-sentinel') . '</th><th>' . esc_html__('Actions', 'freesiem-sentinel') . '</th></tr></thead><tbody>';

		foreach ($users as $user) {
			if (!$user instanceof WP_User) {
				continue;
			}

			$state = $service->get_user_tfa_state((int) $user->ID);
			$view_url = add_query_arg('user_id', (string) $user->ID);
			$enroll_url = freesiem_sentinel_admin_post_url('freesiem_sentinel_tfa_enroll', ['user_id' => (string) $user->ID]);
			$reset_url = freesiem_sentinel_admin_post_url('freesiem_sentinel_tfa_reset', ['user_id' => (string) $user->ID]);
			echo '<tr>';
			echo '<td><a href="' . esc_url($view_url) . '"><strong>' . esc_html((string) $user->user_login) . '</strong></a></td>';
			echo '<td>' . esc_html((string) $user->user_email) . '</td>';
			echo '<td><span style="' . esc_attr($this->tfa_status_badge_style($state['tfa_status'])) . '">' . esc_html($this->format_tfa_label($state['tfa_status'])) . '</span></td>';
			echo '<td><span style="' . esc_attr($this->tfa_meta_badge_style($state['tfa_source'])) . '">' . esc_html(ucfirst($state['tfa_source'])) . '</span></td>';
			echo '<td><span style="' . esc_attr($this->tfa_meta_badge_style($state['tfa_managed'])) . '">' . esc_html(ucfirst($state['tfa_managed'])) . '</span></td>';
			echo '<td>' . esc_html($state['last_verified_at'] !== '' ? freesiem_sentinel_format_datetime($state['last_verified_at']) : __('Never', 'freesiem-sentinel')) . '</td>';
			echo '<td><a class="button button-secondary" href="' . esc_url($view_url) . '">' . esc_html__('View', 'freesiem-sentinel') . '</a> ';
			if ($service->local_actions_allowed((int) $user->ID)) {
				echo '<a class="button button-secondary" href="' . esc_url($enroll_url) . '">' . esc_html__('Enroll TFA', 'freesiem-sentinel') . '</a> ';
				echo '<a class="button button-secondary" href="' . esc_url($reset_url) . '">' . esc_html__('Reset TFA', 'freesiem-sentinel') . '</a>';
			} else {
				echo '<span style="color:#50575e;">' . esc_html__('Core-managed', 'freesiem-sentinel') . '</span>';
			}
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '</div>';

		if ($selected_user instanceof WP_User && is_array($selected_state)) {
			echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-top:20px;">';
			echo '<h2 style="margin-top:0;">' . esc_html(sprintf(__('TFA Details: %s', 'freesiem-sentinel'), $selected_user->user_login)) . '</h2>';
			echo '<p><strong>' . esc_html__('Status', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->format_tfa_label($selected_state['tfa_status'])) . '</p>';
			echo '<p><strong>' . esc_html__('Managed By', 'freesiem-sentinel') . ':</strong> ' . esc_html(ucfirst($selected_state['tfa_managed'])) . '</p>';

			if ($selected_state['tfa_managed'] === Freesiem_TFA_Service::MANAGED_CORE) {
				echo '<p style="color:#50575e;">' . esc_html__('This account is Core-managed. Local enroll, reset, and password changes are disabled, but local WordPress login enforcement still applies.', 'freesiem-sentinel') . '</p>';
			} else {
				echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">';
				echo '<div>';
				echo '<h3 style="margin-top:0;">' . esc_html__('Change Password', 'freesiem-sentinel') . '</h3>';
				echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
				wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
				echo '<input type="hidden" name="action" value="freesiem_sentinel_tfa_change_password" />';
				echo '<input type="hidden" name="user_id" value="' . esc_attr((string) $selected_user->ID) . '" />';
				echo '<p><label>' . esc_html__('New Password', 'freesiem-sentinel') . '<br /><input type="text" name="password" class="regular-text" value="" autocomplete="new-password" /></label></p>';
				echo '<p><button type="submit" class="button button-primary">' . esc_html__('Change Password', 'freesiem-sentinel') . '</button></p>';
				echo '</form>';
				echo '</div>';

				echo '<div>';
				echo '<h3 style="margin-top:0;">' . esc_html__('Enrollment', 'freesiem-sentinel') . '</h3>';
				if ($selected_state['tfa_status'] === Freesiem_TFA_Service::STATUS_PENDING_SETUP && is_string($selected_secret) && $selected_secret !== '') {
					echo '<p>' . esc_html__('Scan the setup data with an authenticator app, then submit the first verification code.', 'freesiem-sentinel') . '</p>';
					echo '<p><strong>' . esc_html__('Manual Setup Key', 'freesiem-sentinel') . ':</strong><br /><code>' . esc_html($selected_secret) . '</code></p>';
					echo '<p><strong>' . esc_html__('Authenticator URI', 'freesiem-sentinel') . ':</strong><br /><code style="word-break:break-all;">' . esc_html($selected_otpauth) . '</code></p>';
					echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
					wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
					echo '<input type="hidden" name="action" value="freesiem_sentinel_tfa_complete_setup" />';
					echo '<input type="hidden" name="user_id" value="' . esc_attr((string) $selected_user->ID) . '" />';
					echo '<p><label>' . esc_html__('Verification Code', 'freesiem-sentinel') . '<br /><input type="text" name="tfa_code" class="regular-text" inputmode="numeric" autocomplete="one-time-code" value="" /></label></p>';
					echo '<p><button type="submit" class="button button-primary">' . esc_html__('Complete Pending Setup', 'freesiem-sentinel') . '</button></p>';
					echo '</form>';
				} else {
					echo '<p>' . esc_html__('Start a fresh local enrollment if this user needs a new authenticator binding.', 'freesiem-sentinel') . '</p>';
					echo '<p><a class="button button-secondary" href="' . esc_url(freesiem_sentinel_admin_post_url('freesiem_sentinel_tfa_enroll', ['user_id' => (string) $selected_user->ID])) . '">' . esc_html__('Enroll TFA', 'freesiem-sentinel') . '</a></p>';
				}
				echo '</div>';
				echo '</div>';
			}

			echo '</div>';
		}

		echo '</div>';
	}

	public function render_ssl_page(): void
	{
		$this->assert_manage_permissions();

		$tab = isset($_GET['tab']) ? sanitize_key((string) wp_unslash($_GET['tab'])) : 'overview';
		if (!in_array($tab, ['overview', 'preflight', 'dry-run', 'logs'], true)) {
			$tab = 'overview';
		}

		$ssl_settings = freesiem_sentinel_get_ssl_settings();
		$preflight = freesiem_sentinel_get_ssl_preflight();
		$dry_run = freesiem_sentinel_get_ssl_dry_run();
		$environment = freesiem_sentinel_get_ssl_environment_snapshot($ssl_settings);
		$readiness = freesiem_sentinel_calculate_ssl_readiness($ssl_settings, $environment, $preflight);
		$ssl_state = freesiem_sentinel_get_ssl_state();
		$install_environment = freesiem_sentinel_detect_ssl_install_environment();
		$logs = array_reverse(freesiem_sentinel_get_ssl_logs());

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('SSL / HTTPS', 'freesiem-sentinel') . '</h1>';
		echo '<div class="notice notice-warning inline"><p>' . esc_html__('Sentinel now supports explicit admin-triggered certbot actions plus nginx SSL apply. Force HTTPS and HSTS are both applied through the nginx workflow when enabled. Apache automation is still not included in this version.', 'freesiem-sentinel') . '</p></div>';
		echo '<nav class="nav-tab-wrapper" style="margin-bottom:20px;">';
		foreach ([
			'overview' => __('Overview', 'freesiem-sentinel'),
			'preflight' => __('Preflight', 'freesiem-sentinel'),
			'dry-run' => __('Dry Run', 'freesiem-sentinel'),
			'logs' => __('Logs', 'freesiem-sentinel'),
		] as $slug => $label) {
			// add_query_arg() (no base URL) rewrites just ?tab= on the current request, so this
			// keeps working whether SSL is reached at its own URL or nested under Security -- it
			// naturally preserves page=freesiem-security&section=ssl instead of hardcoding page=freesiem-ssl.
			$url = add_query_arg('tab', $slug);
			$class = $tab === $slug ? 'nav-tab nav-tab-active' : 'nav-tab';
			echo '<a class="' . esc_attr($class) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
		}
		echo '</nav>';

		if ($tab === 'overview') {
			$this->render_ssl_overview_tab($ssl_settings, $preflight, $dry_run, $readiness, $environment, $ssl_state, $install_environment);
		} elseif ($tab === 'preflight') {
			$this->render_ssl_preflight_tab($preflight);
		} elseif ($tab === 'dry-run') {
			$this->render_ssl_dry_run_tab($ssl_settings, $dry_run, $readiness, $environment, $ssl_state);
		} else {
			$this->render_ssl_logs_tab($logs, $preflight, $dry_run, $ssl_state);
		}

		echo '</div>';
	}

	public function render_settings_page(): void
	{
		$this->assert_manage_permissions();

		// maybe_auto_update_from_settings_page() (admin_init) already ran this exact check
		// earlier in this request -- reuse its result instead of hitting GitHub again. If an
		// update was available, that hook already redirected into the update flow and this
		// render never runs; getting here means it already confirmed there's nothing to install.
		$update_check = $this->settings_update_check ?? $this->plugin->get_updater()->refresh_plugin_update_state();

		$tabs = $this->get_settings_tabs();
		$current_tab = $this->get_settings_current_tab();

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__('Settings', 'freesiem-sentinel') . '</h1>';
		echo '<h2 class="nav-tab-wrapper">';
		foreach ($tabs as $tab => $config) {
			$url = freesiem_sentinel_admin_page_url('freesiem-settings', ['tab' => $tab]);
			echo '<a class="nav-tab ' . esc_attr($tab === $current_tab ? 'nav-tab-active' : '') . '" href="' . esc_url($url) . '">' . esc_html((string) $config['label']) . '</a>';
		}
		echo '</h2>';

		if ($current_tab === 'about') {
			$this->render_settings_about_tab($update_check);
		} else {
			$this->render_settings_general_tab();
		}

		echo '</div>';
	}

	private function render_settings_general_tab(): void
	{
		$settings = freesiem_sentinel_get_settings();
		$providers = freesiem_sentinel_get_rustfs_provider_definitions();
		$provider = (string) ($settings['rustfs_provider'] ?? 'rustfs');
		$provider_def = $providers[$provider] ?? $providers['rustfs'];
		$configured = freesiem_sentinel_rustfs_is_configured($settings);
		$secret_placeholder = freesiem_sentinel_get_rustfs_secret_placeholder();

		echo '<p style="margin-top:16px;">' . esc_html__('General plugin settings, including remote storage used by Export and Purge backups.', 'freesiem-sentinel') . '</p>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-top:16px;max-width:760px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('RustFS / S3-Compatible Storage', 'freesiem-sentinel') . '</h2>';
		echo '<p class="description">' . esc_html__('Optional remote object storage for backup packages -- works with RustFS, MinIO, AWS S3, or any other S3-compatible provider.', 'freesiem-sentinel') . '</p>';
		echo '<p><strong>' . esc_html__('Status:', 'freesiem-sentinel') . '</strong> ' . ($configured ? '<span style="color:#1f8f5f;">' . esc_html__('Configured', 'freesiem-sentinel') . '</span>' : '<span style="color:#b32d2e;">' . esc_html__('Not configured', 'freesiem-sentinel') . '</span>') . '</p>';

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_save_rustfs_settings" />';
		echo '<table class="form-table" role="presentation">';
		$this->render_ssl_checkbox_field('rustfs_enabled', __('Enable remote storage', 'freesiem-sentinel'), !empty($settings['rustfs_enabled']), __('Turns on RustFS/S3 as an available storage destination for backup packages.', 'freesiem-sentinel'));

		echo '<tr><th scope="row"><label for="freesiem-rustfs-provider">' . esc_html__('Provider', 'freesiem-sentinel') . '</label></th><td>';
		echo '<select id="freesiem-rustfs-provider" name="rustfs_provider">';
		foreach ($providers as $key => $def) {
			echo '<option value="' . esc_attr($key) . '" ' . selected($provider, $key, false) . '>' . esc_html((string) $def['label']) . '</option>';
		}
		echo '</select>';
		echo '<p class="description">' . esc_html((string) $provider_def['endpoint_hint']) . '</p>';
		echo '</td></tr>';

		$this->render_ssl_text_field('rustfs_endpoint', __('S3 API Endpoint', 'freesiem-sentinel'), (string) $settings['rustfs_endpoint'], sprintf(/* translators: %s: example endpoint URL */ __('The S3 API host, e.g. %s -- not the web console.', 'freesiem-sentinel'), (string) $provider_def['endpoint_placeholder']));
		$this->render_ssl_text_field('rustfs_console_url', __('Console URL (optional)', 'freesiem-sentinel'), (string) $settings['rustfs_console_url'], (string) $provider_def['console_hint']);
		$this->render_ssl_text_field('rustfs_region', __('Region', 'freesiem-sentinel'), (string) $settings['rustfs_region'], __('RustFS/MinIO accept any string here; AWS S3 requires the bucket\'s actual region.', 'freesiem-sentinel'));
		$this->render_ssl_text_field('rustfs_bucket', __('Bucket', 'freesiem-sentinel'), (string) $settings['rustfs_bucket'], __('The bucket Sentinel should read and write backup packages to.', 'freesiem-sentinel'));
		$this->render_ssl_text_field('rustfs_access_key', __('Access Key', 'freesiem-sentinel'), (string) $settings['rustfs_access_key'], __('A read-write key scoped to the bucket above is all Sentinel needs.', 'freesiem-sentinel'));

		$secret_value = '' !== trim((string) $settings['rustfs_secret_key']) ? $secret_placeholder : '';
		echo '<tr><th scope="row"><label for="freesiem-rustfs-secret_key">' . esc_html__('Secret Key', 'freesiem-sentinel') . '</label></th><td>';
		echo '<input id="freesiem-rustfs-secret_key" type="password" class="regular-text" name="rustfs_secret_key" value="' . esc_attr($secret_value) . '" autocomplete="new-password" />';
		echo '<p class="description">' . esc_html__('Leave the saved value in place to keep the current secret. Clear the field and enter a new one to replace it.', 'freesiem-sentinel') . '</p>';
		echo '</td></tr>';

		$this->render_ssl_checkbox_field('rustfs_path_style', __('Path-style addressing', 'freesiem-sentinel'), !empty($settings['rustfs_path_style']), __('Required for RustFS/MinIO behind a custom domain with no wildcard DNS. Turn off for virtual-hosted-style addressing (typical on AWS S3).', 'freesiem-sentinel'));
		echo '</table>';
		submit_button(__('Save RustFS Settings', 'freesiem-sentinel'));
		echo '</form>';

		echo '<p><a class="button button-secondary" href="' . esc_url(freesiem_sentinel_admin_post_url('freesiem_sentinel_test_rustfs_connection')) . '">' . esc_html__('Test Connection', 'freesiem-sentinel') . '</a></p>';
		echo '</div>';
	}

	private function render_settings_about_tab($update_check): void
	{
		$settings = freesiem_sentinel_get_settings();
		$updater = $this->plugin->get_updater();
		$update_check_error = is_wp_error($update_check) ? $update_check : null;
		$release = is_array($update_check) && is_array($update_check['release'] ?? null)
			? $update_check['release']
			: (is_array($settings['updater_cache'] ?? null) ? $settings['updater_cache'] : []);
		$release = is_wp_error($release) ? [] : freesiem_sentinel_safe_array($release);
		$release_body = trim(safe($release['body'] ?? ''));
		$release_available = !empty($release['available']);
		$release_version = safe($release['version'] ?? '');
		$update_available = $release_available && version_compare($release_version, FREESIEM_SENTINEL_VERSION, '>');
		$update_button_url = $updater->get_update_plugin_url(freesiem_sentinel_admin_page_url('freesiem-settings', ['tab' => 'about']));

		echo '<p style="margin-top:16px;">' . esc_html__('Release, plan, and agent identity details for this WordPress deployment.', 'freesiem-sentinel') . '</p>';
		$this->render_card_grid_start();
		$this->render_stat_card(__('Plugin Version', 'freesiem-sentinel'), FREESIEM_SENTINEL_VERSION, __('Latest Release', 'freesiem-sentinel'), $release_available ? $release_version : __('No releases available', 'freesiem-sentinel'));
		$this->render_stat_card(__('Connected To', 'freesiem-sentinel'), __('freeSIEM Core', 'freesiem-sentinel'), __('Registration', 'freesiem-sentinel'), strtoupper(freesiem_sentinel_safe_string($settings['registration_status'] ?? '')));
		$this->render_stat_card(__('Site ID', 'freesiem-sentinel'), $this->friendly_site_id($settings['site_id'] ?? ''), __('Plan', 'freesiem-sentinel'), ucfirst($this->plugin->get_plan()));
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-top:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Updates & Credentials', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Plugin Updates', 'freesiem-sentinel') . ':</strong> ' . esc_html($update_available ? sprintf(__('Version %s is available.', 'freesiem-sentinel'), $release_version) : __('You are on the latest available version.', 'freesiem-sentinel')) . '</p>';
		if ($update_check_error instanceof WP_Error) {
			echo '<p style="color:#b32d2e;">' . esc_html(sprintf(__('The automatic update check could not complete: %s', 'freesiem-sentinel'), $update_check_error->get_error_message())) . '</p>';
		}
		if ($update_available) {
			echo '<p><a class="button button-primary" href="' . esc_url($update_button_url) . '">' . esc_html__('Update Plugin', 'freesiem-sentinel') . '</a></p>';
		} else {
			echo '<p><a class="button button-secondary" href="' . esc_url($update_button_url) . '">' . esc_html__('Update Plugin', 'freesiem-sentinel') . '</a></p>';
		}
		echo '<p><strong>' . esc_html__('Automatic Updates', 'freesiem-sentinel') . ':</strong> ' . esc_html__('Enabled by default for this plugin.', 'freesiem-sentinel') . '</p>';
		echo '<p style="color:#50575e;">' . esc_html__('This page checks GitHub for the latest packaged release every time it loads. Click Update Plugin to check again and install immediately when an update is available. Automatic updates are also enabled by default for WordPress background update runs.', 'freesiem-sentinel') . '</p>';
		echo '<p><strong>' . esc_html__('API Key:', 'freesiem-sentinel') . '</strong> <code>' . esc_html(freesiem_sentinel_mask_secret((string) ($settings['api_key'] ?? ''))) . '</code></p>';
		echo '<p><strong>' . esc_html__('HMAC Secret:', 'freesiem-sentinel') . '</strong> <code>' . esc_html(freesiem_sentinel_mask_secret((string) ($settings['hmac_secret'] ?? ''))) . '</code></p>';
		if (!empty($release['published_at'])) {
			echo '<p><strong>' . esc_html__('Release Published:', 'freesiem-sentinel') . '</strong> ' . esc_html(freesiem_sentinel_format_datetime((string) ($release['published_at'] ?? ''))) . '</p>';
		}
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-top:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Included Capabilities', 'freesiem-sentinel') . '</h2>';
		echo '<p>' . esc_html__('freeSIEM Sentinel includes backup, restore, sync, and related site-management workflows under the single freeSIEM menu.', 'freesiem-sentinel') . '</p>';
		echo '<p><a class="button button-secondary" href="' . esc_url(freesiem_sentinel_admin_page_url(FREESIEM_SENTINEL_SYNCHY_PAGE)) . '">' . esc_html__('Open Synchy', 'freesiem-sentinel') . '</a></p>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-top:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Latest Release Notes', 'freesiem-sentinel') . '</h2>';
		if (!$release_available) {
			$this->render_empty_state(__('No releases available', 'freesiem-sentinel'), __('Create a GitHub release and attach freesiem-sentinel.zip to enable packaged updates.', 'freesiem-sentinel'));
		} elseif ($release_body === '') {
			$this->render_empty_state(__('No release notes available', 'freesiem-sentinel'), __('The latest GitHub release did not include a changelog body.', 'freesiem-sentinel'));
		} else {
			echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html($release_body) . '</pre>';
		}
		echo '</div>';
	}

	private function render_deep_scan_progress(): void
	{
		$deep = $this->plugin->get_deep_scanner();
		$progress = $deep->progress();

		if (empty($progress['running'])) {
			return;
		}

		$percent = (int) max(2, min(100, (int) ($progress['percent'] ?? 0)));
		$files = number_format_i18n((int) ($progress['files_scanned'] ?? 0));
		$hits = number_format_i18n((int) ($progress['malware_hits'] ?? 0));
		$label = freesiem_sentinel_safe_string($progress['label'] ?? '');
		/* translators: 1: percent 2: file count 3: signature hit count */
		$status_tmpl = __('%1$s%% · %2$s files inspected · %3$s signature hit(s) so far', 'freesiem-sentinel');
		// The JS builds the string with plain replace(), so hand it a template
		// with a single literal % rather than sprintf's doubled %%.
		$js_tmpl = str_replace('%%', '%', $status_tmpl);
		$ajax_url = admin_url('admin-ajax.php');
		$nonce = wp_create_nonce('freesiem_sentinel_deep_scan_tick');

		echo '<div id="fs-deep-progress" style="background:#fff;border:1px solid #72aee6;border-left:4px solid #2271b1;border-radius:12px;padding:16px 20px;margin:0 0 20px;">';
		echo '<p style="margin:0 0 8px;font-weight:600;">'
			. esc_html__('Deep scan in progress', 'freesiem-sentinel') . ' — <span id="fs-deep-label">'
			. esc_html($label) . '</span></p>';
		echo '<div style="background:#f0f0f1;border-radius:999px;height:12px;overflow:hidden;max-width:520px;">';
		echo '<div id="fs-deep-bar" style="background:#2271b1;height:100%;width:' . esc_attr((string) $percent) . '%;transition:width .5s ease;"></div>';
		echo '</div>';
		echo '<p id="fs-deep-status" style="margin:8px 0 0;color:#50575e;font-size:13px;">' . esc_html(sprintf($status_tmpl, $percent, $files, $hits)) . '</p>';
		echo '<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:8px;"><p style="margin:0;color:#50575e;font-size:13px;">' . esc_html__('Keep this tab open to run the scan from your browser; background slices are spaced out to protect shared-host resources.', 'freesiem-sentinel') . '</p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;"><input type="hidden" name="action" value="freesiem_sentinel_abort_deep_scan">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<button type="submit" class="button button-secondary">' . esc_html__('Stop Scan', 'freesiem-sentinel') . '</button></form></div>';

		$cfg = wp_json_encode([
			'url' => $ajax_url,
			'nonce' => $nonce,
			'tmpl' => $js_tmpl,
		]);

		echo '<script>(function(){'
			. 'var c=' . $cfg . ';'
			. 'var bar=document.getElementById("fs-deep-bar");'
			. 'var st=document.getElementById("fs-deep-status");'
			. 'var lb=document.getElementById("fs-deep-label");'
			. 'var busy=false,misses=0;'
			. 'function fmt(p,f,h){return c.tmpl.replace("%1$s",p).replace("%2$s",Number(f).toLocaleString()).replace("%3$s",Number(h).toLocaleString());}'
			. 'function tick(){if(busy){return;}busy=true;'
			. 'fetch(c.url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"action=freesiem_sentinel_deep_scan_tick&nonce="+encodeURIComponent(c.nonce)})'
			. '.then(function(r){return r.json();}).then(function(res){busy=false;misses=0;'
			. 'var d=(res&&res.data)?res.data:{};'
			. 'var pct=Math.max(2,Math.min(100,parseInt(d.percent,10)||0));'
			. 'if(bar){bar.style.width=pct+"%";}'
			. 'if(lb&&d.label){lb.textContent=d.label;}'
			. 'if(st){st.textContent=fmt(pct,d.files_scanned||0,d.malware_hits||0);}'
			. 'if(d.running===false){window.location.reload();}'
			. '}).catch(function(){busy=false;if(++misses>8){clearInterval(iv);}});}'
			. 'var iv=setInterval(tick,15000);setTimeout(tick,800);'
			. '})();</script>';

		echo '</div>';
	}

	/**
	 * Export + Copy actions (JSON / CSV) for a result set.
	 *
	 * @param array $args extra query args, e.g. ['scan_run' => $id]; empty = current results.
	 * @param bool  $compact render as small inline links (used in the history table).
	 */
	private function render_export_actions(array $args, bool $compact = false): string
	{
		$json = freesiem_sentinel_admin_post_url('freesiem_sentinel_export_results', array_merge($args, ['format' => 'json']));
		$csv = freesiem_sentinel_admin_post_url('freesiem_sentinel_export_results', array_merge($args, ['format' => 'csv']));

		if ($compact) {
			return '<span style="white-space:nowrap;">'
				. '<a href="' . esc_url($json) . '">JSON</a>'
				. ' <a href="#" class="fs-copy-export" data-url="' . esc_url($json) . '" data-label="JSON" title="' . esc_attr__('Copy JSON to clipboard', 'freesiem-sentinel') . '">⧉</a>'
				. ' &middot; <a href="' . esc_url($csv) . '">CSV</a>'
				. ' <a href="#" class="fs-copy-export" data-url="' . esc_url($csv) . '" data-label="CSV" title="' . esc_attr__('Copy CSV to clipboard', 'freesiem-sentinel') . '">⧉</a>'
				. '</span>';
		}

		$running_hint = '';

		if ($args === [] && $this->plugin->get_deep_scanner()->is_running()) {
			$running_hint = '<span style="align-self:center;color:#b45309;font-size:12px;">' . esc_html__('deep scan still running — export will be incomplete', 'freesiem-sentinel') . '</span>';
		}

		return '<span style="display:inline-flex;gap:8px;flex-wrap:wrap;align-items:center;">'
			. '<a class="button button-secondary" href="' . esc_url($json) . '">' . esc_html__('Export JSON', 'freesiem-sentinel') . '</a>'
			. '<button type="button" class="button button-secondary fs-copy-export" data-url="' . esc_url($json) . '" data-label="' . esc_attr__('JSON', 'freesiem-sentinel') . '">' . esc_html__('Copy JSON', 'freesiem-sentinel') . '</button>'
			. '<a class="button button-secondary" href="' . esc_url($csv) . '">' . esc_html__('Export CSV', 'freesiem-sentinel') . '</a>'
			. '<button type="button" class="button button-secondary fs-copy-export" data-url="' . esc_url($csv) . '" data-label="' . esc_attr__('CSV', 'freesiem-sentinel') . '">' . esc_html__('Copy CSV', 'freesiem-sentinel') . '</button>'
			. $running_hint
			. '</span>';
	}

	/**
	 * One delegated click handler for every .fs-copy-export control on the page:
	 * fetches the (nonce-protected) export URL and writes the body to the clipboard.
	 */
	private function render_export_copy_script(): void
	{
		static $done = false;

		if ($done) {
			return;
		}

		$done = true;

		echo '<script>(function(){'
			. 'document.addEventListener("click",function(e){'
			. 'var b=e.target.closest(".fs-copy-export");if(!b){return;}e.preventDefault();'
			. 'if(b.dataset.busy){return;}b.dataset.busy="1";'
			. 'var orig=b.textContent,lbl=b.dataset.label||"";'
			. 'var reset=function(msg){b.textContent=msg;setTimeout(function(){b.textContent=orig;delete b.dataset.busy;},1500);};'
			. 'b.textContent=(orig==="⧉")?"…":("Copying "+lbl+"…");'
			. 'fetch(b.dataset.url,{credentials:"same-origin"}).then(function(r){return r.text();}).then(function(t){'
			. 'var ok=function(){reset((orig==="⧉")?"✓":("Copied "+lbl+" ✓"));};'
			. 'if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(ok,function(){fb(t);ok();});}else{fb(t);ok();}'
			. '}).catch(function(){reset("Copy failed");});'
			. 'function fb(t){var a=document.createElement("textarea");a.value=t;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{document.execCommand("copy");}catch(x){}document.body.removeChild(a);}'
			. '});'
			. '})();</script>';
	}

	private function render_scan_results_section(array $view): void
	{
		$all_findings = $view['all_findings'];
		$findings = $view['findings'];
		$filesystem = $view['filesystem'];
		$integrity = $view['integrity'];
		$integrity_changes = $view['integrity_changes'];
		$search = $view['search'];
		$selected_severities = $view['selected_severities'];
		$finding = $view['finding'];
		$active_change_type = freesiem_sentinel_safe_string($view['change_filters']['change_type'] ?? '');
		$active_change_path = freesiem_sentinel_safe_string($view['change_filters']['change_path'] ?? '');
		$scan_metrics = array_merge(
			[
				'files_discovered' => '',
				'files_analyzed' => '',
				'files_flagged' => '',
				'duration_seconds' => '',
				'scan_modules' => [],
			],
			freesiem_sentinel_safe_array($view['summary']),
			freesiem_sentinel_safe_array($view['inventory']['scan_metrics'] ?? [])
		);

		echo '<div id="freesiem-results-section" style="background:#fff;padding:24px;border:1px solid #dcdcde;border-radius:16px;">';
		echo '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px;">';
		echo '<h2 style="margin:0;">' . esc_html__('Scan Results', 'freesiem-sentinel') . '</h2>';
		if ($all_findings !== []) {
			echo $this->render_export_actions([]);
			$this->render_export_copy_script();
		}
		echo '</div>';

		if (is_array($finding)) {
			$this->render_finding_detail_page($finding);
			echo '</div>';
			return;
		}

		echo '<div style="display:grid;grid-template-columns:1.2fr .8fr;gap:20px;margin-bottom:20px;">';
		echo '<div>';
		echo '<h3 style="margin-top:0;">' . esc_html__('Summary', 'freesiem-sentinel') . '</h3>';
		if ($all_findings === [] && empty($view['settings']['last_local_scan_at'])) {
			$this->render_empty_state(__('No scan has been run yet.', 'freesiem-sentinel'), __('Run a scan to populate findings and file change details.', 'freesiem-sentinel'));
		} else {
			echo '<p><strong>' . esc_html__('Files discovered', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback($scan_metrics['files_discovered'] ?? ($filesystem['discovered_files'] ?? ''), false)) . '</p>';
			echo '<p><strong>' . esc_html__('Files analyzed', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback($scan_metrics['files_analyzed'] ?? ($filesystem['inspected_files'] ?? ''), false)) . '</p>';
			echo '<p><strong>' . esc_html__('Flagged files', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback($scan_metrics['files_flagged'] ?? ($filesystem['flagged_files'] ?? ''), false)) . '</p>';
			echo '<p><strong>' . esc_html__('Scan duration', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->format_duration($scan_metrics['duration_seconds'] ?? '')) . '</p>';
			if (isset($scan_metrics['files_content_scanned'])) {
				echo '<p><strong>' . esc_html__('Files content-scanned (deep)', 'freesiem-sentinel') . ':</strong> ' . esc_html(number_format_i18n((int) $scan_metrics['files_content_scanned'])) . '</p>';
			}
			if (isset($scan_metrics['malware_hits']) || isset($scan_metrics['core_files_modified']) || isset($scan_metrics['database_issues'])) {
				echo '<p><strong>' . esc_html__('Deep scan hits', 'freesiem-sentinel') . ':</strong> ' . esc_html(sprintf(
					/* translators: 1: malware hits 2: core files modified 3: plugin files modified 4: db issues */
					__('%1$s malware, %2$s core modified, %3$s plugin modified, %4$s database', 'freesiem-sentinel'),
					number_format_i18n((int) ($scan_metrics['malware_hits'] ?? 0)),
					number_format_i18n((int) ($scan_metrics['core_files_modified'] ?? 0)),
					number_format_i18n((int) ($scan_metrics['plugin_files_modified'] ?? 0)),
					number_format_i18n((int) ($scan_metrics['database_issues'] ?? 0))
				)) . '</p>';
			}
			echo '<p><strong>' . esc_html__('File integrity changes', 'freesiem-sentinel') . ':</strong> ' . esc_html(sprintf('%s new, %s modified, %s deleted', safe($integrity['new_files_count'] ?? '0'), safe($integrity['modified_files_count'] ?? '0'), safe($integrity['deleted_files_count'] ?? '0'))) . '</p>';
			echo '<p><strong>' . esc_html__('Scan modules used', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->format_scan_modules(!empty($scan_metrics['scan_modules']) ? ['scan_modules' => $scan_metrics['scan_modules']] : freesiem_sentinel_safe_array($view['inventory']['scan_profile'] ?? []))) . '</p>';
		}
		echo '</div>';

		echo '<div>';
		echo '<h3 style="margin-top:0;">' . esc_html__('File Changes Detected', 'freesiem-sentinel') . '</h3>';
		if ($integrity_changes === []) {
			$this->render_empty_state(__('No file changes detected in the latest scan.', 'freesiem-sentinel'), __('File additions, deletions, and monitored updates will appear here after a scan finds them.', 'freesiem-sentinel'));
		} else {
			if ($active_change_type !== '' || $active_change_path !== '') {
				echo '<p style="margin-top:0;"><strong>' . esc_html__('Active filters', 'freesiem-sentinel') . ':</strong> ';
				if ($active_change_type !== '') {
					echo '<code>' . esc_html($active_change_type) . '</code> ';
				}
				if ($active_change_path !== '') {
					echo '<code>' . esc_html($active_change_path) . '</code> ';
				}
				echo '<a href="' . esc_url($this->build_scan_url(['show_results' => '1']) . '#freesiem-results-section') . '">' . esc_html__('Clear file filters', 'freesiem-sentinel') . '</a></p>';
			}
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Change', 'freesiem-sentinel') . '</th><th>' . esc_html__('Path', 'freesiem-sentinel') . '</th><th>' . esc_html__('Hash', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach (array_slice($integrity_changes, 0, 5) as $change) {
				$change_type = freesiem_sentinel_safe_string($change['change_type'] ?? 'modified');
				$path = freesiem_sentinel_safe_string($change['path'] ?? '');
				$current_hash = freesiem_sentinel_safe_string($change['current_hash'] ?? '');
				$previous_hash = freesiem_sentinel_safe_string($change['previous_hash'] ?? '');
				$change_type_url = $this->build_scan_url([
					'show_results' => '1',
					'change_type' => $change_type,
					'change_path' => $active_change_path,
				]) . '#freesiem-results-section';
				$path_url = $this->build_scan_url([
					'show_results' => '1',
					'change_type' => $active_change_type,
					'change_path' => $path,
				]) . '#freesiem-results-section';
				echo '<tr>';
				echo '<td><a href="' . esc_url($change_type_url) . '" style="text-decoration:none;"><span style="' . esc_attr($this->change_badge_style($change_type)) . '">' . esc_html(ucfirst($change_type)) . '</span></a></td>';
				echo '<td><a href="' . esc_url($path_url) . '" style="text-decoration:none;"><code>' . esc_html($path) . '</code></a></td>';
				echo '<td><code>' . esc_html($current_hash !== '' ? substr($current_hash, 0, 16) : substr($previous_hash, 0, 16)) . '</code></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
		echo '</div>';

		echo '<div style="background:#f8fafc;padding:16px;border:1px solid #dbe3ea;border-radius:12px;margin-bottom:20px;">';
		echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;">';
		echo '<input type="hidden" name="page" value="freesiem-scan" />';
		echo '<input type="hidden" name="show_results" value="1" />';
		echo '<div><label for="freesiem-search" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('Search Findings', 'freesiem-sentinel') . '</label><input id="freesiem-search" class="regular-text" type="search" name="s" value="' . esc_attr($search) . '" /></div>';
		echo '<div><span style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('Severity Filters', 'freesiem-sentinel') . '</span>';
		foreach (['critical' => __('Critical', 'freesiem-sentinel'), 'high' => __('High', 'freesiem-sentinel'), 'medium' => __('Medium', 'freesiem-sentinel'), 'low' => __('Low', 'freesiem-sentinel'), 'info' => __('Info', 'freesiem-sentinel')] as $key => $label) {
			echo '<label style="margin-right:10px;display:inline-flex;align-items:center;gap:4px;"><input type="checkbox" name="severity[]" value="' . esc_attr($key) . '"' . checked(in_array($key, $selected_severities, true), true, false) . ' />' . esc_html($label) . '</label>';
		}
		echo '</div>';
		echo '<div><button type="submit" class="button button-secondary">' . esc_html__('Apply Filters', 'freesiem-sentinel') . '</button></div>';
		echo '</form>';
		echo '</div>';

		echo '<div>';
		echo '<h3 style="margin-top:0;">' . esc_html__('Findings', 'freesiem-sentinel') . '</h3>';
		if ($findings === []) {
			$this->render_empty_state(__('No findings match your current filters.', 'freesiem-sentinel'), __('Adjust the search terms or severity filters to widen the results.', 'freesiem-sentinel'));
		} else {
			$show_actions = Freesiem_File_Actions::can_act();
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Severity', 'freesiem-sentinel') . '</th><th>' . esc_html__('Title', 'freesiem-sentinel') . '</th><th>' . esc_html__('Category', 'freesiem-sentinel') . '</th><th>' . esc_html__('Recommendation', 'freesiem-sentinel') . '</th><th>' . esc_html__('Path', 'freesiem-sentinel') . '</th>' . ($show_actions ? '<th>' . esc_html__('Remediate', 'freesiem-sentinel') . '</th>' : '') . '</tr></thead><tbody>';
			foreach ($findings as $finding_row) {
				if (!is_array($finding_row)) {
					continue;
				}

				$reference = $this->build_finding_reference($finding_row);
				$detail_url = $this->build_scan_url([
					'show_results' => '1',
					'finding' => $reference,
				]);
				$path = freesiem_sentinel_safe_string($finding_row['evidence']['path'] ?? '');
				$summary_value = $path !== '' ? $path : $this->evidence_summary($finding_row);
				$size_label = $this->finding_size_label($finding_row);

				echo '<tr>';
				echo '<td><a href="' . esc_url($detail_url) . '" style="' . esc_attr($this->severity_badge_style((string) ($finding_row['severity'] ?? 'info'))) . '">' . esc_html(strtoupper(freesiem_sentinel_safe_string($finding_row['severity'] ?? 'info'))) . '</a></td>';
				echo '<td><a href="' . esc_url($detail_url) . '" style="display:block;color:inherit;text-decoration:none;"><strong>' . esc_html(freesiem_sentinel_safe_string($finding_row['title'] ?? '')) . '</strong><br /><span>' . esc_html(freesiem_sentinel_safe_string($finding_row['description'] ?? '')) . '</span></a></td>';
				echo '<td><a href="' . esc_url($detail_url) . '" style="display:block;color:inherit;text-decoration:none;">' . esc_html(freesiem_sentinel_safe_string($finding_row['category'] ?? '')) . '</a></td>';
				echo '<td><a href="' . esc_url($detail_url) . '" style="display:block;color:inherit;text-decoration:none;">' . esc_html(freesiem_sentinel_safe_string($finding_row['recommendation'] ?? '')) . '</a></td>';
				echo '<td><a href="' . esc_url($detail_url) . '" style="display:block;color:inherit;text-decoration:none;"><code>' . esc_html($summary_value) . '</code>'
					. ($size_label !== '' ? '<br /><small style="color:#646970;">' . esc_html($size_label) . '</small>' : '')
					. '</a></td>';

				if ($show_actions) {
					if ($path !== '' && !is_wp_error(Freesiem_File_Actions::resolve($path))) {
						echo '<td><a class="button button-small" href="' . esc_url($detail_url . '#freesiem-file-actions') . '">' . esc_html__('View / remove', 'freesiem-sentinel') . '</a></td>';
					} else {
						echo '<td><span style="color:#8c8f94;">&mdash;</span></td>';
					}
				}

				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		$this->render_acknowledged_findings_section(freesiem_sentinel_safe_array($view['acknowledged_findings'] ?? []));

		echo '</div>';

		$this->render_export_copy_script();
	}

	/**
	 * The collapsed "Marked as safe" list under the Findings table. These are
	 * excluded from the score, the severity counts and the report email; they
	 * survive Clear Results and stay here until an admin removes the mark (or,
	 * for a file-backed mark, until the file changes).
	 */
	private function render_acknowledged_findings_section(array $acknowledged): void
	{
		$acknowledged = array_values(array_filter($acknowledged, 'is_array'));

		if ($acknowledged === []) {
			return;
		}

		$can_manage = Freesiem_Acknowledgements::can_manage();

		echo '<details style="margin-top:20px;border:1px solid #a7f3d0;border-radius:12px;background:#f0fdf4;">';
		echo '<summary style="cursor:pointer;padding:12px 16px;font-weight:600;color:#065f46;">'
			. esc_html(sprintf(
				/* translators: %d: count */
				_n('%d finding marked as safe', '%d findings marked as safe', count($acknowledged), 'freesiem-sentinel'),
				count($acknowledged)
			))
			. '<span style="font-weight:400;color:#047857;"> — ' . esc_html__('excluded from the score and counts', 'freesiem-sentinel') . '</span></summary>';
		echo '<div style="padding:0 16px 16px;overflow-x:auto;">';

		echo '<table class="widefat striped"><thead><tr>'
			. '<th>' . esc_html__('Severity', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Title', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Path', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Note', 'freesiem-sentinel') . '</th>'
			. '<th>' . esc_html__('Marked by', 'freesiem-sentinel') . '</th>'
			. '<th></th>'
			. '</tr></thead><tbody>';

		foreach ($acknowledged as $finding_row) {
			$ack = freesiem_sentinel_safe_array($finding_row['acknowledged'] ?? []);
			$reference = $this->build_finding_reference($finding_row);
			$detail_url = $this->build_scan_url(['show_results' => '1', 'finding' => $reference]);
			$path = freesiem_sentinel_safe_string($finding_row['evidence']['path'] ?? '');

			echo '<tr>';
			echo '<td><a href="' . esc_url($detail_url) . '" style="' . esc_attr($this->severity_badge_style((string) ($finding_row['severity'] ?? 'info'))) . '">' . esc_html(strtoupper(freesiem_sentinel_safe_string($finding_row['severity'] ?? 'info'))) . '</a></td>';
			echo '<td><a href="' . esc_url($detail_url) . '" style="color:inherit;text-decoration:none;"><strong>' . esc_html(freesiem_sentinel_safe_string($finding_row['title'] ?? '')) . '</strong></a></td>';
			echo '<td><code>' . esc_html($path !== '' ? $path : '—') . '</code></td>';
			echo '<td>' . esc_html(freesiem_sentinel_safe_string($ack['note'] ?? '')) . '</td>';
			echo '<td>' . esc_html(sprintf(
				/* translators: 1: user login 2: date */
				__('%1$s, %2$s', 'freesiem-sentinel'),
				freesiem_sentinel_safe_string($ack['user_login'] ?? '') ?: __('admin', 'freesiem-sentinel'),
				freesiem_sentinel_format_datetime((string) ($ack['at'] ?? ''))
			)) . '</td>';
			echo '<td>';
			if ($can_manage) {
				echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;">';
				echo '<input type="hidden" name="action" value="freesiem_sentinel_unmark_finding_safe" />';
				echo '<input type="hidden" name="finding" value="' . esc_attr($reference) . '" />';
				echo '<input type="hidden" name="finding_key" value="' . esc_attr(freesiem_sentinel_safe_string($finding_row['finding_key'] ?? '')) . '" />';
				wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
				echo '<button type="submit" class="button button-small">' . esc_html__('Restore to active', 'freesiem-sentinel') . '</button>';
				echo '</form>';
			}
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';

		if ($can_manage) {
			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:12px;" onsubmit="return confirm(\'' . esc_js(__('Remove every safe mark on this site?', 'freesiem-sentinel')) . '\');">';
			echo '<input type="hidden" name="action" value="freesiem_sentinel_clear_safe_marks" />';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<button type="submit" class="button button-link-delete" style="color:#b32d2e;">' . esc_html__('Clear all safe marks', 'freesiem-sentinel') . '</button>';
			echo '</form>';
		}

		echo '</div></details>';
	}

	private function get_scan_results_view(): array
	{
		$settings = freesiem_sentinel_get_settings();
		$cache = $this->plugin->get_results()->get_cache();
		$summary = freesiem_sentinel_safe_array($cache['summary'] ?? []);
		$inventory = freesiem_sentinel_safe_array($cache['local_inventory'] ?? []);
		$filesystem = freesiem_sentinel_safe_array($inventory['filesystem'] ?? []);
		$integrity = freesiem_sentinel_safe_array($inventory['file_integrity'] ?? []);
		$all_findings = array_values(freesiem_sentinel_safe_array($cache['local_findings'] ?? []));
		$acknowledged_findings = array_values(array_filter($all_findings, static function ($f): bool {
			return is_array($f) && !empty($f['acknowledged']);
		}));
		$active_findings = freesiem_sentinel_active_findings($all_findings);
		$search = isset($_GET['s']) ? sanitize_text_field(wp_unslash((string) $_GET['s'])) : '';
		$selected_severities = $this->get_results_severity_filters();
		$findings = $this->filter_findings($active_findings, $search, $selected_severities);
		$finding_ref = isset($_GET['finding']) ? sanitize_text_field(wp_unslash((string) $_GET['finding'])) : '';
		$finding = $finding_ref !== '' ? $this->find_finding_by_reference($all_findings, $finding_ref) : null;
		$fim_diff_cache = freesiem_sentinel_safe_array($settings['fim_diff_cache'] ?? []);
		$integrity_changes = array_values(array_filter(freesiem_sentinel_safe_array($fim_diff_cache['changes'] ?? []), 'is_array'));
		$change_filters = [
			'change_type' => isset($_GET['change_type']) ? sanitize_key(wp_unslash((string) $_GET['change_type'])) : '',
			'change_path' => isset($_GET['change_path']) ? sanitize_text_field(wp_unslash((string) $_GET['change_path'])) : '',
		];
		$integrity_changes = $this->filter_integrity_changes($integrity_changes, $change_filters);

		return [
			'settings' => $settings,
			'cache' => $cache,
			'summary' => $summary,
			'inventory' => $inventory,
			'filesystem' => $filesystem,
			'integrity' => $integrity,
			'all_findings' => $all_findings,
			'acknowledged_findings' => $acknowledged_findings,
			'findings' => $findings,
			'search' => $search,
			'selected_severities' => $selected_severities,
			'finding' => $finding,
			'integrity_changes' => $integrity_changes,
			'change_filters' => $change_filters,
		];
	}

	private function sanitize_scan_preferences(array $input): array
	{
		$settings = freesiem_sentinel_get_settings();
		$current = freesiem_sentinel_safe_array($settings['scan_preferences'] ?? []);

		$exclude_raw = isset($input['exclude_paths']) ? (string) wp_unslash($input['exclude_paths']) : '';
		$exclude_paths = array_values(array_filter(array_map(
			static function ($path): string {
				return trim(ltrim((string) $path, '/'));
			},
			preg_split('/[\r\n,]+/', $exclude_raw) ?: []
		)));

		return [
			'scan_wordpress' => empty($input['scan_wordpress']) ? 0 : 1,
			'scan_filesystem' => empty($input['scan_filesystem']) ? 0 : 1,
			'scan_fim' => Freesiem_Features::is_enabled('fim') && !empty($input['scan_fim']) ? 1 : 0,
			'scan_malware' => empty($input['scan_malware']) ? 0 : 1,
			'scan_core_integrity' => empty($input['scan_core_integrity']) ? 0 : 1,
			'scan_plugin_integrity' => empty($input['scan_plugin_integrity']) ? 0 : 1,
			'scan_database' => empty($input['scan_database']) ? 0 : 1,
			'scan_uploads_deep' => empty($input['scan_uploads_deep']) ? 0 : 1,
			'scan_intensity' => in_array((string) ($input['scan_intensity'] ?? 'balanced'), ['gentle', 'balanced', 'thorough'], true) ? (string) $input['scan_intensity'] : 'balanced',
			'throttle_us' => max(-1, min(200000, (int) ($input['throttle_us'] ?? ($current['throttle_us'] ?? -1)))),
			'exclude_paths' => $exclude_paths,
			'include_uploads' => empty($input['include_uploads']) ? 0 : 1,
			'cloud_upload' => empty($input['cloud_upload']) ? 0 : 1,
			'max_files' => max(100, min(200000, (int) ($input['max_files'] ?? ($current['max_files'] ?? 1000)))),
			'max_depth' => max(1, min(20, (int) ($input['max_depth'] ?? ($current['max_depth'] ?? 5)))),
		];
	}

	private function render_card_grid_start(): void
	{
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px;">';
	}

	private function render_stat_card(string $title, string $value, string $label, string $meta): void
	{
		$title = freesiem_sentinel_safe_string($title);
		$value = freesiem_sentinel_safe_string($value);
		$label = freesiem_sentinel_safe_string($label);
		$meta = freesiem_sentinel_safe_string($meta);

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<p style="margin:0 0 8px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#50575e;">' . esc_html($title) . '</p>';
		echo '<p style="margin:0;font-size:24px;font-weight:600;word-break:break-word;">' . esc_html($value) . '</p>';
		echo '<p style="margin:12px 0 0;color:#50575e;"><strong>' . esc_html($label) . ':</strong> ' . esc_html($meta) . '</p>';
		echo '</div>';
	}

	private function render_summary_stat(string $label, string $value): void
	{
		static $palette_index = 0;
		$palettes = [
			['bg' => '#ecfeff', 'border' => '#a5f3fc'],
			['bg' => '#eff6ff', 'border' => '#bfdbfe'],
			['bg' => '#fef3c7', 'border' => '#fcd34d'],
			['bg' => '#ecfccb', 'border' => '#bef264'],
			['bg' => '#fee2e2', 'border' => '#fca5a5'],
			['bg' => '#f5f3ff', 'border' => '#c4b5fd'],
		];
		$palette = $palettes[$palette_index % count($palettes)];
		$palette_index++;

		echo '<div style="padding:14px;border:1px solid ' . esc_attr($palette['border']) . ';border-radius:12px;background:' . esc_attr($palette['bg']) . ';">';
		echo '<span style="display:block;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#64748b;">' . esc_html($label) . '</span>';
		echo '<strong style="display:block;font-size:20px;line-height:1.2;margin-top:6px;">' . esc_html($value) . '</strong>';
		echo '</div>';
	}

	private function render_empty_state(string $title, string $description): void
	{
		echo '<div style="padding:12px 14px;border:1px dashed #c3c4c7;border-radius:8px;background:#f9f9f9;">';
		echo '<p style="margin:0 0 6px;font-weight:600;">' . esc_html(freesiem_sentinel_safe_string($title)) . '</p>';
		echo '<p style="margin:0;color:#50575e;">' . esc_html(freesiem_sentinel_safe_string($description)) . '</p>';
		echo '</div>';
	}

	private function get_results_severity_filters(): array
	{
		$raw = isset($_GET['severity']) ? wp_unslash($_GET['severity']) : ['critical', 'high'];
		$values = is_array($raw) ? $raw : [$raw];
		$values = array_map(static fn($value): string => sanitize_key((string) $value), $values);
		$values = array_values(array_intersect($values, ['critical', 'high', 'medium', 'low', 'info']));

		return $values === [] ? ['critical', 'high'] : $values;
	}

	private function filter_findings(array $findings, string $search, array $severities): array
	{
		$search = strtolower((string) $search);

		return array_values(array_filter($findings, static function ($finding) use ($search, $severities): bool {
			if (!is_array($finding)) {
				return false;
			}

			$severity = freesiem_sentinel_normalize_severity((string) ($finding['severity'] ?? 'info'));

			if (!in_array($severity, $severities, true)) {
				return false;
			}

			if ($search === '') {
				return true;
			}

			$haystack = strtolower(implode(' ', [
				freesiem_sentinel_safe_string($finding['title'] ?? ''),
				freesiem_sentinel_safe_string($finding['category'] ?? ''),
				freesiem_sentinel_safe_string($finding['description'] ?? ''),
				freesiem_sentinel_safe_string($finding['recommendation'] ?? ''),
				freesiem_sentinel_safe_string($finding['finding_key'] ?? ''),
				freesiem_sentinel_safe_string($finding['evidence']['path'] ?? ''),
				freesiem_sentinel_safe_json_pretty($finding['evidence'] ?? []),
			]));

			return str_contains($haystack, $search);
		}));
	}

	/**
	 * A stable per-finding token used in URLs and file-action forms. Derived
	 * only from the finding's own identity (not its position in a list) so a
	 * reference built from the filtered table still resolves against the full
	 * stored set — including findings that have been marked safe.
	 */
	private function build_finding_reference(array $finding): string
	{
		$evidence = freesiem_sentinel_safe_array($finding['evidence'] ?? []);
		$seed = implode('|', [
			freesiem_sentinel_safe_string($finding['finding_key'] ?? ''),
			freesiem_sentinel_safe_string($finding['detected_at'] ?? ''),
			freesiem_sentinel_safe_string($finding['title'] ?? ''),
			freesiem_sentinel_safe_string($evidence['path'] ?? ''),
			freesiem_sentinel_safe_string($evidence['line'] ?? ''),
			freesiem_sentinel_safe_string($evidence['signature_id'] ?? ''),
		]);

		return substr(sha1($seed), 0, 16);
	}

	private function find_finding_by_reference(array $findings, string $reference): ?array
	{
		foreach (array_values($findings) as $finding) {
			if (!is_array($finding)) {
				continue;
			}

			if ($this->build_finding_reference($finding) === $reference) {
				$finding['_reference'] = $reference;
				return $finding;
			}
		}

		return null;
	}

	private function render_finding_detail_page(array $finding): void
	{
		$back_url = $this->build_scan_url(['show_results' => '1']) . '#freesiem-results-section';
		$severity = freesiem_sentinel_normalize_severity((string) ($finding['severity'] ?? 'info'));
		$evidence = freesiem_sentinel_safe_array($finding['evidence'] ?? []);
		$path = freesiem_sentinel_safe_string($evidence['path'] ?? '');

		echo '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">';
		echo '<a class="button button-secondary" href="' . esc_url($back_url) . '">' . esc_html__('Back to Scan Results', 'freesiem-sentinel') . '</a>';
		echo '<a class="button button-primary" href="' . esc_url(freesiem_sentinel_admin_page_url('freesiem-scan')) . '">' . esc_html__('Run Scan Again', 'freesiem-sentinel') . '</a>';
		echo '</div>';

		echo '<div style="background:#fff;padding:24px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<p><span style="' . esc_attr($this->severity_badge_style($severity)) . '">' . esc_html(strtoupper($severity)) . '</span></p>';
		echo '<h2 style="margin-top:0;">' . esc_html(freesiem_sentinel_safe_string($finding['title'] ?? '')) . '</h2>';
		echo '<p>' . esc_html(freesiem_sentinel_safe_string($finding['description'] ?? '')) . '</p>';

		$explainer = $this->finding_explainer($finding);

		if ($explainer !== '') {
			echo '<div style="margin:0 0 18px;padding:14px 16px;background:#f0f6fc;border:1px solid #c3d9ed;border-left:4px solid #2271b1;border-radius:8px;">';
			echo '<strong style="display:block;margin-bottom:4px;">' . esc_html__('Why this matters', 'freesiem-sentinel') . '</strong>';
			echo '<span style="color:#1d2327;">' . esc_html($explainer) . '</span>';
			echo '</div>';
		}

		echo '<table class="form-table" role="presentation">';
		$this->render_detail_row(__('Finding Key', 'freesiem-sentinel'), freesiem_sentinel_safe_string($finding['finding_key'] ?? ''));
		$this->render_detail_row(__('Category', 'freesiem-sentinel'), freesiem_sentinel_safe_string($finding['category'] ?? ''));
		$this->render_detail_row(__('Recommendation', 'freesiem-sentinel'), freesiem_sentinel_safe_string($finding['recommendation'] ?? ''));
		$this->render_detail_row(__('Detected At', 'freesiem-sentinel'), freesiem_sentinel_format_datetime((string) ($finding['detected_at'] ?? '')));
		$this->render_detail_row(__('Score', 'freesiem-sentinel'), freesiem_sentinel_safe_string($finding['score'] ?? ''));
		$this->render_detail_row(__('Source', 'freesiem-sentinel'), $this->derive_finding_source($finding));
		if ($path !== '') {
			$this->render_detail_row(__('Path', 'freesiem-sentinel'), $path);

			$recorded_size = $evidence['size'] ?? ($evidence['current_size'] ?? null);

			if (is_numeric($recorded_size)) {
				$this->render_detail_row(__('File size (at scan time)', 'freesiem-sentinel'), size_format((int) $recorded_size) . ' (' . number_format_i18n((int) $recorded_size) . ' bytes)');
			}

			$live_abs = Freesiem_File_Actions::resolve($path);

			if (is_wp_error($live_abs)) {
				$this->render_detail_row(__('On disk now', 'freesiem-sentinel'), $live_abs->get_error_code() === 'freesiem_missing'
					? __('No longer present', 'freesiem-sentinel')
					: sprintf(__('Present (%s)', 'freesiem-sentinel'), $live_abs->get_error_message()));
			} else {
				$live_size = (int) @filesize($live_abs);
				$this->render_detail_row(__('On disk now', 'freesiem-sentinel'), sprintf(
					/* translators: 1: human size 2: byte count 3: modified date */
					__('%1$s (%2$s bytes), modified %3$s', 'freesiem-sentinel'),
					size_format($live_size),
					number_format_i18n($live_size),
					freesiem_sentinel_format_datetime(gmdate('c', (int) @filemtime($live_abs)))
				));
			}
		}
		if (!empty($evidence['change_type'])) {
			$this->render_detail_row(__('Change Type', 'freesiem-sentinel'), strtoupper(freesiem_sentinel_safe_string($evidence['change_type'] ?? '')));
		}
		if (array_key_exists('previous_size', $evidence) || array_key_exists('current_size', $evidence)) {
			$this->render_detail_row(__('Previous Size', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['previous_size'] ?? ''));
			$this->render_detail_row(__('Current Size', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['current_size'] ?? ''));
		}
		if (!empty($evidence['previous_hash']) || !empty($evidence['current_hash'])) {
			$this->render_detail_row(__('Previous Hash', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['previous_hash'] ?? ''));
			$this->render_detail_row(__('Current Hash', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['current_hash'] ?? ''));
		}
		if (!empty($evidence['previous_modified_time']) || !empty($evidence['current_modified_time'])) {
			$this->render_detail_row(__('Previous Modified Time', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['previous_modified_time'] ?? ''));
			$this->render_detail_row(__('Current Modified Time', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['current_modified_time'] ?? ''));
		}
		if (!empty($evidence['signature_id'])) {
			$this->render_detail_row(__('Signature', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['signature_id'] ?? ''));
		}
		if (!empty($evidence['line'])) {
			$this->render_detail_row(__('Line', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['line'] ?? ''));
		}
		if (!empty($evidence['match_count'])) {
			$this->render_detail_row(__('Occurrences', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['match_count'] ?? ''));
		}
		if (!empty($evidence['expected_md5']) || !empty($evidence['actual_md5'])) {
			$this->render_detail_row(__('Expected MD5', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['expected_md5'] ?? ''));
			$this->render_detail_row(__('Actual MD5', 'freesiem-sentinel'), freesiem_sentinel_safe_string($evidence['actual_md5'] ?? ''));
		}
		echo '</table>';

		$this->render_finding_safe_mark($finding);

		if ($path !== '') {
			$this->render_finding_file_actions($finding, $path);
		}

		if (!empty($evidence['snippet'])) {
			echo '<h3>' . esc_html__('Matched Content', 'freesiem-sentinel') . '</h3>';
			echo '<pre style="white-space:pre-wrap;overflow:auto;background:#1d2327;color:#f0f0f1;padding:12px;border-radius:8px;">' . esc_html(freesiem_sentinel_safe_string($evidence['snippet'])) . '</pre>';
		}
		if (!empty($evidence['modified_files']) && is_array($evidence['modified_files'])) {
			echo '<h3>' . esc_html__('Modified Files', 'freesiem-sentinel') . '</h3>';
			echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html(implode("\n", array_map('freesiem_sentinel_safe_string', $evidence['modified_files']))) . '</pre>';
		}
		echo '<h3>' . esc_html__('Evidence', 'freesiem-sentinel') . '</h3>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html(freesiem_sentinel_safe_json_pretty($evidence)) . '</pre>';
		echo '</div>';
	}

	private function render_detail_row(string $label, string $value): void
	{
		echo '<tr><th scope="row">' . esc_html(freesiem_sentinel_safe_string($label)) . '</th><td>' . esc_html(freesiem_sentinel_safe_string($value)) . '</td></tr>';
	}

	/**
	 * "Mark as safe" / "Remove safe mark" controls for a finding. A mark is
	 * local to this site, survives Clear Results, is excluded from the score and
	 * counts, and — for a finding that points at a file — auto-voids if that
	 * file's bytes ever change.
	 */
	private function render_finding_safe_mark(array $finding): void
	{
		if (!Freesiem_Acknowledgements::can_manage()) {
			return;
		}

		$reference = freesiem_sentinel_safe_string($finding['_reference'] ?? '');
		$finding_key = freesiem_sentinel_safe_string($finding['finding_key'] ?? '');
		$ack = is_array($finding['acknowledged'] ?? null) ? $finding['acknowledged'] : null;
		$post_url = esc_url(admin_url('admin-post.php'));

		echo '<h3 id="freesiem-safe-mark" style="margin-top:24px;">' . esc_html__('Reviewed &amp; safe', 'freesiem-sentinel') . '</h3>';

		if (!empty($finding['acknowledgement_voided'])) {
			echo '<div style="margin:0 0 12px;padding:12px 14px;background:#fef3c7;border:1px solid #fcd34d;border-left:4px solid #d97706;border-radius:8px;">'
				. esc_html__('This finding was previously marked safe, but the file has changed since then, so the mark was voided and the finding is active again. Review it before marking it safe once more.', 'freesiem-sentinel')
				. '</div>';
		}

		if ($ack !== null) {
			$when = freesiem_sentinel_format_datetime((string) ($ack['at'] ?? ''));
			$who = freesiem_sentinel_safe_string($ack['user_login'] ?? '');
			$note = freesiem_sentinel_safe_string($ack['note'] ?? '');

			echo '<div style="margin:0 0 12px;padding:12px 14px;background:#ecfdf5;border:1px solid #a7f3d0;border-left:4px solid #059669;border-radius:8px;">';
			echo '<strong style="display:block;margin-bottom:4px;">' . esc_html__('Marked as safe', 'freesiem-sentinel') . '</strong>';
			echo '<span style="display:block;color:#065f46;">' . esc_html(sprintf(
				/* translators: 1: user login 2: date */
				__('By %1$s on %2$s', 'freesiem-sentinel'),
				$who !== '' ? $who : __('an administrator', 'freesiem-sentinel'),
				$when
			)) . '</span>';
			if ($note !== '') {
				echo '<span style="display:block;margin-top:6px;color:#1d2327;"><em>' . esc_html($note) . '</em></span>';
			}
			if (!empty($ack['sha256'])) {
				echo '<span style="display:block;margin-top:6px;font-size:12px;color:#4b5563;">' . esc_html(sprintf(__('Bound to file hash %s… — the mark voids automatically if the file changes.', 'freesiem-sentinel'), substr((string) $ack['sha256'], 0, 12))) . '</span>';
			}
			echo '</div>';

			echo '<form method="post" action="' . $post_url . '" onsubmit="return confirm(\'' . esc_js(__('Remove the safe mark? The finding will count again.', 'freesiem-sentinel')) . '\');">';
			echo '<input type="hidden" name="action" value="freesiem_sentinel_unmark_finding_safe" />';
			echo '<input type="hidden" name="finding" value="' . esc_attr($reference) . '" />';
			echo '<input type="hidden" name="finding_key" value="' . esc_attr($finding_key) . '" />';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<button type="submit" class="button button-secondary">' . esc_html__('Remove safe mark', 'freesiem-sentinel') . '</button>';
			echo '</form>';

			return;
		}

		$severity = freesiem_sentinel_normalize_severity((string) ($finding['severity'] ?? 'info'));
		$loud = in_array($severity, ['critical', 'high'], true);

		echo '<p style="color:#50575e;max-width:640px;">' . esc_html__('If you have checked this finding and it is a legitimate file or an expected condition, mark it safe. It stays out of the score and severity counts on this site until you remove the mark — and, for a file, until the file changes.', 'freesiem-sentinel') . '</p>';

		if ($loud) {
			echo '<p style="color:#b32d2e;max-width:640px;"><strong>' . esc_html__('This is a high-severity finding.', 'freesiem-sentinel') . '</strong> ' . esc_html__('Only mark it safe if you are certain — view the file contents first.', 'freesiem-sentinel') . '</p>';
		}

		echo '<form method="post" action="' . $post_url . '" onsubmit="return confirm(\'' . esc_js(__('Mark this finding as safe on this site?', 'freesiem-sentinel')) . '\');">';
		echo '<input type="hidden" name="action" value="freesiem_sentinel_mark_finding_safe" />';
		echo '<input type="hidden" name="finding" value="' . esc_attr($reference) . '" />';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<p><label for="freesiem-ack-note" style="display:block;font-weight:600;margin-bottom:4px;">' . esc_html__('Why is this safe? (required)', 'freesiem-sentinel') . '</label>';
		echo '<textarea id="freesiem-ack-note" name="ack_note" rows="2" class="large-text" maxlength="500" required placeholder="' . esc_attr__('e.g. UI kit I uploaded to the media library on 2026-05-01', 'freesiem-sentinel') . '"></textarea></p>';
		echo '<button type="submit" class="button button-secondary">' . esc_html__('Mark as safe', 'freesiem-sentinel') . '</button>';
		echo '</form>';
	}

	/**
	 * A compact "1.2 KB" label for a finding that points at a file, taken from
	 * the size recorded at scan time. Empty string when the finding has no size.
	 */
	private function finding_size_label(array $finding): string
	{
		$evidence = freesiem_sentinel_safe_array($finding['evidence'] ?? []);
		$size = $evidence['size'] ?? ($evidence['current_size'] ?? ($evidence['file_size'] ?? null));

		if (!is_numeric($size)) {
			return '';
		}

		$size = (int) $size;

		if ($size === 0) {
			return __('empty file', 'freesiem-sentinel');
		}

		return sprintf(
			/* translators: 1: human-readable size e.g. "1.2 KB" 2: exact byte count */
			__('%1$s (%2$s bytes)', 'freesiem-sentinel'),
			size_format($size),
			number_format_i18n($size)
		);
	}

	/**
	 * Plain-language background for a finding: what the flagged thing is and why
	 * a scanner cares, keyed off the signature / category / filename so the admin
	 * is not left to look it up.
	 */
	private function finding_explainer(array $finding): string
	{
		$evidence = freesiem_sentinel_safe_array($finding['evidence'] ?? []);
		$category = strtolower(freesiem_sentinel_safe_string($finding['category'] ?? ''));
		$signature = strtolower(freesiem_sentinel_safe_string($evidence['signature_id'] ?? ''));
		$path = strtolower(freesiem_sentinel_safe_string($evidence['path'] ?? ''));
		$ext = strtolower((string) pathinfo($path, PATHINFO_EXTENSION));
		$reasons = array_map('strtolower', array_map('freesiem_sentinel_safe_string', freesiem_sentinel_safe_array($evidence['reasons'] ?? [])));
		$reason_text = implode(' ', $reasons);

		if (!empty($evidence['self_unrecognized']) || !empty($evidence['unrecognized_files'])) {
			return __('freeSIEM Sentinel checksums every file it ships (checksums.json). A byte-perfect copy of its own code is trusted and skipped. This file is inside our plugin folder but is NOT in that manifest — so either a development copy of the plugin was deployed (the release build strips tests/, dist/ and *.md, and our test fixtures deliberately contain malware-shaped strings), or someone dropped a file into our directory. A stranger file inside a trusted plugin is a classic hiding spot for a web shell, which is why it is surfaced rather than ignored.', 'freesiem-sentinel');
		}

		if ($ext === 'sql' || str_contains($reason_text, 'database dump')) {
			return __('A .sql file is a database dump — a plain-text copy of part or all of the site database: user accounts, hashed passwords, secret keys, orders, personal data. If it sits in a web-reachable folder, anyone who guesses the URL can download the whole thing. These files are normally left behind by a backup plugin, a migration/staging tool, or a manual export, and should be moved out of the web root (or deleted) once you no longer need them. An empty one exposes nothing, but still should not be there.', 'freesiem-sentinel');
		}

		if (str_contains($signature, 'eval') || str_contains($signature, 'encoded') || str_contains($signature, 'base64')) {
			return __('This code decodes a hidden string (base64 / gzip / hex) and immediately executes it with eval() or a similar call. Legitimate plugins almost never need to hide code from you this way; attackers do it constantly so a shell reads as gibberish and slips past a casual look. Treat any file you cannot personally account for that does this as a live backdoor.', 'freesiem-sentinel');
		}

		if (str_contains($signature, 'polyglot') || (str_contains($reason_text, 'php') && in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'ico'], true))) {
			return __('This file carries an image header but also contains runnable PHP — a "polyglot". Uploading a real image that is secretly executable is a common way to get code onto a site through an avatar or media upload form, then run it by requesting the file directly.', 'freesiem-sentinel');
		}

		if (str_contains($signature, 'htaccess') || str_contains($path, '.htaccess')) {
			return __('An .htaccess file changes how Apache serves a folder. Malware uses it to make normally-inert file types (.jpg, .txt) execute as PHP, to hide URLs, or to redirect your visitors to another site. Review every directive against what that folder legitimately needs.', 'freesiem-sentinel');
		}

		if (str_contains($reason_text, 'uploads')) {
			return __('The uploads folder is for media — it should never contain executable PHP. A .php file here almost always means an upload form was abused to plant one. Anything runnable in uploads should be treated as hostile until proven otherwise.', 'freesiem-sentinel');
		}

		if (str_contains($reason_text, 'web shell') || str_contains($signature, 'webshell') || str_contains($signature, 'shell')) {
			return __('A web shell is a small script that lets a remote attacker run commands, browse files, and upload more malware through a normal web request — a remote-control panel for your server. They are often named to blend in (e.g. wp-info.php, class-wp.php) and are the usual payload left behind after a break-in.', 'freesiem-sentinel');
		}

		if (in_array($ext, ['bak', 'old', 'orig', 'save', 'swp'], true) || str_contains($path, 'wp-config')) {
			return __('Backup and editor temp copies of PHP files (.bak, .old, ~, .swp) are served as plain text, not executed — so a backup of wp-config.php hands out your database password and secret keys to anyone who requests it. Keep backups outside the web root.', 'freesiem-sentinel');
		}

		if (in_array($ext, ['zip', 'tar', 'gz', 'tgz', 'bz2', 'xz', '7z', 'rar'], true)) {
			return __('A publicly-reachable archive in the web root often contains a full copy of the site (code and configuration). If it is not something you deliberately published for download, remove it — and check whether it exposes wp-config.php or a database dump inside.', 'freesiem-sentinel');
		}

		if ($category === 'plugin_integrity' || $category === 'file_integrity' || $category === 'core') {
			return __('This file does not match the known-good checksum for its version. That is expected right after you edit a file yourself; if you did not, it means something changed the code on disk — a compromised update, a planted change, or a failed deploy — and the affected component should be reinstalled from a clean source.', 'freesiem-sentinel');
		}

		if ($category === 'database') {
			return __('This finding is about data stored in the WordPress database rather than a file — an injected admin user, a malicious scheduled task, spam URLs in post content, or a rogue option. Database malware survives reinstalling files, so it has to be cleaned separately.', 'freesiem-sentinel');
		}

		return '';
	}

	/**
	 * View / quarantine / delete / restore controls for the file a finding
	 * points at. Gated on Freesiem_File_Actions::can_act().
	 */
	private function render_finding_file_actions(array $finding, string $path): void
	{
		if (!Freesiem_File_Actions::can_act()) {
			return;
		}

		$reference = freesiem_sentinel_safe_string($finding['_reference'] ?? '');
		$resolved = Freesiem_File_Actions::resolve($path);
		$records = Freesiem_File_Actions::records();
		$quarantined_id = '';

		foreach ($records as $id => $record) {
			if (freesiem_sentinel_safe_string($record['relative_path'] ?? '') === ltrim($path, '/')) {
				$quarantined_id = (string) $id;
				break;
			}
		}

		echo '<h3 id="freesiem-file-actions">' . esc_html__('File actions', 'freesiem-sentinel') . '</h3>';

		if ($quarantined_id !== '') {
			echo '<p>' . esc_html__('This file is currently in quarantine (moved out of the web root, kept so it can be restored).', 'freesiem-sentinel') . '</p>';
			echo '<div style="display:flex;gap:10px;flex-wrap:wrap;">';
			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'' . esc_js(__('Move this file back to its original location?', 'freesiem-sentinel')) . '\');">';
			echo '<input type="hidden" name="action" value="freesiem_sentinel_restore_file" />';
			echo '<input type="hidden" name="quarantine_id" value="' . esc_attr($quarantined_id) . '" />';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<button type="submit" class="button button-secondary">' . esc_html__('Restore file', 'freesiem-sentinel') . '</button>';
			echo '</form>';
			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'' . esc_js(__('Permanently delete the quarantined copy? This cannot be undone.', 'freesiem-sentinel')) . '\');">';
			echo '<input type="hidden" name="action" value="freesiem_sentinel_delete_file" />';
			echo '<input type="hidden" name="quarantine_id" value="' . esc_attr($quarantined_id) . '" />';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<button type="submit" class="button button-link-delete" style="color:#b32d2e;">' . esc_html__('Delete quarantined copy', 'freesiem-sentinel') . '</button>';
			echo '</form>';
			echo '</div>';

			return;
		}

		if (is_wp_error($resolved)) {
			echo '<p style="color:#646970;">' . esc_html(sprintf(
				/* translators: %s: reason */
				__('No file actions available: %s', 'freesiem-sentinel'),
				$resolved->get_error_message()
			)) . '</p>';

			return;
		}

		$viewing = isset($_GET['view_file']) && $_GET['view_file'] === '1';
		$detail_url = $this->build_scan_url(['show_results' => '1', 'finding' => $reference]);

		echo '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px;">';

		if ($viewing) {
			echo '<a class="button button-secondary" href="' . esc_url($detail_url . '#freesiem-results-section') . '">' . esc_html__('Hide file contents', 'freesiem-sentinel') . '</a>';
		} else {
			echo '<a class="button button-secondary" href="' . esc_url(add_query_arg('view_file', '1', $detail_url) . '#freesiem-file-view') . '">' . esc_html__('View file contents', 'freesiem-sentinel') . '</a>';
		}

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'' . esc_js(__('Move this file into quarantine? It leaves the web root but can be restored.', 'freesiem-sentinel')) . '\');">';
		echo '<input type="hidden" name="action" value="freesiem_sentinel_quarantine_file" />';
		echo '<input type="hidden" name="finding" value="' . esc_attr($reference) . '" />';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<button type="submit" class="button button-primary">' . esc_html__('Quarantine file', 'freesiem-sentinel') . '</button>';
		echo '</form>';

		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'' . esc_js(__('Permanently delete this file? This cannot be undone. Quarantine instead if you are not sure.', 'freesiem-sentinel')) . '\');">';
		echo '<input type="hidden" name="action" value="freesiem_sentinel_delete_file" />';
		echo '<input type="hidden" name="finding" value="' . esc_attr($reference) . '" />';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<button type="submit" class="button button-link-delete" style="color:#b32d2e;">' . esc_html__('Delete file', 'freesiem-sentinel') . '</button>';
		echo '</form>';

		echo '</div>';

		if (!$viewing) {
			return;
		}

		$view = Freesiem_File_Actions::read_for_display($path);

		echo '<div id="freesiem-file-view">';

		if (is_wp_error($view)) {
			echo '<p style="color:#b32d2e;">' . esc_html($view->get_error_message()) . '</p>';
			echo '</div>';

			return;
		}

		$notes = [];

		if (!empty($view['masked'])) {
			$notes[] = __('secret values masked', 'freesiem-sentinel');
		}

		if (!empty($view['truncated'])) {
			$shown = $view['type'] === 'binary' ? Freesiem_File_Actions::MAX_BINARY_VIEW_BYTES : Freesiem_File_Actions::MAX_VIEW_BYTES;
			$notes[] = sprintf(__('showing the first %s of %s', 'freesiem-sentinel'), size_format($shown), size_format((int) $view['bytes']));
		}

		if ($view['type'] === 'binary') {
			$notes[] = __('binary file, shown as a hex dump', 'freesiem-sentinel');
		}

		if ($notes !== []) {
			echo '<p style="color:#646970;margin-bottom:6px;">' . esc_html(ucfirst(implode('; ', $notes))) . '.</p>';
		}

		echo '<pre style="white-space:pre-wrap;overflow:auto;max-height:520px;background:#1d2327;color:#f0f0f1;padding:12px;border-radius:8px;font-size:12px;line-height:1.5;">' . esc_html((string) $view['content']) . '</pre>';
		echo '</div>';
	}

	private function derive_finding_source(array $finding): string
	{
		$category = freesiem_sentinel_safe_string($finding['category'] ?? '');

		return match ($category) {
			'filesystem' => 'filesystem',
			'file_integrity' => 'file_integrity',
			'malware' => 'deep_scan_malware',
			'core_integrity' => 'deep_scan_core',
			'plugin_integrity' => 'deep_scan_plugin',
			'database' => 'deep_scan_database',
			default => 'local',
		};
	}

	private function severity_badge_style(string $severity): string
	{
		$severity = freesiem_sentinel_normalize_severity($severity);
		$palette = match ($severity) {
			'critical' => 'background:#8b1e1e;color:#fff;border:1px solid #6b0b0b;',
			'high' => 'background:#b42318;color:#fff;border:1px solid #912018;',
			'medium' => 'background:#f79009;color:#111;border:1px solid #d97706;',
			'low' => 'background:#dbeafe;color:#1d4ed8;border:1px solid #93c5fd;',
			default => 'background:#f3f4f6;color:#374151;border:1px solid #d1d5db;',
		};

		return 'display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;font-weight:700;text-decoration:none;' . $palette;
	}

	private function change_badge_style(string $change_type): string
	{
		$palette = match (strtolower((string) $change_type)) {
			'new' => 'background:#8b1e1e;color:#fff;border:1px solid #6b0b0b;',
			'deleted' => 'background:#b42318;color:#fff;border:1px solid #912018;',
			default => 'background:#f79009;color:#111;border:1px solid #d97706;',
		};

		return 'display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;font-weight:700;text-decoration:none;' . $palette;
	}

	private function summary_value_or_fallback($value, bool $is_datetime): string
	{
		if ($is_datetime) {
			$string_value = safe($value);
			return $string_value === '' ? __('No scan yet', 'freesiem-sentinel') : freesiem_sentinel_format_datetime($string_value);
		}

		$string_value = safe($value);
		return $string_value === '' ? __('No scan yet', 'freesiem-sentinel') : $string_value;
	}

	private function friendly_site_id($site_id): string
	{
		$site_id = safe($site_id);
		return $site_id === '' ? __('Pending Setup', 'freesiem-sentinel') : $site_id;
	}

	private function agent_status_label(bool $connected): string
	{
		return $connected ? __('Connected to freeSIEM Cloud', 'freesiem-sentinel') : __('Pending Setup', 'freesiem-sentinel');
	}

	private function registration_state_label($status): string
	{
		$status = sanitize_key((string) $status);

		return match ($status) {
			'registered', 'connected', 'active' => __('Connected', 'freesiem-sentinel'),
			default => __('Pending Setup', 'freesiem-sentinel'),
		};
	}

	private function format_scan_modules(array $scan_profile): string
	{
		if (!empty($scan_profile['scan_modules']) && is_array($scan_profile['scan_modules'])) {
			return implode(', ', array_map('freesiem_sentinel_safe_string', $scan_profile['scan_modules']));
		}

		$labels = [];

		if (!empty($scan_profile['scan_wordpress'])) {
			$labels[] = __('WordPress Config', 'freesiem-sentinel');
		}
		if (!empty($scan_profile['scan_filesystem'])) {
			$labels[] = __('Filesystem', 'freesiem-sentinel');
		}
		if (!empty($scan_profile['scan_fim'])) {
			$labels[] = __('File Integrity', 'freesiem-sentinel');
		}
		if (!empty($scan_profile['scan_malware'])) {
			$labels[] = __('Malware Signatures', 'freesiem-sentinel');
		}
		if (!empty($scan_profile['scan_core_integrity'])) {
			$labels[] = __('Core Checksums', 'freesiem-sentinel');
		}
		if (!empty($scan_profile['scan_plugin_integrity'])) {
			$labels[] = __('Plugin Checksums', 'freesiem-sentinel');
		}
		if (!empty($scan_profile['scan_database'])) {
			$labels[] = __('Database', 'freesiem-sentinel');
		}

		return $labels === [] ? __('No modules selected', 'freesiem-sentinel') : implode(', ', $labels);
	}

	private function filter_integrity_changes(array $changes, array $filters): array
	{
		$change_type = freesiem_sentinel_safe_string($filters['change_type'] ?? '');
		$change_path = freesiem_sentinel_safe_string($filters['change_path'] ?? '');

		return array_values(array_filter($changes, static function ($change) use ($change_type, $change_path): bool {
			if (!is_array($change)) {
				return false;
			}

			if ($change_type !== '' && freesiem_sentinel_safe_string($change['change_type'] ?? '') !== $change_type) {
				return false;
			}

			if ($change_path !== '' && freesiem_sentinel_safe_string($change['path'] ?? '') !== $change_path) {
				return false;
			}

			return true;
		}));
	}

	private function format_duration($duration): string
	{
		if ($duration === '' || $duration === null) {
			return __('No scan yet', 'freesiem-sentinel');
		}

		$duration = (float) $duration;

		if ($duration <= 0) {
			return __('No scan yet', 'freesiem-sentinel');
		}

		return sprintf(__('%s seconds', 'freesiem-sentinel'), number_format_i18n($duration, 2));
	}

	private function build_scan_url(array $args = []): string
	{
		return freesiem_sentinel_admin_page_url('freesiem-scan', $args);
	}

	private function evidence_summary(array $finding): string
	{
		$evidence = freesiem_sentinel_safe_array($finding['evidence'] ?? []);
		$parts = array_filter([
			freesiem_sentinel_safe_string($evidence['change_type'] ?? ''),
			freesiem_sentinel_safe_string($evidence['extension'] ?? ''),
		]);

		return $parts === [] ? __('View details', 'freesiem-sentinel') : implode(' | ', $parts);
	}

	private function format_connection_state(string $state): string
	{
		return ucwords(str_replace('_', ' ', $state === '' ? 'disconnected' : $state));
	}

	private function render_pending_task_detail(array $task): void
	{
		$service = $this->plugin->get_pending_tasks();
		$events = $service->get_task_events((int) ($task['id'] ?? 0));
		$back_url = remove_query_arg('task_id');
		$approve_url = freesiem_sentinel_admin_post_url('freesiem_sentinel_approve_task', ['task_id' => (string) ($task['id'] ?? 0)]);
		$deny_url = admin_url('admin-post.php');
		$payload = is_array($task['payload'] ?? null) ? $task['payload'] : [];
		$execution_result = is_array($task['execution_result'] ?? null) ? $task['execution_result'] : [];

		echo '<div style="display:flex;gap:10px;flex-wrap:wrap;margin:18px 0;">';
		echo '<a class="button button-secondary" href="' . esc_url($back_url) . '">' . esc_html__('Back to Task Queue', 'freesiem-sentinel') . '</a>';
		if (($task['status'] ?? '') === 'pending') {
			echo '<a class="button button-primary" href="' . esc_url($approve_url) . '">' . esc_html__('Approve Task', 'freesiem-sentinel') . '</a>';
		}
		echo '</div>';

		echo '<div style="display:grid;grid-template-columns:minmax(0,1.4fr) minmax(280px,.8fr);gap:20px;">';
		echo '<div>';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Task Summary', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Local Task ID', 'freesiem-sentinel') . ':</strong> #' . esc_html((string) ($task['id'] ?? 0)) . '</p>';
		echo '<p><strong>' . esc_html__('Core Task ID', 'freesiem-sentinel') . ':</strong> <code>' . esc_html((string) ($task['core_task_id'] ?? '')) . '</code></p>';
		echo '<p><strong>' . esc_html__('Action', 'freesiem-sentinel') . ':</strong> ' . esc_html(ucwords(str_replace('_', ' ', (string) ($task['action_type'] ?? '')))) . '</p>';
		echo '<p><strong>' . esc_html__('Target', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->task_target_summary($task)) . '</p>';
		echo '<p><strong>' . esc_html__('Source Core', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($task['source_core_identifier'] ?? 'freeSIEM Core')) . '</p>';
		echo '<p><strong>' . esc_html__('Source URL', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($task['source_core_url'] ?? '')) . '</p>';
		echo '<p><strong>' . esc_html__('Signature Verified', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($task['signature_verified']) ? __('Yes', 'freesiem-sentinel') : __('No', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Status', 'freesiem-sentinel') . ':</strong> <span style="' . esc_attr($this->task_status_badge_style((string) ($task['status'] ?? 'pending'))) . '">' . esc_html(ucwords(str_replace('_', ' ', (string) ($task['status'] ?? 'pending')))) . '</span></p>';
		echo '<p><strong>' . esc_html__('Requested At', 'freesiem-sentinel') . ':</strong> ' . esc_html(freesiem_sentinel_format_datetime((string) ($task['requested_at'] ?? ''))) . '</p>';
		echo '<p><strong>' . esc_html__('Auto Approve At', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($task['auto_approve_at']) ? freesiem_sentinel_format_datetime((string) $task['auto_approve_at']) : __('Manual only', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Approval Mode', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($task['approval_mode'] ?? 'manual')) . '</p>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Payload Snapshot', 'freesiem-sentinel') . '</h2>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html(freesiem_sentinel_safe_json_pretty($payload)) . '</pre>';
		if (($task['action_type'] ?? '') === 'update_user') {
			echo '<h3>' . esc_html__('Requested Field Changes', 'freesiem-sentinel') . '</h3>';
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Field', 'freesiem-sentinel') . '</th><th>' . esc_html__('Requested Value', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach ((array) ($payload['target'] ?? $payload) as $field => $value) {
				if (in_array((string) $field, ['user_id', 'username', 'user_login', 'email', 'user_email'], true)) {
					continue;
				}
				echo '<tr><td>' . esc_html((string) $field) . '</td><td>' . esc_html(is_scalar($value) ? (string) $value : wp_json_encode($value)) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		if ($execution_result !== []) {
			echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
			echo '<h2 style="margin-top:0;">' . esc_html__('Execution Result', 'freesiem-sentinel') . '</h2>';
			echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html(freesiem_sentinel_safe_json_pretty($execution_result)) . '</pre>';
			echo '</div>';
		}

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Audit Trail', 'freesiem-sentinel') . '</h2>';
		if ($events === []) {
			$this->render_empty_state(__('No audit events yet.', 'freesiem-sentinel'), __('Task lifecycle events will appear here as the request moves through review and execution.', 'freesiem-sentinel'));
		} else {
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('When', 'freesiem-sentinel') . '</th><th>' . esc_html__('Event', 'freesiem-sentinel') . '</th><th>' . esc_html__('Message', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach ($events as $event) {
				echo '<tr><td>' . esc_html(freesiem_sentinel_format_datetime((string) ($event['created_at'] ?? ''))) . '</td><td>' . esc_html(ucwords(str_replace('_', ' ', (string) ($event['event_type'] ?? '')))) . '</td><td>' . esc_html((string) ($event['message'] ?? '')) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
		echo '</div>';

		echo '<div>';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Decision Controls', 'freesiem-sentinel') . '</h2>';
		if (($task['status'] ?? '') === 'pending') {
			echo '<p>' . esc_html__('This task is waiting for a local approval decision before WordPress executes it.', 'freesiem-sentinel') . '</p>';
			echo '<p><a class="button button-primary" href="' . esc_url($approve_url) . '">' . esc_html__('Approve Task', 'freesiem-sentinel') . '</a></p>';
			echo '<form method="post" action="' . esc_url($deny_url) . '">';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<input type="hidden" name="action" value="freesiem_sentinel_deny_task" />';
			echo '<input type="hidden" name="task_id" value="' . esc_attr((string) ($task['id'] ?? 0)) . '" />';
			echo '<p><label for="freesiem-deny-reason">' . esc_html__('Deny Reason', 'freesiem-sentinel') . '</label><br /><textarea id="freesiem-deny-reason" name="deny_reason" rows="4" class="large-text"></textarea></p>';
			submit_button(__('Deny Task', 'freesiem-sentinel'), 'secondary', '', false);
			echo '</form>';
		} else {
			$this->render_empty_state(__('Task decision already recorded.', 'freesiem-sentinel'), __('This task is no longer pending, so review controls are disabled.', 'freesiem-sentinel'));
		}
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Task Timing', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Approved At', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($task['approved_at']) ? freesiem_sentinel_format_datetime((string) $task['approved_at']) : __('Not approved yet', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Denied At', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($task['denied_at']) ? freesiem_sentinel_format_datetime((string) $task['denied_at']) : __('Not denied', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Executed At', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($task['executed_at']) ? freesiem_sentinel_format_datetime((string) $task['executed_at']) : __('Not executed yet', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Completed At', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($task['completed_at']) ? freesiem_sentinel_format_datetime((string) $task['completed_at']) : __('Not completed', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Failed At', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($task['failed_at']) ? freesiem_sentinel_format_datetime((string) $task['failed_at']) : __('Not failed', 'freesiem-sentinel')) . '</p>';
		if (!empty($task['deny_reason'])) {
			echo '<p><strong>' . esc_html__('Deny Reason', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) $task['deny_reason']) . '</p>';
		}
		if (!empty($task['error_message'])) {
			echo '<p><strong>' . esc_html__('Error', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) $task['error_message']) . '</p>';
		}
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}

	private function task_status_badge_style(string $status): string
	{
		$palette = match ($status) {
			'completed' => 'background:#ecfdf5;color:#166534;border:1px solid #86efac;',
			'failed', 'denied' => 'background:#fef2f2;color:#991b1b;border:1px solid #fca5a5;',
			'approved', 'auto_approved', 'executing' => 'background:#eff6ff;color:#1d4ed8;border:1px solid #93c5fd;',
			default => 'background:#fffbeb;color:#92400e;border:1px solid #fcd34d;',
		};

		return 'display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;font-weight:700;text-decoration:none;' . $palette;
	}

	private function task_target_summary(array $task): string
	{
		$parts = [];

		if (!empty($task['target_username'])) {
			$parts[] = '@' . (string) $task['target_username'];
		}
		if (!empty($task['target_email'])) {
			$parts[] = (string) $task['target_email'];
		}
		if (!empty($task['target_user_id'])) {
			$parts[] = '#' . (int) $task['target_user_id'];
		}

		return $parts !== [] ? implode(' ', $parts) : __('Site users', 'freesiem-sentinel');
	}

	private function is_cloud_connected(array $settings): bool
	{
		return Freesiem_Cloud_Connect_State::is_connected($settings);
	}

	private function format_tfa_label(string $value): string
	{
		return ucwords(str_replace('_', ' ', sanitize_key($value)));
	}

	private function tfa_status_badge_style(string $status): string
	{
		return match (sanitize_key($status)) {
			Freesiem_TFA_Service::STATUS_ENABLED => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#dcfce7;color:#166534;font-weight:600;',
			Freesiem_TFA_Service::STATUS_PENDING_SETUP => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#fef3c7;color:#92400e;font-weight:600;',
			default => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#e5e7eb;color:#374151;font-weight:600;',
		};
	}

	private function tfa_meta_badge_style(string $value): string
	{
		return sanitize_key($value) === 'core'
			? 'display:inline-block;padding:4px 10px;border-radius:999px;background:#dbeafe;color:#1d4ed8;font-weight:600;'
			: 'display:inline-block;padding:4px 10px;border-radius:999px;background:#ecfccb;color:#3f6212;font-weight:600;';
	}

	private function render_ssl_overview_tab(array $ssl_settings, array $preflight, array $dry_run, array $readiness, array $environment, array $ssl_state, array $install_environment): void
	{
		$certificate = freesiem_sentinel_get_certificate_view_data($ssl_state);
		$endpoint_status = freesiem_sentinel_get_ssl_endpoint_status($environment);
		$integration = freesiem_sentinel_detect_nginx_integration($ssl_settings, $environment, $ssl_state);
		$permission_guidance = freesiem_sentinel_get_nginx_permission_guidance($integration, $environment);
		$user_space = freesiem_sentinel_get_ssl_user_space_paths($ssl_settings);
		$user_space_config = !empty($ssl_state['user_space_config_dir']) ? (string) $ssl_state['user_space_config_dir'] : (string) ($user_space['config_dir'] ?? '');
		$lineage_exists = freesiem_sentinel_ssl_lineage_exists((string) ($environment['configured_host'] ?? ''), ['user_space' => ['config_dir' => $user_space_config]]);
		$issue_gate = freesiem_sentinel_can_run_live_ssl_action('issue', $ssl_settings, $environment, $readiness);
		$renew_gate = freesiem_sentinel_can_run_live_ssl_action('renew', $ssl_settings, $environment, $readiness);
		$resolved_provider = freesiem_sentinel_resolve_ssl_provider($ssl_settings, $environment);

		$this->render_ssl_action_bar($issue_gate, $renew_gate, $integration, $lineage_exists, $ssl_settings);

		echo '<div style="display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px;margin-bottom:20px;">';
		$this->render_summary_stat(__('Domain', 'freesiem-sentinel'), $environment['configured_host'] !== '' ? $environment['configured_host'] : __('Unavailable', 'freesiem-sentinel'));
		$this->render_summary_stat(__('HTTPS', 'freesiem-sentinel'), (string) ($endpoint_status['https'] ?? __('Unavailable', 'freesiem-sentinel')), __('WordPress HTTPS', 'freesiem-sentinel'), $environment['is_https_configured'] ? __('Yes', 'freesiem-sentinel') : __('No', 'freesiem-sentinel'));
		$this->render_summary_stat(__('Redirect', 'freesiem-sentinel'), (string) ($endpoint_status['redirect'] ?? __('Unavailable', 'freesiem-sentinel')), __('Force HTTPS', 'freesiem-sentinel'), !empty($ssl_settings['force_https']) ? __('Enabled', 'freesiem-sentinel') : __('Off', 'freesiem-sentinel'));
		if ($resolved_provider === 'php-acme') {
			$this->render_summary_stat(__('Provider', 'freesiem-sentinel'), __('PHP ACME (built-in)', 'freesiem-sentinel'), __('OpenSSL support', 'freesiem-sentinel'), !empty($environment['openssl_acme_support']) ? __('Yes', 'freesiem-sentinel') : __('No', 'freesiem-sentinel'));
		} else {
			$this->render_summary_stat(__('Provider', 'freesiem-sentinel'), !empty($environment['certbot']['available']) ? __('Certbot', 'freesiem-sentinel') : __('Certbot (missing)', 'freesiem-sentinel'), __('Version', 'freesiem-sentinel'), !empty($environment['certbot']['version']) ? (string) $environment['certbot']['version'] : __('Unavailable', 'freesiem-sentinel'));
		}
		$this->render_summary_stat(__('Certificate', 'freesiem-sentinel'), !empty($certificate['exists']) ? (!empty($certificate['is_staging_certificate']) ? __('Staging cert', 'freesiem-sentinel') : __('Present', 'freesiem-sentinel')) : __('Not found', 'freesiem-sentinel'), __('Nginx', 'freesiem-sentinel'), in_array((string) ($integration['mode'] ?? ''), ['patch', 'pending_root_finalize'], true) ? __('Ready', 'freesiem-sentinel') : __('Needs setup', 'freesiem-sentinel'));
		$this->render_summary_stat(__('HSTS', 'freesiem-sentinel'), (string) ($endpoint_status['hsts'] ?? __('Unavailable', 'freesiem-sentinel')), __('Configured', 'freesiem-sentinel'), !empty($ssl_settings['hsts_enabled']) ? __('Enabled', 'freesiem-sentinel') : __('Off', 'freesiem-sentinel'));
		echo '</div>';

		echo '<div style="display:grid;gap:16px;">';
		echo '<div style="background:#fff;padding:18px;border:1px solid #dcdcde;border-radius:12px;">';
		$this->render_ssl_next_steps_panel($ssl_settings, $environment, $ssl_state, $certificate, $integration, $endpoint_status);
		echo '</div>';

		echo '<div style="background:#fff;padding:18px;border:1px solid #dcdcde;border-radius:12px;">';
		$this->render_ssl_core_settings_panel($ssl_settings, $environment, $ssl_state);
		echo '</div>';

		echo '<div style="background:#fff;padding:18px;border:1px solid #dcdcde;border-radius:12px;">';
		$this->render_ssl_certificate_panel($certificate);
		echo '</div>';

		if ($resolved_provider === 'php-acme') {
			echo '<div style="background:#fff;padding:18px;border:1px solid #dcdcde;border-radius:12px;">';
			$this->render_ssl_php_acme_activation_guide($ssl_settings, $environment, $user_space);
			echo '</div>';
		}

		echo '<div style="background:#fff;padding:18px;border:1px solid #dcdcde;border-radius:12px;">';
		$this->render_ssl_nginx_section($ssl_settings, $environment, $ssl_state, $endpoint_status);
		echo '</div>';
		if (!empty($permission_guidance['blocked'])) {
			echo '<div style="background:#fff;padding:18px;border:1px solid #dcdcde;border-radius:12px;">';
			$this->render_ssl_nginx_permission_guidance($permission_guidance);
			echo '</div>';
		}
		echo '<div style="background:#fff;padding:18px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Logs / Diagnostics', 'freesiem-sentinel') . '</h2>';
		echo '<p style="margin:0 0 12px 0;color:#646970;">' . esc_html__('Preflight detail, dry-run output, nginx parsing detail, and raw command traces now live in the Logs tab to keep Overview clean.', 'freesiem-sentinel') . '</p>';
		echo '<p style="margin:0;"><a class="button button-secondary" href="' . esc_url(add_query_arg('tab', 'logs')) . '">' . esc_html__('Open Logs / Diagnostics', 'freesiem-sentinel') . '</a></p>';
		echo '</div>';
		echo '</div>';
	}

	private function render_ssl_action_bar(array $issue_gate, array $renew_gate, array $integration, bool $lineage_exists, array $ssl_settings): void
	{
		echo '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-start;margin-bottom:20px;background:#fff;padding:16px;border:1px solid #dcdcde;border-radius:12px;">';
		$this->render_ssl_action_form(__('Detect Nginx Config', 'freesiem-sentinel'), 'freesiem_sentinel_detect_nginx_config', true, '', 'secondary');
		$this->render_ssl_action_form(__('Run Preflight', 'freesiem-sentinel'), 'freesiem_sentinel_run_ssl_preflight', true, '', 'secondary', ['redirect_tab' => 'preflight']);
		$this->render_ssl_action_form(__('Run Dry Run', 'freesiem-sentinel'), 'freesiem_sentinel_run_ssl_dry_run', true, '', 'secondary', ['redirect_tab' => 'dry-run']);
		$this->render_ssl_action_form(__('Issue Certificate', 'freesiem-sentinel'), 'freesiem_sentinel_issue_ssl_certificate', !empty($issue_gate['allowed']), (string) ($issue_gate['reason'] ?? ''), 'primary');
		$this->render_ssl_action_form(__('Re-Issue Certificate', 'freesiem-sentinel'), 'freesiem_sentinel_issue_ssl_certificate', !empty($issue_gate['allowed']) && $lineage_exists, $lineage_exists ? __('Re-Issue uses force renewal to replace the current certificate lineage.', 'freesiem-sentinel') : __('No existing certificate lineage is available to replace yet.', 'freesiem-sentinel'), 'secondary', ['force_reissue_existing_certificate' => '1']);
		$this->render_ssl_action_form(__('Renew', 'freesiem-sentinel'), 'freesiem_sentinel_renew_ssl_certificate', !empty($renew_gate['allowed']), (string) ($renew_gate['reason'] ?? ''), 'secondary');
		$this->render_ssl_action_form(__('Apply SSL to Nginx', 'freesiem-sentinel'), 'freesiem_sentinel_apply_ssl_to_nginx', !empty($integration['apply_allowed']), (string) ($integration['apply_reason'] ?? $integration['reason'] ?? ''), 'secondary', ['enable_nginx_https_redirect' => !empty($ssl_settings['force_https']) ? '1' : '0']);
		echo '</div>';
	}

	private function render_ssl_action_form(string $label, string $action, bool $allowed, string $reason = '', string $button_class = 'secondary', array $hidden_fields = []): void
	{
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="' . esc_attr($action) . '" />';
		foreach ($hidden_fields as $name => $value) {
			if ($value === '') {
				continue;
			}
			echo '<input type="hidden" name="' . esc_attr((string) $name) . '" value="' . esc_attr((string) $value) . '" />';
		}
		submit_button($label, $button_class, '', false, $allowed ? [] : ['disabled' => 'disabled', 'title' => $reason !== '' ? $reason : __('Action unavailable.', 'freesiem-sentinel')]);
		echo '</form>';
	}

	private function render_ssl_core_settings_panel(array $ssl_settings, array $environment, array $ssl_state): void
	{
		$webroot = freesiem_sentinel_recommend_ssl_webroot_path($ssl_settings, $environment, $ssl_state);

		$resolved_provider = freesiem_sentinel_resolve_ssl_provider($ssl_settings, $environment);

		echo '<h2 style="margin-top:0;">' . esc_html__('Core SSL Settings', 'freesiem-sentinel') . '</h2>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0;">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_save_ssl_settings" />';
		echo '<div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;align-items:end;">';
		echo '<div><label for="freesiem-ssl-email" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('Email', 'freesiem-sentinel') . '</label><input id="freesiem-ssl-email" type="email" name="acme_contact_email" value="' . esc_attr((string) ($ssl_settings['acme_contact_email'] ?? '')) . '" class="regular-text" style="width:100%;max-width:none;" /></div>';
		echo '<div><label for="freesiem-ssl-webroot" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('Webroot', 'freesiem-sentinel') . '</label><input id="freesiem-ssl-webroot" type="text" name="webroot_path" value="' . esc_attr($webroot) . '" class="regular-text" style="width:100%;max-width:none;" /></div>';
		echo '<div><label for="freesiem-ssl-challenge" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('Challenge method', 'freesiem-sentinel') . '</label><select id="freesiem-ssl-challenge" name="challenge_method" style="width:100%;max-width:none;">';
		foreach ([
			'webroot-http-01' => __('webroot-http-01', 'freesiem-sentinel'),
			'standalone-http-01' => __('standalone-http-01', 'freesiem-sentinel'),
			'manual-dns-01' => __('manual-dns-01', 'freesiem-sentinel'),
		] as $value => $label) {
			echo '<option value="' . esc_attr($value) . '" ' . selected((string) ($ssl_settings['challenge_method'] ?? 'webroot-http-01'), $value, false) . '>' . esc_html($label) . '</option>';
		}
		echo '</select></div>';
		echo '<div><label for="freesiem-ssl-provider" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('Certificate provider', 'freesiem-sentinel') . '</label><select id="freesiem-ssl-provider" name="provider" style="width:100%;max-width:none;">';
		foreach ([
			'auto' => __('Automatic (recommended)', 'freesiem-sentinel'),
			'certbot' => __('Certbot (shell required)', 'freesiem-sentinel'),
			'php-acme' => __('PHP ACME client (no shell required)', 'freesiem-sentinel'),
		] as $value => $label) {
			echo '<option value="' . esc_attr($value) . '" ' . selected((string) ($ssl_settings['provider'] ?? 'auto'), $value, false) . '>' . esc_html($label) . '</option>';
		}
		echo '</select></div>';
		echo '</div>';
		echo '<div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin-top:12px;">';
		echo '<label><input type="checkbox" name="force_https" value="1" ' . checked(!empty($ssl_settings['force_https']), true, false) . ' /> ' . esc_html__('Force HTTPS', 'freesiem-sentinel') . '</label>';
		echo '<label><input type="checkbox" name="hsts_enabled" value="1" ' . checked(!empty($ssl_settings['hsts_enabled']), true, false) . ' /> ' . esc_html__('HSTS', 'freesiem-sentinel') . '</label>';
		echo '<label><input type="checkbox" name="auto_renew" value="1" ' . checked(!empty($ssl_settings['auto_renew']), true, false) . ' /> ' . esc_html__('Auto-renew', 'freesiem-sentinel') . '</label>';
		echo '<label><input type="checkbox" name="use_staging" value="1" ' . checked(!empty($ssl_settings['use_staging']), true, false) . ' /> ' . esc_html__('Use staging', 'freesiem-sentinel') . '</label>';
		echo '<label><input type="checkbox" name="detailed_logs" value="1" ' . checked(!empty($ssl_settings['detailed_logs']), true, false) . ' /> ' . esc_html__('Detailed logs', 'freesiem-sentinel') . '</label>';
		echo '</div>';
		echo '<p style="margin:10px 0 0 0;color:#646970;">' . esc_html__('Webroot is auto-populated from nginx when available and falls back to WordPress paths if needed. HSTS remains stored-only in this version. Auto-renew runs a daily background check and renews the certificate automatically once it is within its renewal window.', 'freesiem-sentinel') . '</p>';
		echo '<p style="margin:6px 0 0 0;color:#646970;">' . sprintf(
			/* translators: %s: resolved provider label, e.g. "Certbot" or "PHP ACME client". */
			esc_html__('"Automatic" currently resolves to: %s.', 'freesiem-sentinel'),
			'<strong>' . esc_html($resolved_provider === 'certbot' ? __('Certbot', 'freesiem-sentinel') : __('PHP ACME client (no shell required)', 'freesiem-sentinel')) . '</strong>'
		) . ' ' . esc_html__('The PHP ACME client only supports webroot-http-01 today; it ignores standalone-http-01/manual-dns-01.', 'freesiem-sentinel') . '</p>';

		echo '<div style="margin-top:16px;padding-top:14px;border-top:1px solid #dcdcde;">';
		echo '<h3 style="margin:0 0 6px 0;">' . esc_html__('cPanel auto-install (optional)', 'freesiem-sentinel') . '</h3>';
		echo '<p style="margin:0 0 10px 0;color:#646970;">' . esc_html__('When the PHP ACME client issues or renews a certificate, Sentinel will try to install it into cPanel automatically via UAPI (GoDaddy\'s usual shared-hosting stack). Leave blank to skip auto-install and copy the certificate manually from the Certificate panel instead - this is the normal path on hosts without cPanel, such as Hostinger.', 'freesiem-sentinel') . '</p>';
		echo '<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;">';
		echo '<div><label for="freesiem-cpanel-username" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('cPanel username', 'freesiem-sentinel') . '</label><input id="freesiem-cpanel-username" type="text" name="cpanel_username" value="' . esc_attr((string) ($ssl_settings['cpanel_username'] ?? '')) . '" class="regular-text" style="width:100%;max-width:none;" /></div>';
		echo '<div><label for="freesiem-cpanel-token" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('cPanel API token', 'freesiem-sentinel') . '</label><input id="freesiem-cpanel-token" type="password" name="cpanel_api_token" value="" autocomplete="new-password" placeholder="' . esc_attr(!empty($ssl_settings['cpanel_api_token']) ? freesiem_sentinel_mask_secret((string) $ssl_settings['cpanel_api_token']) : __('Not set', 'freesiem-sentinel')) . '" class="regular-text" style="width:100%;max-width:none;" /></div>';
		echo '<div><label for="freesiem-cpanel-host" style="display:block;font-weight:600;margin-bottom:6px;">' . esc_html__('cPanel host override', 'freesiem-sentinel') . '</label><input id="freesiem-cpanel-host" type="text" name="cpanel_host_override" value="' . esc_attr((string) ($ssl_settings['cpanel_host_override'] ?? '')) . '" placeholder="' . esc_attr($environment['configured_host'] ?? '') . '" class="regular-text" style="width:100%;max-width:none;" /></div>';
		echo '</div>';
		echo '<p style="margin:8px 0 0 0;color:#646970;">' . esc_html__('The token field is left blank on reload for security; leave it blank to keep the currently saved token, or type a new one to replace it.', 'freesiem-sentinel') . '</p>';
		echo '</div>';

		echo '<p style="margin:12px 0 0 0;">';
		submit_button(__('Save SSL Settings', 'freesiem-sentinel'), 'secondary', '', false);
		echo '</p>';
		echo '</form>';
	}

	private function render_ssl_certificate_panel(array $certificate): void
	{
		echo '<h2 style="margin-top:0;">' . esc_html__('Certificate', 'freesiem-sentinel') . '</h2>';
		if (!empty($certificate['is_staging_certificate'])) {
			echo '<p style="margin-top:0;padding:12px;border-radius:8px;background:#fee2e2;border:1px solid #fca5a5;"><strong>' . esc_html__('Browser warning expected.', 'freesiem-sentinel') . '</strong> ' . esc_html__('This site is currently serving a Let’s Encrypt staging certificate. Disable staging and issue a production certificate next.', 'freesiem-sentinel') . '</p>';
		}
		echo '<p><strong>' . esc_html__('Issuer', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($certificate['issuer']) ? (string) $certificate['issuer'] : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Expiry', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($certificate['expires_at']) ? (string) $certificate['expires_at'] : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('SANs', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($certificate['sans']) ? implode(', ', (array) $certificate['sans']) : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Environment', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($certificate['staging']) ? __('Staging', 'freesiem-sentinel') : __('Production', 'freesiem-sentinel')) . '</p>';
		echo '<details style="margin-top:12px;"><summary style="cursor:pointer;list-style:none;"><span class="button button-secondary">' . esc_html__('View Certificate', 'freesiem-sentinel') . '</span></summary>';
		if (empty($certificate['exists'])) {
			echo '<p style="margin-top:12px;">' . esc_html__('No certificate files are currently available to inspect.', 'freesiem-sentinel') . '</p>';
		} else {
			echo '<p style="margin-top:12px;"><strong>' . esc_html__('Certificate path', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($certificate['cert_path'] ?? '')) . '</p>';
			echo '<p><strong>' . esc_html__('Key path', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($certificate['key_path'] ?? '')) . '</p>';
			if (!empty($certificate['raw_text'])) {
				echo '<details style="margin-top:8px;"><summary style="cursor:pointer;">' . esc_html__('Show raw details', 'freesiem-sentinel') . '</summary><pre style="white-space:pre-wrap;overflow:auto;margin-top:12px;">' . esc_html((string) $certificate['raw_text']) . '</pre></details>';
			}
		}
		echo '</details>';
	}

	/**
	 * Shown only when the PHP ACME client is the active provider (no certbot,
	 * no nginx apply available). This is the one thing "Issue Certificate"
	 * does NOT do for you on shared hosting: a certbot/nginx VPS applies and
	 * reloads itself, but on GoDaddy/Hostinger-style cPanel accounts nothing
	 * terminates TLS with the freshly issued files until something installs
	 * them into the host. Written up here after walking a real GoDaddy cPanel
	 * account through it end to end.
	 */
	private function render_ssl_php_acme_activation_guide(array $ssl_settings, array $environment, array $user_space): void
	{
		$host = (string) ($environment['configured_host'] ?? '');
		$config_dir = rtrim((string) ($user_space['config_dir'] ?? ''), '/\\');
		$live_dir = $host !== '' && $config_dir !== '' ? $config_dir . '/live/' . $host : '';
		$has_cpanel_creds = !empty($ssl_settings['cpanel_username']) && !empty($ssl_settings['cpanel_api_token']);

		echo '<h2 style="margin-top:0;">' . esc_html__('Activating a PHP ACME Certificate', 'freesiem-sentinel') . '</h2>';
		echo '<p style="margin-top:0;color:#646970;">' . esc_html__('The PHP ACME client issues and verifies a real Let\'s Encrypt certificate and writes it to disk - but on shared hosting, WordPress/PHP does not terminate HTTPS itself, so nothing here automatically becomes the certificate your visitors see. One extra step is needed, one way or another.', 'freesiem-sentinel') . '</p>';

		echo '<p style="margin:14px 0 4px 0;"><strong>' . esc_html__('1. Check if it already installed automatically', 'freesiem-sentinel') . '</strong></p>';
		echo '<p style="margin:0;color:#646970;">' . ($has_cpanel_creds
			? esc_html__('cPanel auto-install credentials are configured, so the last Issue/Renew should have tried this already. Check the Logs tab for a "php_acme_cpanel_install" entry to see if it succeeded.', 'freesiem-sentinel')
			: esc_html__('No cPanel auto-install credentials are configured below, so nothing was attempted automatically - this cert is sitting as files only for now.', 'freesiem-sentinel')) . ' ' . esc_html__('Check the Logs tab for a "php_acme_cpanel_install" entry either way.', 'freesiem-sentinel') . '</p>';

		echo '<p style="margin:14px 0 4px 0;"><strong>' . esc_html__('2. If your host has cPanel, try its own AutoSSL first', 'freesiem-sentinel') . '</strong></p>';
		echo '<p style="margin:0;color:#646970;">' . esc_html__('Many cPanel hosts (GoDaddy included) already run free Let\'s Encrypt automation independent of this plugin: cPanel -> Security -> SSL/TLS Status -> "Run AutoSSL" for your domain. If that\'s available, it\'s often the simplest way to get a valid cert installed.', 'freesiem-sentinel') . '</p>';

		echo '<p style="margin:14px 0 4px 0;"><strong>' . esc_html__('3. Or let Sentinel install it automatically via cPanel', 'freesiem-sentinel') . '</strong></p>';
		echo '<p style="margin:0;color:#646970;">' . esc_html__('Fill in the cPanel username and API token fields below (your cPanel username is usually the same as your account\'s home-directory folder name), Save, then click "Re-Issue Certificate" - saving the settings by itself does not trigger an install, only a fresh Issue/Renew does.', 'freesiem-sentinel') . '</p>';

		echo '<p style="margin:14px 0 4px 0;"><strong>' . esc_html__('4. Or install it manually', 'freesiem-sentinel') . '</strong></p>';
		echo '<ol style="margin:4px 0 0 20px;color:#646970;">';
		echo '<li>' . sprintf(
			/* translators: %s: filesystem path to the issued certificate's directory. */
			esc_html__('In your host\'s File Manager (or FTP), find %s and download cert.pem, fullchain.pem, and privkey.pem.', 'freesiem-sentinel'),
			'<code>' . esc_html($live_dir !== '' ? $live_dir : __('the path shown in "View Certificate" above', 'freesiem-sentinel')) . '</code>'
		) . '</li>';
		echo '<li>' . esc_html__('In cPanel: Security -> SSL/TLS -> "Manage SSL sites", select your domain.', 'freesiem-sentinel') . '</li>';
		echo '<li>' . esc_html__('Certificate (CRT): upload/paste cert.pem - not fullchain.pem, cPanel rejects a multi-certificate file there as invalid.', 'freesiem-sentinel') . '</li>';
		echo '<li>' . esc_html__('Private Key (KEY): upload/paste privkey.pem.', 'freesiem-sentinel') . '</li>';
		echo '<li>' . esc_html__('Certificate Authority Bundle (CABUNDLE): leave this blank and click Install - cPanel auto-fetches the correct Let\'s Encrypt intermediate on its own in most cases. Only build a bundle manually (the second certificate block inside fullchain.pem, with the first block removed) if cPanel specifically complains that one is required.', 'freesiem-sentinel') . '</li>';
		echo '<li>' . esc_html__('Click Install Certificate, then re-check the site in a private/incognito browser window.', 'freesiem-sentinel') . '</li>';
		echo '</ol>';
		echo '<p style="margin:10px 0 0 0;color:#646970;">' . esc_html__('Once confirmed working, delete any locally downloaded copies of these files from your computer - privkey.pem especially should not sit around longer than needed.', 'freesiem-sentinel') . '</p>';

		echo '<p style="margin:14px 0 0 0;padding:10px 12px;border-radius:8px;background:#fef3c7;border:1px solid #fde68a;">' . esc_html__('Security note: this certificate\'s files live inside your webroot by default and get an automatic .htaccess (Require all denied) to block direct web access. If your host doesn\'t honor .htaccess (e.g. nginx instead of Apache/LiteSpeed), confirm the path above isn\'t reachable directly in a browser.', 'freesiem-sentinel') . '</p>';
	}

	private function render_ssl_nginx_section(array $ssl_settings, array $environment, array $ssl_state, array $endpoint_status): void
	{
		$integration = freesiem_sentinel_detect_nginx_integration($ssl_settings, $environment, $ssl_state);

		echo '<h2 style="margin-top:0;">' . esc_html__('Nginx Integration', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Integration mode', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($integration['mode'] ?? 'manual_required')) . '</p>';
		echo '<p><strong>' . esc_html__('Detection result', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($integration['reason'] ?? __('Unavailable', 'freesiem-sentinel'))) . '</p>';
		echo '<p><strong>' . esc_html__('Matched file', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($integration['target_path'] ?? __('Unavailable', 'freesiem-sentinel'))) . '</p>';
		echo '<p><strong>' . esc_html__('Matched server_name', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($integration['matched_server_name'] ?? __('Unavailable', 'freesiem-sentinel'))) . '</p>';
		echo '<p><strong>' . esc_html__('Confidence level', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($integration['detection_confidence'] ?? 'ambiguous')) . '</p>';
		echo '<p><strong>' . esc_html__('Redirect on apply', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_settings['force_https']) ? __('Enabled', 'freesiem-sentinel') : __('Off', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('HSTS on apply', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_settings['hsts_enabled']) ? __('Enabled', 'freesiem-sentinel') : __('Off', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Last apply attempt', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback((string) ($ssl_state['nginx_last_apply_at'] ?? ''), true) . ' / ' . (!empty($ssl_state['nginx_last_apply_status']) ? (string) $ssl_state['nginx_last_apply_status'] : __('none', 'freesiem-sentinel'))) . '</p>';
		if (empty($integration['apply_allowed'])) {
			echo '<p><strong>' . esc_html__('Apply gate', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($integration['apply_reason'] ?? $integration['reason'] ?? __('Automatic nginx apply is unavailable.', 'freesiem-sentinel'))) . '</p>';
		}
		echo '<table class="widefat striped" style="margin-bottom:14px;"><thead><tr><th>' . esc_html__('Check', 'freesiem-sentinel') . '</th><th>' . esc_html__('Status', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
		foreach ([
			__('Nginx binary', 'freesiem-sentinel') => !empty($integration['detection_checks']['binary']) ? strtoupper((string) $integration['detection_checks']['binary']) : (!empty($integration['binary_available']) ? 'PASS' : 'FAIL'),
			__('Command execution', 'freesiem-sentinel') => !empty($integration['detection_checks']['execution']) ? strtoupper((string) $integration['detection_checks']['execution']) : (!empty($integration['execution_available']) ? 'PASS' : 'FAIL'),
			__('Hostname', 'freesiem-sentinel') => !empty($integration['detection_checks']['hostname']) ? strtoupper((string) $integration['detection_checks']['hostname']) : (!empty($environment['configured_host']) ? 'PASS' : 'WARN'),
			__('nginx -T', 'freesiem-sentinel') => !empty($integration['detection_checks']['nginx_t']) ? strtoupper((string) $integration['detection_checks']['nginx_t']) : (!empty($integration['nginx_t_ok']) ? 'PASS' : 'WARN'),
			__('Parsing / config path', 'freesiem-sentinel') => !empty($integration['detection_checks']['parsing']) ? strtoupper((string) $integration['detection_checks']['parsing']) : (!empty($integration['target_path']) ? 'PASS' : 'FAIL'),
			__('Config writable', 'freesiem-sentinel') => !empty($integration['config_writable']) ? 'PASS' : 'FAIL',
			__('Snippets writable', 'freesiem-sentinel') => !empty($integration['snippet_dir_writable']) ? 'PASS' : 'FAIL',
			__('Certificate files', 'freesiem-sentinel') => (!empty($integration['fullchain_exists']) && !empty($integration['privkey_exists'])) ? 'PASS' : 'FAIL',
			__('Redirect status', 'freesiem-sentinel') => !empty($endpoint_status['redirect_enabled']) ? 'PASS' : (!empty($ssl_settings['force_https']) ? 'FAIL' : 'WARN'),
			__('HSTS status', 'freesiem-sentinel') => !empty($endpoint_status['hsts_enabled']) ? 'PASS' : (!empty($ssl_settings['hsts_enabled']) ? 'FAIL' : 'WARN'),
		] as $label => $status) {
			echo '<tr><td>' . esc_html($label) . '</td><td><span style="' . esc_attr($this->ssl_preflight_badge_style($status)) . '">' . esc_html($status) . '</span></td></tr>';
		}
		echo '</tbody></table>';
		echo '<p><strong>' . esc_html__('Last live status check', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback((string) ($ssl_state['live_status_checked_at'] ?? ''), true)) . '</p>';
		echo '<p><strong>' . esc_html__('Last nginx test result', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['nginx_last_test_result']) ? (string) $ssl_state['nginx_last_test_result'] : __('None yet', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Last nginx reload result', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['nginx_last_reload_result']) ? (string) $ssl_state['nginx_last_reload_result'] : __('None yet', 'freesiem-sentinel')) . '</p>';
		echo '<p style="margin-bottom:6px;color:#646970;">' . esc_html__('Deep nginx preview and parser output now live in the Logs tab. Apply SSL to Nginx respects both Force HTTPS and HSTS from Core SSL Settings.', 'freesiem-sentinel') . '</p>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html((string) ($integration['test_command'] ?? 'nginx -t') . "\n" . (string) ($integration['reload_command'] ?? 'nginx -s reload')) . '</pre>';
	}

	private function render_ssl_next_steps_panel(array $ssl_settings, array $environment, array $ssl_state, array $certificate, array $integration, array $endpoint_status): void
	{
		$steps = [];
		$title = __('What To Do Next', 'freesiem-sentinel');

		if (!empty($certificate['is_staging_certificate']) && empty($ssl_settings['use_staging'])) {
			$steps[] = __('Issue a production certificate now.', 'freesiem-sentinel');
			$steps[] = __('If the lineage is reused, use Re-Issue Certificate from the top action bar.', 'freesiem-sentinel');
			$steps[] = __('After issuance, apply the updated cert to nginx.', 'freesiem-sentinel');
		} elseif (!empty($certificate['is_staging_certificate'])) {
			$steps[] = __('Turn off staging in Core SSL Settings.', 'freesiem-sentinel');
			$steps[] = __('Issue a browser-trusted production certificate.', 'freesiem-sentinel');
		} elseif (($ssl_state['nginx_integration_mode'] ?? '') === 'pending_root_finalize') {
			$steps[] = __('Run nginx -t as root, then reload nginx as root.', 'freesiem-sentinel');
			$steps[] = __('Refresh this page and verify HTTPS loads without browser warnings.', 'freesiem-sentinel');
		} elseif (empty($certificate['exists'])) {
			$steps[] = __('Run Preflight if needed, then issue the first certificate.', 'freesiem-sentinel');
		} elseif (!empty($integration['apply_allowed']) && empty($ssl_state['nginx_last_apply_at'])) {
			$steps[] = __('Apply SSL to nginx so the site starts serving the certificate.', 'freesiem-sentinel');
		} elseif (!empty($ssl_settings['force_https']) && empty($endpoint_status['redirect_enabled'])) {
			$steps[] = __('Force HTTPS is enabled, but HTTP is still serving directly.', 'freesiem-sentinel');
			$steps[] = __('Apply SSL to nginx again so the redirect block is written.', 'freesiem-sentinel');
		} elseif (!empty($certificate['exists']) && !empty($endpoint_status['https_ok']) && (empty($ssl_settings['force_https']) || !empty($endpoint_status['redirect_enabled']))) {
			$steps[] = __('SSL fully configured.', 'freesiem-sentinel');
			$steps[] = __('Optional: switch the WordPress Site URL and Home URL to HTTPS if they still use HTTP.', 'freesiem-sentinel');
		} else {
			$steps[] = __('Refresh detection and review the latest SSL status.', 'freesiem-sentinel');
		}

		if (!$environment['is_https_configured'] && !empty($endpoint_status['https_ok']) && empty($certificate['is_staging_certificate'])) {
			$steps[] = __('Update the WordPress Site URL and Home URL to HTTPS when you are ready.', 'freesiem-sentinel');
		}

		echo '<h2 style="margin-top:0;">' . esc_html($title) . '</h2>';
		echo '<ol style="margin:0;padding-left:18px;">';
		foreach ($steps as $step) {
			echo '<li style="margin-bottom:8px;">' . esc_html((string) $step) . '</li>';
		}
		echo '</ol>';
	}

	private function render_ssl_nginx_permission_guidance(array $guidance): void
	{
		echo '<h2 style="margin-top:0;">' . esc_html__('Permissions Required for Auto Apply', 'freesiem-sentinel') . '</h2>';
		echo '<p style="margin-top:0;color:#646970;">' . esc_html__('Auto apply is blocked by filesystem permissions. Sentinel only recommends the minimum write access needed for the detected nginx files.', 'freesiem-sentinel') . '</p>';
		echo '<p><strong>' . esc_html__('Detected web user', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($guidance['web_user']['user'] ?? 'www-data')) . ' (' . esc_html((string) ($guidance['web_user']['confidence'] ?? 'low')) . ')</p>';
		echo '<table class="widefat striped" style="margin-bottom:14px;"><thead><tr><th>' . esc_html__('Path', 'freesiem-sentinel') . '</th><th>' . esc_html__('Writable', 'freesiem-sentinel') . '</th><th>' . esc_html__('Reason needed', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
		foreach ((array) ($guidance['items'] ?? []) as $item) {
			if (!is_array($item)) {
				continue;
			}
			echo '<tr>';
			echo '<td><code>' . esc_html((string) ($item['path'] ?? '')) . '</code></td>';
			echo '<td><span style="' . esc_attr($this->ssl_preflight_badge_style(!empty($item['writable']) ? 'PASS' : 'FAIL')) . '">' . esc_html(!empty($item['writable']) ? 'PASS' : 'FAIL') . '</span></td>';
			echo '<td>' . esc_html((string) ($item['reason'] ?? '')) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
		echo '<p><strong>' . esc_html__('Recommended order', 'freesiem-sentinel') . ':</strong></p>';
		echo '<ul style="margin-top:0;">';
		echo '<li><strong>' . esc_html__('ACL', 'freesiem-sentinel') . '</strong> ' . esc_html__('LOW risk. Preferred because it grants path-specific access to the detected web user only.', 'freesiem-sentinel') . '</li>';
		echo '<li><strong>' . esc_html__('Group write', 'freesiem-sentinel') . '</strong> ' . esc_html__('MEDIUM risk. Use only if ACL is unavailable on this server.', 'freesiem-sentinel') . '</li>';
		echo '<li><strong>' . esc_html__('Broad permissions', 'freesiem-sentinel') . '</strong> ' . esc_html__('NOT recommended. Sentinel does not suggest chmod 777 or broad /etc/nginx access.', 'freesiem-sentinel') . '</li>';
		echo '</ul>';
		echo '<p><strong>' . esc_html__('ACL example commands', 'freesiem-sentinel') . ':</strong></p>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html(implode("\n", (array) ($guidance['commands']['acl'] ?? []))) . '</pre>';
		echo '<p><strong>' . esc_html__('Fallback group-write commands', 'freesiem-sentinel') . ':</strong></p>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html(implode("\n", (array) ($guidance['commands']['group_write'] ?? []))) . '</pre>';
		echo '<p><strong>' . esc_html__('Next steps', 'freesiem-sentinel') . ':</strong></p>';
		echo '<ol style="margin-top:0;padding-left:18px;">';
		foreach ((array) ($guidance['steps'] ?? []) as $step) {
			echo '<li>' . esc_html((string) $step) . '</li>';
		}
		echo '</ol>';
	}

	private function render_ssl_preflight_tab(array $preflight): void
	{
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Safe Preflight Checks', 'freesiem-sentinel') . '</h2>';
		echo '<p>' . esc_html__('This preflight only inspects WordPress and server readiness. It does not run certbot, issue certificates, install packages, or change web server configuration.', 'freesiem-sentinel') . '</p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_run_ssl_preflight" />';
		submit_button(__('Run Preflight', 'freesiem-sentinel'), 'primary', '', false);
		echo '</form>';
		echo '</div>';
		$this->render_ssl_results_table($preflight, __('Latest Results', 'freesiem-sentinel'));
	}

	private function render_ssl_settings_tab(array $ssl_settings, array $readiness, array $environment, array $install_environment): void
	{
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_save_ssl_settings" />';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Future SSL Settings', 'freesiem-sentinel') . '</h2>';
		echo '<p><span style="' . esc_attr($this->ssl_readiness_badge_style((string) ($readiness['state'] ?? 'not_configured'))) . '">' . esc_html(strtoupper((string) ($readiness['state'] ?? 'not_configured'))) . '</span></p>';
		echo '<p style="margin-bottom:0;color:#646970;"><strong>' . esc_html__('Stored only for future implementation; not active in this version.', 'freesiem-sentinel') . '</strong></p>';
		echo '</div>';

		echo '<table class="form-table" role="presentation">';
		$this->render_ssl_checkbox_field('enable_management_ui', __('Enable SSL management UI', 'freesiem-sentinel'), !empty($ssl_settings['enable_management_ui']), __('Keeps this SSL/HTTPS admin area available without turning on live SSL management.', 'freesiem-sentinel'));
		$this->render_ssl_text_field('acme_contact_email', __('ACME contact email', 'freesiem-sentinel'), (string) ($ssl_settings['acme_contact_email'] ?? ''), __('Stored for future certificate registration only.', 'freesiem-sentinel'), 'email');
		$this->render_ssl_text_field('hostname_override', __('Preferred domain / hostname override', 'freesiem-sentinel'), (string) ($ssl_settings['hostname_override'] ?? ''), __('Optional override used by preflight, dry run, and future certificate planning.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('allow_local_override', __('Allow localhost / IP override', 'freesiem-sentinel'), !empty($ssl_settings['allow_local_override']), __('Use only if you intentionally want validation to accept a local or IP-based hostname.', 'freesiem-sentinel'));
		echo '<tr><th scope="row"><label for="freesiem-challenge-method">' . esc_html__('Preferred challenge method', 'freesiem-sentinel') . '</label></th><td>';
		echo '<select id="freesiem-challenge-method" name="challenge_method">';
		foreach ([
			'webroot-http-01' => __('webroot-http-01', 'freesiem-sentinel'),
			'standalone-http-01' => __('standalone-http-01', 'freesiem-sentinel'),
			'manual-dns-01' => __('manual-dns-01', 'freesiem-sentinel'),
		] as $value => $label) {
			echo '<option value="' . esc_attr($value) . '" ' . selected((string) ($ssl_settings['challenge_method'] ?? ''), $value, false) . '>' . esc_html($label) . '</option>';
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__('Selection is stored now for future implementation only.', 'freesiem-sentinel') . '</p>';
		echo '</td></tr>';
		$this->render_ssl_text_field('webroot_path', __('Webroot path', 'freesiem-sentinel'), (string) ($ssl_settings['webroot_path'] ?? ''), __('Required for webroot HTTP-01 dry-run validation and future planning.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('check_port_80', __('Intent to use port 80', 'freesiem-sentinel'), !empty($ssl_settings['check_port_80']), __('Used for readiness reporting only right now.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('check_port_443', __('Intent to use port 443', 'freesiem-sentinel'), !empty($ssl_settings['check_port_443']), __('Used for readiness reporting only right now.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('force_https', __('Force HTTPS', 'freesiem-sentinel'), !empty($ssl_settings['force_https']), __('Stored only for future implementation; no redirects are added in this version.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('hsts_enabled', __('HSTS', 'freesiem-sentinel'), !empty($ssl_settings['hsts_enabled']), __('Applied through nginx SSL config when you run Apply SSL to Nginx.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('auto_renew', __('Auto-renew', 'freesiem-sentinel'), !empty($ssl_settings['auto_renew']), __('Runs a daily background check (via WP-Cron) and renews the certificate automatically once it is within its Let\'s Encrypt renewal window. Nginx is reloaded automatically where the host allows it; otherwise a manual reload may be needed.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('use_staging', __('Use Let’s Encrypt staging', 'freesiem-sentinel'), !empty($ssl_settings['use_staging']), __('Recommended for safe simulated execution planning.', 'freesiem-sentinel'));
		$this->render_ssl_checkbox_field('detailed_logs', __('Enable detailed SSL logs', 'freesiem-sentinel'), !empty($ssl_settings['detailed_logs']), __('Adds category and context details to the lightweight SSL log store.', 'freesiem-sentinel'));
		echo '</table>';
		submit_button(__('Save SSL Settings', 'freesiem-sentinel'));
		echo '</form>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-top:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Certbot Installation', 'freesiem-sentinel') . '</h2>';
		$this->render_ssl_install_section($environment, $install_environment, freesiem_sentinel_can_install_certbot($install_environment, $environment));
		echo '</div>';
	}

	private function render_ssl_dry_run_tab(array $ssl_settings, array $dry_run, array $readiness, array $environment, array $ssl_state): void
	{
		$preview = freesiem_sentinel_get_ssl_command_preview($ssl_settings, $environment);
		$issue_gate = freesiem_sentinel_can_run_live_ssl_action('issue', $ssl_settings, $environment, $readiness);
		$renew_gate = freesiem_sentinel_can_run_live_ssl_action('renew', $ssl_settings, $environment, $readiness);

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Dry Run Validation', 'freesiem-sentinel') . '</h2>';
		echo '<p>' . esc_html__('This dry run re-checks configuration completeness, re-runs safe preflight, builds a simulated command preview, and records whether the site would be ready for an explicit admin-triggered issuance attempt. No certificate will be issued by this dry-run action.', 'freesiem-sentinel') . '</p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
		echo '<input type="hidden" name="action" value="freesiem_sentinel_run_ssl_dry_run" />';
		submit_button(__('Run Dry Run Validation', 'freesiem-sentinel'), 'primary', '', false);
		echo '</form>';
		echo '</div>';

		echo '<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(280px,.9fr);gap:20px;margin-bottom:20px;">';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Simulated Command Preview', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html((string) ($preview['label'] ?? __('Preview only', 'freesiem-sentinel'))) . '</strong></p>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html((string) ($preview['command'] ?? '')) . '</pre>';
		if (!empty($preview['user_space']) && is_array($preview['user_space'])) {
			echo '<p><strong>' . esc_html__('User-space config dir', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($preview['user_space']['config_dir'] ?? '')) . '</p>';
			echo '<p><strong>' . esc_html__('User-space work dir', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($preview['user_space']['work_dir'] ?? '')) . '</p>';
			echo '<p><strong>' . esc_html__('User-space logs dir', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($preview['user_space']['logs_dir'] ?? '')) . '</p>';
		}
		echo '<p style="margin-bottom:0;color:#646970;">' . esc_html__('Preview only. No shell execution occurs in this version.', 'freesiem-sentinel') . '</p>';
		echo '</div>';
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Readiness Snapshot', 'freesiem-sentinel') . '</h2>';
		echo '<p><span style="' . esc_attr($this->ssl_readiness_badge_style((string) ($readiness['state'] ?? 'not_configured'))) . '">' . esc_html(strtoupper((string) ($readiness['state'] ?? 'not_configured'))) . '</span></p>';
		echo '<p><strong>' . esc_html((string) ($readiness['label'] ?? '')) . '</strong></p>';
		echo '<p><strong>' . esc_html__('Current certbot state', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($environment['certbot']['available']) ? sprintf(__('Available (%s)', 'freesiem-sentinel'), (string) ($environment['certbot']['version'] ?? '')) : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Last verification', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['last_verification_result']) ? (string) $ssl_state['last_verification_result'] : __('No verification recorded yet.', 'freesiem-sentinel')) . '</p>';
		echo '<p style="margin-bottom:0;color:#646970;">' . esc_html((string) ($readiness['description'] ?? '')) . '</p>';
		echo '</div>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Live Action Gates', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Issue Certificate', 'freesiem-sentinel') . ':</strong> ' . esc_html($issue_gate['allowed'] ? __('Enabled', 'freesiem-sentinel') : (string) $issue_gate['reason']) . '</p>';
		echo '<p style="margin-bottom:0;"><strong>' . esc_html__('Renew Now', 'freesiem-sentinel') . ':</strong> ' . esc_html($renew_gate['allowed'] ? __('Enabled', 'freesiem-sentinel') : (string) $renew_gate['reason']) . '</p>';
		echo '</div>';

		$this->render_ssl_results_table($dry_run, __('Latest Dry Run', 'freesiem-sentinel'));

		if (!empty($dry_run['plan'])) {
			echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-top:20px;">';
			echo '<h2 style="margin-top:0;">' . esc_html__('Execution Plan Summary', 'freesiem-sentinel') . '</h2>';
			echo '<ol style="margin:0;padding-left:18px;">';
			foreach ((array) $dry_run['plan'] as $step) {
				echo '<li style="margin-bottom:8px;">' . esc_html((string) $step) . '</li>';
			}
			echo '</ol>';
			echo '</div>';
		}
	}

	private function render_ssl_logs_tab(array $logs, array $preflight, array $dry_run, array $ssl_state): void
	{
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Latest Summary', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Last preflight', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback((string) ($preflight['ran_at'] ?? ''), true)) . '</p>';
		echo '<p><strong>' . esc_html__('Preflight summary', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($preflight['summary'] ?? __('No preflight run yet.', 'freesiem-sentinel'))) . '</p>';
		echo '<p><strong>' . esc_html__('Last dry run', 'freesiem-sentinel') . ':</strong> ' . esc_html($this->summary_value_or_fallback((string) ($dry_run['ran_at'] ?? ''), true)) . '</p>';
		echo '<p style="margin-bottom:0;"><strong>' . esc_html__('Dry-run summary', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) ($dry_run['summary'] ?? __('No dry run yet.', 'freesiem-sentinel'))) . '</p>';
		echo '</div>';

		echo '<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:20px;margin-bottom:20px;">';
		$this->render_ssl_results_table($preflight, __('Preflight Details', 'freesiem-sentinel'));
		$this->render_ssl_results_table($dry_run, __('Dry Run Details', 'freesiem-sentinel'));
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;margin-bottom:20px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Nginx Detection Details', 'freesiem-sentinel') . '</h2>';
		echo '<p><strong>' . esc_html__('Detection source', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['nginx_detection_source']) ? (string) $ssl_state['nginx_detection_source'] : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Matched file', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['nginx_config_path']) ? (string) $ssl_state['nginx_config_path'] : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Matched server_name', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['nginx_matched_server_name']) ? (string) $ssl_state['nginx_matched_server_name'] : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p><strong>' . esc_html__('Confidence', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['nginx_detection_confidence']) ? (string) $ssl_state['nginx_detection_confidence'] : __('Unavailable', 'freesiem-sentinel')) . '</p>';
		echo '<p style="margin-bottom:0;"><strong>' . esc_html__('Last detect result', 'freesiem-sentinel') . ':</strong> ' . esc_html(!empty($ssl_state['nginx_last_detect_result']) ? (string) $ssl_state['nginx_last_detect_result'] : __('None yet', 'freesiem-sentinel')) . '</p>';
		echo '</div>';

		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<h2 style="margin-top:0;">' . esc_html__('Event Log', 'freesiem-sentinel') . '</h2>';
		if ($logs === []) {
			$this->render_empty_state(__('No SSL events logged yet.', 'freesiem-sentinel'), __('Saving SSL settings, running preflight, or running a dry run will add lightweight event entries here.', 'freesiem-sentinel'));
		} else {
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Timestamp', 'freesiem-sentinel') . '</th><th>' . esc_html__('Category', 'freesiem-sentinel') . '</th><th>' . esc_html__('Level', 'freesiem-sentinel') . '</th><th>' . esc_html__('Message', 'freesiem-sentinel') . '</th><th>' . esc_html__('Context', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach ($logs as $entry) {
				if (!is_array($entry)) {
					continue;
				}
				echo '<tr>';
				echo '<td>' . esc_html($this->summary_value_or_fallback((string) ($entry['timestamp'] ?? ''), true)) . '</td>';
				echo '<td>' . esc_html(ucwords(str_replace('_', ' ', (string) ($entry['category'] ?? 'general')))) . '</td>';
				echo '<td><span style="' . esc_attr($this->ssl_log_badge_style((string) ($entry['level'] ?? 'info'))) . '">' . esc_html(strtoupper((string) ($entry['level'] ?? 'info'))) . '</span></td>';
				echo '<td>' . esc_html((string) ($entry['message'] ?? '')) . '</td>';
				echo '<td><code>' . esc_html(wp_json_encode((array) ($entry['context'] ?? []))) . '</code></td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	private function render_ssl_results_table(array $result, string $title): void
	{
		echo '<div style="background:#fff;padding:20px;border:1px solid #dcdcde;border-radius:12px;">';
		echo '<div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">';
		echo '<div>';
		echo '<h2 style="margin:0 0 6px 0;">' . esc_html($title) . '</h2>';
		echo '<p style="margin:0;color:#646970;">' . esc_html($this->summary_value_or_fallback((string) ($result['ran_at'] ?? ''), true)) . '</p>';
		echo '</div>';
		echo '<p style="margin:0;"><strong>' . esc_html((string) ($result['summary'] ?? __('No results yet.', 'freesiem-sentinel'))) . '</strong></p>';
		echo '</div>';

		if (empty($result['items'])) {
			echo '<div style="margin-top:20px;">';
			$this->render_empty_state(__('No results yet.', 'freesiem-sentinel'), __('Run the relevant SSL validation action to populate results here.', 'freesiem-sentinel'));
			echo '</div>';
		} else {
			echo '<table class="widefat striped" style="margin-top:20px;"><thead><tr><th>' . esc_html__('Check', 'freesiem-sentinel') . '</th><th>' . esc_html__('Status', 'freesiem-sentinel') . '</th><th>' . esc_html__('Details', 'freesiem-sentinel') . '</th></tr></thead><tbody>';
			foreach ((array) $result['items'] as $item) {
				if (!is_array($item)) {
					continue;
				}
				echo '<tr>';
				echo '<td><strong>' . esc_html((string) ($item['label'] ?? '')) . '</strong></td>';
				echo '<td><span style="' . esc_attr($this->ssl_preflight_badge_style((string) ($item['status'] ?? 'WARN'))) . '">' . esc_html((string) ($item['status'] ?? 'WARN')) . '</span></td>';
				echo '<td>' . esc_html((string) ($item['message'] ?? '')) . '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	private function render_ssl_install_section(array $environment, array $install_environment, array $install_gate): void
	{
		$preview = freesiem_sentinel_get_certbot_install_preview($install_environment);
		$manual = freesiem_sentinel_get_certbot_manual_install_instructions();
		$show_button = empty($environment['certbot']['available']) && !empty($environment['execution_support']);

		if ($show_button) {
			if (!$install_gate['allowed']) {
				echo '<p><strong>' . esc_html__('Install gate', 'freesiem-sentinel') . ':</strong> ' . esc_html((string) $install_gate['reason']) . '</p>';
			}

			if (!empty($preview['preview'])) {
				echo '<p><strong>' . esc_html__('Install preview', 'freesiem-sentinel') . ':</strong></p>';
				echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html((string) $preview['preview']) . '</pre>';
			}

			echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
			wp_nonce_field(FREESIEM_SENTINEL_NONCE_ACTION);
			echo '<input type="hidden" name="action" value="freesiem_sentinel_install_certbot" />';
			echo '<p><label><input type="checkbox" name="confirm_certbot_install" value="1" /> ' . esc_html__('I understand this requires server-level permissions', 'freesiem-sentinel') . '</label></p>';
			submit_button(__('Install Certbot', 'freesiem-sentinel'), 'secondary', '', false, $install_gate['allowed'] ? [] : ['disabled' => 'disabled']);
			echo '</form>';
		}

		echo '<p><strong>' . esc_html__('Manual fallback', 'freesiem-sentinel') . ':</strong></p>';
		echo '<p style="margin-bottom:6px;"><strong>' . esc_html__('Ubuntu / Debian', 'freesiem-sentinel') . '</strong></p>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html((string) $manual['ubuntu']) . '</pre>';
		echo '<p style="margin-bottom:6px;"><strong>' . esc_html__('CentOS / RHEL', 'freesiem-sentinel') . '</strong></p>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;">' . esc_html((string) $manual['centos']) . '</pre>';
		echo '<p style="margin-bottom:6px;"><strong>' . esc_html__('Snap', 'freesiem-sentinel') . '</strong></p>';
		echo '<pre style="white-space:pre-wrap;overflow:auto;margin-bottom:0;">' . esc_html((string) $manual['snap']) . '</pre>';
	}

	private function render_ssl_readiness_details(array $ssl_settings, array $environment, array $readiness): void
	{
		$details = [
			['status' => is_email((string) ($ssl_settings['acme_contact_email'] ?? '')) ? 'PASS' : 'FAIL', 'message' => __('ACME contact email is configured.', 'freesiem-sentinel')],
			['status' => $environment['configured_host'] !== '' ? 'PASS' : 'FAIL', 'message' => __('Hostname/domain is configured.', 'freesiem-sentinel')],
			['status' => !empty($environment['certbot']['available']) ? 'PASS' : 'FAIL', 'message' => !empty($environment['certbot']['available']) ? __('Certbot is installed and detectable.', 'freesiem-sentinel') : __('Certbot is not installed or not detectable on this server.', 'freesiem-sentinel')],
			['status' => $environment['execution_support'] ? 'PASS' : 'FAIL', 'message' => $environment['execution_support'] ? __('Command execution capability is available.', 'freesiem-sentinel') : __('Command execution capability is not available.', 'freesiem-sentinel')],
			['status' => empty($readiness['warning_messages']) ? 'PASS' : 'WARN', 'message' => empty($readiness['warning_messages']) ? __('No readiness warnings remain.', 'freesiem-sentinel') : __('One or more readiness warnings still need review.', 'freesiem-sentinel')],
		];

		echo '<p><strong>' . esc_html__('Readiness Details', 'freesiem-sentinel') . '</strong></p>';
		echo '<ul style="margin-top:0;margin-bottom:0;">';
		foreach ($details as $detail) {
			echo '<li><span style="' . esc_attr($this->ssl_preflight_badge_style((string) $detail['status'])) . '">' . esc_html((string) $detail['status']) . '</span> ' . esc_html((string) $detail['message']) . '</li>';
		}
		echo '</ul>';
	}

	private function format_ssl_install_environment(array $install_environment): string
	{
		$parts = [];
		if (!empty($install_environment['os_family'])) {
			$parts[] = str_replace('_', '/', (string) $install_environment['os_family']);
		}
		if (!empty($install_environment['root_status'])) {
			$parts[] = 'privileges: ' . (string) $install_environment['root_status'];
		}
		if (!empty($install_environment['install_method'])) {
			$parts[] = 'installer: ' . (string) $install_environment['install_method'];
		}

		return $parts !== [] ? implode(' | ', $parts) : __('Unknown', 'freesiem-sentinel');
	}

	private function render_ssl_checkbox_field(string $name, string $label, bool $checked, string $description): void
	{
		echo '<tr><th scope="row">' . esc_html($label) . '</th><td>';
		echo '<label><input type="checkbox" name="' . esc_attr($name) . '" value="1" ' . checked($checked, true, false) . ' /> ' . esc_html__('Enabled', 'freesiem-sentinel') . '</label>';
		echo '<p class="description">' . esc_html($description) . '</p>';
		echo '</td></tr>';
	}

	private function render_ssl_text_field(string $name, string $label, string $value, string $description, string $type = 'text'): void
	{
		echo '<tr><th scope="row"><label for="freesiem-' . esc_attr($name) . '">' . esc_html($label) . '</label></th><td>';
		echo '<input id="freesiem-' . esc_attr($name) . '" type="' . esc_attr($type) . '" class="regular-text" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" />';
		echo '<p class="description">' . esc_html($description) . '</p>';
		echo '</td></tr>';
	}

	private function format_ssl_challenge_method(string $method): string
	{
		return match ($method) {
			'webroot-http-01' => 'webroot-http-01',
			'standalone-http-01' => 'standalone-http-01',
			'manual-dns-01' => 'manual-dns-01',
			default => 'webroot-http-01',
		};
	}

	private function ssl_preflight_badge_style(string $status): string
	{
		return match (strtoupper($status)) {
			'PASS' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#dcfce7;color:#166534;font-weight:700;',
			'FAIL' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#fee2e2;color:#991b1b;font-weight:700;',
			default => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#fef3c7;color:#92400e;font-weight:700;',
		};
	}

	private function ssl_readiness_badge_style(string $state): string
	{
		return match (sanitize_key($state)) {
			'future_ready' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#dcfce7;color:#166534;font-weight:700;',
			'ready_for_dry_run' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#dbeafe;color:#1d4ed8;font-weight:700;',
			'blocked' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#fee2e2;color:#991b1b;font-weight:700;',
			'partially_configured' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#fef3c7;color:#92400e;font-weight:700;',
			default => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#e5e7eb;color:#374151;font-weight:700;',
		};
	}

	private function ssl_log_badge_style(string $level): string
	{
		return match (sanitize_key($level)) {
			'error' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#fee2e2;color:#991b1b;font-weight:700;',
			'warning' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#fef3c7;color:#92400e;font-weight:700;',
			'success' => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#dcfce7;color:#166534;font-weight:700;',
			default => 'display:inline-block;padding:4px 10px;border-radius:999px;background:#dbeafe;color:#1d4ed8;font-weight:700;',
		};
	}

	private function ssl_result_log_level(string $status): string
	{
		return freesiem_sentinel_ssl_result_log_level($status);
	}

	private function get_login_protection_failure_context(string $username, ?WP_Error $error = null): array
	{
		$raw_username = sanitize_text_field($username);
		$login_username = sanitize_user($raw_username, true);
		$user = $login_username !== '' ? get_user_by('login', $login_username) : false;

		if (!$user instanceof WP_User && is_email($raw_username)) {
			$user = get_user_by('email', sanitize_email($raw_username));
		}

		$error_code = $error instanceof WP_Error ? (string) $error->get_error_code() : '';
		$reason = $user instanceof WP_User ? 'invalid_password' : 'invalid_username';

		if ($error_code === 'invalid_email') {
			$reason = 'invalid_username';
		} elseif ($error_code === 'incorrect_password') {
			$reason = 'invalid_password';
		} elseif ($error_code === 'invalid_username') {
			$reason = 'invalid_username';
		}

		return [
			'known_user' => $user instanceof WP_User,
			'user' => $user instanceof WP_User ? $user : null,
			'normalized_username' => $user instanceof WP_User ? (string) $user->user_login : $login_username,
			'reason' => $reason,
		];
	}

	private function maybe_apply_failed_login_delay(?WP_Error $error = null): void
	{
		$script_name = isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '';
		$is_login_request = str_ends_with($script_name, 'wp-login.php');
		$error_code = $error instanceof WP_Error ? (string) $error->get_error_code() : '';

		if (!$is_login_request || wp_doing_ajax() || in_array($error_code, ['freesiem_login_locked', 'freesiem_login_banned'], true)) {
			return;
		}

		$delay_ms = freesiem_sentinel_get_login_protection_failed_login_delay_ms();
		if ($delay_ms > 0) {
			usleep($delay_ms * 1000);
		}
	}

	public function maybe_enforce_login_lockout($user, string $username, string $password)
	{
		$settings = freesiem_sentinel_get_login_protection_settings();
		if (empty($settings['enabled']) || $username === '' || $user instanceof WP_User) {
			return $user;
		}

		$record = freesiem_sentinel_get_login_protection_record($username, '', $settings);
		if (!empty($record['permanently_banned'])) {
			freesiem_sentinel_log_event('lockout_denied_request', __('Login attempt denied because this key is permanently banned.', 'freesiem-sentinel'), (string) ($record['username'] ?? $username), (string) ($record['ip_address'] ?? ''), [
				'status' => 'permanent_ban',
				'key_type' => (string) ($record['key_type'] ?? 'combined'),
				'reason' => (string) ($record['reason'] ?? 'permanent_ban'),
			]);

			return new WP_Error('freesiem_login_banned', __('This login source has been blocked. Contact the site administrator.', 'freesiem-sentinel'));
		}

		if ((int) ($record['locked_until'] ?? 0) > time()) {
			freesiem_sentinel_log_event('lockout_denied_request', __('Login attempt blocked because the username/IP is currently locked out.', 'freesiem-sentinel'), (string) ($record['username'] ?? $username), (string) ($record['ip_address'] ?? ''), [
				'locked_until' => (int) ($record['locked_until'] ?? 0),
				'status' => 'active_lockout',
				'key_type' => (string) ($record['key_type'] ?? 'combined'),
			]);

			return new WP_Error('freesiem_login_locked', __('Too many failed login attempts. Please try again later.', 'freesiem-sentinel'));
		}

		return $user;
	}

	public function handle_login_failed_event(string $username, ?WP_Error $error = null): void
	{
		$settings = freesiem_sentinel_get_login_protection_settings();
		$error_code = $error instanceof WP_Error ? (string) $error->get_error_code() : '';
		if (in_array($error_code, ['freesiem_login_locked', 'freesiem_login_banned'], true)) {
			return;
		}

		$failure = $this->get_login_protection_failure_context($username, $error);
		$normalized_username = (string) ($failure['normalized_username'] ?? '');
		$reason = (string) ($failure['reason'] ?? 'invalid_password');
		$record = freesiem_sentinel_get_login_protection_record($normalized_username !== '' ? $normalized_username : $username, '', $settings);

		if (empty($settings['enabled'])) {
			if (!empty($settings['log_failed_logins'])) {
				freesiem_sentinel_log_event(
					$reason === 'invalid_username' ? 'invalid_username_attempt' : 'login_failed',
					$reason === 'invalid_username' ? __('WordPress login failed for an unknown username or email.', 'freesiem-sentinel') : __('WordPress login failed.', 'freesiem-sentinel'),
					$normalized_username !== '' ? $normalized_username : $username,
					(string) ($record['ip_address'] ?? ''),
					['reason' => $reason]
				);
			}

			$this->maybe_apply_failed_login_delay($error);
			return;
		}

		$record['attempts'] = (int) ($record['attempts'] ?? 0) + 1;
		$record['last_failure_at'] = time();
		$record['reason'] = $reason;
		$lockout_rule = null;
		foreach (freesiem_sentinel_get_login_protection_progressive_thresholds($settings) as $rule) {
			if ((int) $record['attempts'] >= (int) ($rule['threshold'] ?? 0)) {
				$lockout_rule = $rule;
			}
		}

		if (is_array($lockout_rule)) {
			$record['locked_until'] = time() + (max(1, (int) ($lockout_rule['duration_minutes'] ?? 15)) * MINUTE_IN_SECONDS);
			$record['total_offenses'] = (int) ($record['total_offenses'] ?? 0) + 1;
			if (!empty($settings['enable_permanent_ban']) && (int) ($settings['permanent_ban_threshold'] ?? 0) > 0 && (int) $record['total_offenses'] >= (int) ($settings['permanent_ban_threshold'] ?? 0)) {
				$record['permanently_banned'] = 1;
				$record['locked_until'] = 0;
				$record['reason'] = 'permanent_ban_threshold';
				freesiem_sentinel_log_event('permanent_ban_triggered', __('A permanent login protection ban was triggered after repeated lockouts.', 'freesiem-sentinel'), (string) ($record['username'] ?? $username), (string) ($record['ip_address'] ?? ''), [
					'attempts' => (int) ($record['attempts'] ?? 0),
					'total_offenses' => (int) ($record['total_offenses'] ?? 0),
					'key_type' => (string) ($record['key_type'] ?? 'combined'),
				]);
				do_action('freesiem_sentinel_login_ban_triggered', $record, ['source' => 'system']);
			} else {
				freesiem_sentinel_log_event('lockout_triggered', __('Login lockout triggered after repeated failed attempts.', 'freesiem-sentinel'), (string) ($record['username'] ?? $username), (string) ($record['ip_address'] ?? ''), [
					'attempts' => (int) ($record['attempts'] ?? 0),
					'total_offenses' => (int) ($record['total_offenses'] ?? 0),
					'locked_until' => (int) ($record['locked_until'] ?? 0),
					'lockout_duration_minutes' => (int) ($lockout_rule['duration_minutes'] ?? 0),
					'key_type' => (string) ($record['key_type'] ?? 'combined'),
				]);
				do_action('freesiem_sentinel_login_lockout_triggered', $record, ['source' => 'system']);
			}
		}

		freesiem_sentinel_upsert_login_protection_record($record);
		if (!empty($settings['log_failed_logins'])) {
			freesiem_sentinel_log_event($reason === 'invalid_username' ? 'invalid_username_attempt' : 'login_failed', $reason === 'invalid_username' ? __('WordPress login failed for an unknown username or email.', 'freesiem-sentinel') : __('WordPress login failed.', 'freesiem-sentinel'), (string) ($record['username'] !== '' ? $record['username'] : $username), (string) ($record['ip_address'] ?? ''), [
				'attempts' => !empty($settings['track_failed_login_count']) ? (int) ($record['attempts'] ?? 0) : 0,
				'total_offenses' => (int) ($record['total_offenses'] ?? 0),
				'reason' => $reason,
				'key_type' => (string) ($record['key_type'] ?? 'combined'),
			]);
		}

		$this->maybe_apply_failed_login_delay($error);
	}

	public function handle_login_success_event(string $user_login, WP_User $user): void
	{
		$settings = freesiem_sentinel_get_login_protection_settings();
		$record = freesiem_sentinel_get_login_protection_record($user_login, '', $settings);
		if (!empty($record['key'])) {
			freesiem_sentinel_delete_login_protection_record((string) $record['key']);
		}

		if (!empty($settings['log_successful_logins'])) {
			freesiem_sentinel_log_event('login_success', __('WordPress login succeeded.', 'freesiem-sentinel'), $user_login, (string) ($record['ip_address'] ?? ''), [
				'user_id' => (int) $user->ID,
			]);
		}
	}

	public function handle_tfa_success_event(int $user_id, array $context = []): void
	{
		$user = get_user_by('id', $user_id);
		freesiem_sentinel_log_event('tfa_success', __('TFA verification succeeded.', 'freesiem-sentinel'), $user instanceof WP_User ? (string) $user->user_login : '', '', $context);
	}

	public function handle_tfa_failure_event(int $user_id, array $context = []): void
	{
		$user = get_user_by('id', $user_id);
		freesiem_sentinel_log_event('tfa_failure', __('TFA verification failed.', 'freesiem-sentinel'), $user instanceof WP_User ? (string) $user->user_login : '', '', $context);
	}

	public function maybe_handle_stealth_mode(): void
	{
		$settings = freesiem_sentinel_get_stealth_mode_settings();
		if (!freesiem_sentinel_is_stealth_mode_effectively_active($settings)) {
			return;
		}

		$script_name = isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '';
		$is_login_request = str_ends_with($script_name, 'wp-login.php');
		$is_admin_request = is_admin() && !wp_doing_ajax();
		$token = freesiem_sentinel_get_sanitized_stealth_request_token();
		$token_raw = freesiem_sentinel_get_raw_stealth_request_token();
		$expected = freesiem_sentinel_get_stealth_expected_token($settings);
		$has_valid_token = freesiem_sentinel_request_has_valid_stealth_token($settings);
		$login_action = isset($_REQUEST['action']) ? sanitize_key((string) wp_unslash($_REQUEST['action'])) : '';
		$allowed_login_actions = $this->get_allowed_stealth_login_actions();
		$request_method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

		$request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash((string) $_SERVER['REQUEST_URI']) : '';
		$request_path = trim((string) wp_parse_url($request_uri, PHP_URL_PATH), '/');
		$home_path = trim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
		if ($home_path !== '' && str_starts_with($request_path, $home_path . '/')) {
			$request_path = trim(substr($request_path, strlen($home_path)), '/');
		}

		if (!$is_login_request && in_array($request_method, ['GET', 'HEAD'], true) && $request_path === $expected) {
			$url = freesiem_sentinel_get_stealth_query_login_url($settings);
			$redirect_to = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash((string) $_GET['redirect_to'])) : '';
			$action = isset($_GET['action']) ? sanitize_key(wp_unslash((string) $_GET['action'])) : '';
			$reauth = isset($_GET['reauth']) ? sanitize_text_field(wp_unslash((string) $_GET['reauth'])) : '';
			if ($redirect_to !== '') {
				$url = add_query_arg(['redirect_to' => $redirect_to], $url);
			}
			if ($action !== '') {
				$url = add_query_arg(['action' => $action], $url);
			}
			if ($reauth !== '') {
				$url = add_query_arg(['reauth' => $reauth], $url);
			}

			freesiem_sentinel_log_event('stealth_login_path_access', __('Friendly Stealth login path accessed.', 'freesiem-sentinel'), '', '', [
				'request_path' => $request_path,
				'redirect_to' => $redirect_to,
			]);
			wp_safe_redirect($url);
			exit;
		}

		if ($is_login_request && $token_raw !== '' && !$has_valid_token) {
			freesiem_sentinel_log_event('stealth_invalid_token', __('An invalid Stealth Mode token was supplied to wp-login.php.', 'freesiem-sentinel'), '', '', [
				'action' => $login_action,
				'request_method' => $request_method,
				'token_length' => strlen($token_raw),
			]);
		}

		if ($is_login_request && $has_valid_token && $request_method !== 'POST') {
			freesiem_sentinel_log_event('stealth_login_access', __('Stealth login URL accessed.', 'freesiem-sentinel'), '', '', [
				'action' => $login_action === '' ? 'login' : $login_action,
			]);
		}

		if ($is_login_request && !is_user_logged_in() && !empty($settings['block_direct_wp_login']) && !$has_valid_token && !in_array($login_action, $allowed_login_actions, true)) {
			freesiem_sentinel_log_event('stealth_block', __('Direct wp-login.php access was blocked by Stealth Mode.', 'freesiem-sentinel'), '', '', [
				'action' => $login_action === '' ? 'login' : $login_action,
				'request_method' => $request_method,
				'token_present' => $token_raw !== '',
				'token_matches_expected' => $token === $expected,
			]);
			wp_safe_redirect(home_url('/'));
			exit;
		}

		if ($is_admin_request && !is_user_logged_in() && !empty($settings['redirect_wp_admin_guests'])) {
			freesiem_sentinel_log_event('stealth_admin_redirect', __('Unauthenticated wp-admin access was redirected to the Stealth login URL.', 'freesiem-sentinel'), '', '', [
				'request_uri' => isset($_SERVER['REQUEST_URI']) ? sanitize_text_field((string) wp_unslash($_SERVER['REQUEST_URI'])) : '/wp-admin/',
			]);
			$request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash((string) $_SERVER['REQUEST_URI']) : '/wp-admin/';
			$target = wp_validate_redirect(home_url($request_uri), admin_url());
			wp_safe_redirect(wp_login_url($target));
			exit;
		}
	}

	public function render_stealth_login_token_field(): void
	{
		$settings = freesiem_sentinel_get_stealth_mode_settings();
		if (!freesiem_sentinel_is_stealth_mode_effectively_active($settings)) {
			return;
		}

		$token = freesiem_sentinel_get_sanitized_stealth_request_token();
		if ($token === '' || !freesiem_sentinel_request_has_valid_stealth_token($settings)) {
			return;
		}

		echo '<input type="hidden" name="freesiem_login" value="' . esc_attr($token) . '" />';
	}

	public function filter_stealth_login_error_message(string $message): string
	{
		$settings = freesiem_sentinel_get_stealth_mode_settings();
		$login_protection_settings = freesiem_sentinel_get_login_protection_settings();
		if ($message === '') {
			return $message;
		}

		$login_action = isset($_REQUEST['action']) ? sanitize_key((string) wp_unslash($_REQUEST['action'])) : '';
		if (in_array($login_action, ['lostpassword', 'retrievepassword', 'rp', 'resetpass', 'register'], true)) {
			return $message;
		}

		if (!empty($_REQUEST['freesiem_tfa_token']) || !empty($_POST['freesiem_tfa_verify'])) {
			return $message;
		}

		if (
			freesiem_sentinel_is_stealth_mode_effectively_active($settings) ||
			!empty($login_protection_settings['enabled'])
		) {
			return __('Login failed. Check your credentials and try again.', 'freesiem-sentinel');
		}

		return $message;
	}

	public function filter_login_url(string $login_url, string $redirect, bool $force_reauth): string
	{
		$settings = freesiem_sentinel_get_stealth_mode_settings();
		if (!freesiem_sentinel_is_stealth_mode_effectively_active($settings)) {
			return $login_url;
		}

		$url = freesiem_sentinel_get_stealth_login_url($settings);
		if ($redirect !== '') {
			$url = add_query_arg(['redirect_to' => $redirect], $url);
		}
		if ($force_reauth) {
			$url = add_query_arg(['reauth' => '1'], $url);
		}

		return $url;
	}

	public function filter_stealth_login_redirect(string $redirect_to, string $requested_redirect_to, WP_User|WP_Error $user): string
	{
		$settings = freesiem_sentinel_get_stealth_mode_settings();
		if (!freesiem_sentinel_is_stealth_mode_effectively_active($settings) || is_wp_error($user)) {
			return $redirect_to;
		}

		$requested_redirect_to = wp_validate_redirect($requested_redirect_to, '');
		if ($requested_redirect_to !== '') {
			return $requested_redirect_to;
		}

		if (!freesiem_sentinel_request_has_valid_stealth_token($settings)) {
			return $redirect_to;
		}

		return admin_url();
	}

	private function get_allowed_stealth_login_actions(): array
	{
		$actions = ['logout', 'lostpassword', 'retrievepassword', 'rp', 'resetpass', 'postpass'];

		if ((int) get_option('users_can_register', 0) === 1) {
			$actions[] = 'register';
		}

		return $actions;
	}

	private function get_synchy_tabs(): array
	{
		return [
			'sync' => [
				'label' => __('Sync', 'freesiem-sentinel'),
				'legacy_slug' => 'synchy-site-sync',
			],
			'export' => [
				'label' => __('Export & Import', 'freesiem-sentinel'),
				'legacy_slug' => 'synchy-export',
			],
			'schedule' => [
				'label' => __('Schedule', 'freesiem-sentinel'),
				'legacy_slug' => 'synchy-scheduled-backups',
			],
		];
	}

	private function get_synchy_current_tab(): string
	{
		$tab = isset($_GET['tab']) ? sanitize_key((string) wp_unslash($_GET['tab'])) : 'sync';

		// Import and Upload to Live no longer have their own tabs -- Import merged into Export
		// (now "Backup & Restore"), Upload to Live was removed outright -- but old bookmarks/links
		// with ?tab=import or ?tab=upload-live should still land somewhere sensible, not silently
		// fall back to Sync.
		if ($tab === 'import' || $tab === 'upload-live') {
			return 'export';
		}

		$tabs = $this->get_synchy_tabs();

		return isset($tabs[$tab]) ? $tab : 'sync';
	}

	private function get_synchy_legacy_page_slug(string $tab): string
	{
		$tabs = $this->get_synchy_tabs();

		return isset($tabs[$tab]['legacy_slug']) ? (string) $tabs[$tab]['legacy_slug'] : 'synchy-site-sync';
	}

	private function get_synchy_tab_for_legacy_page(string $page): string
	{
		if ($page === 'synchy') {
			return 'sync';
		}

		if ($page === 'synchy-settings') {
			return 'sync';
		}

		// Same backward-compat mapping as get_synchy_current_tab(): both old legacy page slugs
		// now live under the Export tab (renamed "Backup & Restore").
		if ($page === 'synchy-import' || $page === 'synchy-push-live-site') {
			return 'export';
		}

		foreach ($this->get_synchy_tabs() as $tab => $config) {
			if ((string) ($config['legacy_slug'] ?? '') === $page) {
				return $tab;
			}
		}

		return '';
	}

	private function get_settings_tabs(): array
	{
		return [
			'general' => [
				'label' => __('General', 'freesiem-sentinel'),
			],
			'about' => [
				'label' => __('About', 'freesiem-sentinel'),
			],
		];
	}

	private function get_settings_current_tab(): string
	{
		$tab = isset($_GET['tab']) ? sanitize_key((string) wp_unslash($_GET['tab'])) : 'about';
		$tabs = $this->get_settings_tabs();

		return isset($tabs[$tab]) ? $tab : 'about';
	}

	private function filter_synchy_rendered_page_html(string $html, string $current_tab): string
	{
		$about_urls = [
			preg_quote(admin_url('admin.php?page=synchy-settings'), '#'),
			preg_quote(admin_url('admin.php?page=' . FREESIEM_SENTINEL_SYNCHY_PAGE . '&tab=about'), '#'),
		];

		foreach ($about_urls as $about_url) {
			$html = preg_replace('#<a[^>]+href="' . $about_url . '"[^>]*>.*?</a>#si', '', $html) ?? $html;
		}

		return $html;
	}

	private function get_synchy_asset_path(string $asset): string
	{
		$asset = ltrim($asset, '/');
		$plugin_path = WP_PLUGIN_DIR . '/synchy/assets/' . $asset;

		if (file_exists($plugin_path)) {
			return $plugin_path;
		}

		$bundled_path = FREESIEM_SENTINEL_PLUGIN_DIR . 'includes/synchy/assets/' . $asset;

		return file_exists($bundled_path) ? $bundled_path : '';
	}

	private function get_synchy_asset_url(string $asset): string
	{
		$asset = ltrim($asset, '/');
		$plugin_path = WP_PLUGIN_DIR . '/synchy/assets/' . $asset;

		if (file_exists($plugin_path)) {
			return plugins_url('synchy/assets/' . $asset);
		}

		$bundled_path = FREESIEM_SENTINEL_PLUGIN_DIR . 'includes/synchy/assets/' . $asset;

		return file_exists($bundled_path) ? plugins_url('includes/synchy/assets/' . $asset, FREESIEM_SENTINEL_PLUGIN_FILE) : '';
	}

	private function assert_manage_permissions(): void
	{
		if (!freesiem_sentinel_current_user_can_manage()) {
			wp_die(esc_html__('You are not allowed to manage freeSIEM Sentinel.', 'freesiem-sentinel'));
		}
	}

	private function assert_task_permissions(): void
	{
		if (!$this->plugin->get_pending_tasks()->current_user_can_approve_tasks()) {
			wp_die(esc_html__('You are not allowed to review freeSIEM Pending Tasks.', 'freesiem-sentinel'));
		}
	}

	private function redirect_to_page(string $page, array $args = []): void
	{
		wp_safe_redirect(freesiem_sentinel_admin_page_url($page, $args));
		exit;
	}
}
